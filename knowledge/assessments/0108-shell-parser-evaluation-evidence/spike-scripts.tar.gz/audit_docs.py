import sys

sys.path.insert(0, "/repo")
from tools import shell_reader as sr

files = open("/frozen/files.txt").read().split()
raised, corpus, bom, cr = [], [], [], []
for name in files:
    raw = open(f"/repo/{name}", "rb").read()
    try:
        found = sr.shell_lines(name, raw.decode("utf-8").split("\n"))
    except Exception as exc:
        raised.append((name, type(exc).__name__, raw[:2]))
        continue
    if found:
        corpus.append(name)
        bom += [name] if raw.startswith(b"\xef\xbb\xbf") else []
        cr += [name] if b"\r" in raw else []
print("tracked files:", len(files), "files with shell surfaces:", len(corpus))
print("corpus files with a BOM:", bom, "with a CR:", cr)
print("files that raised:", len(raised))
for name, kind, magic in raised:
    archive = magic in (b"\x1f\x8b", b"PK") or name.endswith(".tar")
    print(f"  {kind} {name} shebang={magic == b'#!'} archive={archive}")
