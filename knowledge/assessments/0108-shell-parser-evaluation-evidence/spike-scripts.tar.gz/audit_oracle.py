import json, re, sys
sys.argv = ["x"]
exec(open("/spike/corpus_scripts.py").read().split('print(f"{len(masked)} scripts')[0])
# Every occurrence of the word `git`, found by text alone, independently of any parser.
WORD = re.compile(r"(?<![\w.$-])git(?![\w-])")
parser = Parser(Language(tsb.language()))
covered_total = residual_total = 0
residual = []
for path, script in masked:
    data = script.encode("utf-8")
    spans = []
    stack = [parser.parse(data).root_node]
    while stack:
        node = stack.pop()
        if node.type == "command":
            argv = ts_argv(node)
            if argv and argv[0] is not None and sr._runs_git([w if w is not None else "\x00" for w in argv], 0):
                spans.append((node.start_byte, node.end_byte))
        stack.extend(node.children)
    for m in WORD.finditer(script):
        at = len(script[: m.start()].encode("utf-8"))
        if any(a <= at < b for a, b in spans):
            covered_total += 1
        else:
            residual_total += 1
            line_start = script.rfind("\n", 0, m.start()) + 1
            line_end = script.find("\n", m.start())
            residual.append((path, script[line_start: line_end if line_end != -1 else None].strip()))
print("scripts", len(masked), "git words", covered_total + residual_total, "inside an oracle command", covered_total, "elsewhere", residual_total)
for path, line in residual:
    print(f"  {path}: {line[:150]}")
