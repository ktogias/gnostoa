"""Whole scripts, extracted properly: each workflow or action `run:` value through
YAML, so its block indentation is gone; other files as the reader's joined lines."""
import json, re, sys, yaml
sys.argv = ["x"]
exec(open("/spike/evaluate314.py").read().split("ADAPTERS = {")[0])
mask = re.compile(r"\$\{\{.*?\}\}", re.S)
docs = json.load(open("/spike/corpus.json"))
scripts = []
def runs(node, path):
    if isinstance(node, dict):
        for k, v in node.items():
            if k == "run" and isinstance(v, str):
                scripts.append((path, v))
            else:
                runs(v, path)
    elif isinstance(node, list):
        for v in node:
            runs(v, path)
for d in docs:
    p = d["path"]
    if p.startswith(".github/") and p.endswith((".yml", ".yaml")):
        runs(yaml.safe_load(open(f"/repo/{p}", encoding="utf-8")), p)
    else:
        scripts.append((p, d["text"]))
masked = [(p, mask.sub(lambda m: "_" * len(m.group(0)), s)) for p, s in scripts]
print(f"{len(masked)} scripts from {len({p for p, _ in masked})} files")
for name, analyse in (("tree-sitter-bash 0.25.1", ts_analyse), ("mvdan/sh 3.14.1", sh_analyse)):
    git = 0; problems = []; dynamic = 0
    for p, s in masked:
        a = analyse(s)
        if a.unsupported:
            problems.append(p)
        for argv in a.commands:
            if argv and argv[0] is None:
                dynamic += 1
            elif argv and sr._runs_git([w if w is not None else "\x00" for w in argv], 0):
                git += 1
    print(f"{name}: git commands {git}; scripts with a parse problem {len(problems)} {sorted(set(problems))}; dynamic command words {dynamic}")
