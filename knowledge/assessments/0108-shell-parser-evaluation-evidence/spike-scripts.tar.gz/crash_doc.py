import json, sys, faulthandler
faulthandler.enable()
exec(open("/spike/spike.py").read().split("CORPUS: list")[0])
docs = json.load(open("/spike/corpus.json"))
selected = [d for d in docs if not sys.argv[1:] or d["path"] == sys.argv[1]]
for d in selected:
    print("DOC", d["path"], flush=True)
    source = d["text"].encode()
    tree = Parser(LANG).parse(source)
    stack = [tree.root_node]
    while stack:
        node = stack.pop()
        if node.type == "command":
            _argv(node)
        stack.extend(node.named_children)
print("ok")
