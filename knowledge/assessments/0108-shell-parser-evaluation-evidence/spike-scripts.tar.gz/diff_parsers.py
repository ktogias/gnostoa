import json, re, sys, yaml
sys.argv = ["x"]
exec(open("/spike/corpus_scripts.py").read().split('print(f"{len(masked)} scripts')[0])
def gits(analyse, s):
    out = []
    for argv in analyse(s).commands:
        if argv and argv[0] is not None and sr._runs_git([w if w is not None else "\x00" for w in argv], 0):
            out.append(" ".join(w if w is not None else "<dyn>" for w in argv)[:70])
    return out
for p, s in masked:
    a, b = gits(ts_analyse, s), gits(sh_analyse, s)
    if sorted(a) != sorted(b):
        print(p, "\n  tree-sitter only:", sorted(set(a) - set(b)), "\n  mvdan/sh only:", sorted(set(b) - set(a)))
        print("  counts", len(a), len(b))
