import hashlib, json, subprocess, sys
sys.path.insert(0, "/repo")
from tools import shell_reader as sr
files = subprocess.run(["git", "-C", "/repo", "ls-files"], capture_output=True, text=True, check=True).stdout.split()
out = []
for name in files:
    try:
        lines = open(f"/repo/{name}", encoding="utf-8").read().split("\n")
        found = sr.shell_lines(name, lines)
    except Exception:
        continue
    if found:
        numbers = sorted(found)
        text = "\n".join(found[n][0] for n in numbers)
        out.append({"path": name, "lines": numbers, "text": text, "sha256": hashlib.sha256(text.encode()).hexdigest()})
json.dump(out, open("/spike/corpus.json", "w"), indent=1)
print(len(out), "documents")
