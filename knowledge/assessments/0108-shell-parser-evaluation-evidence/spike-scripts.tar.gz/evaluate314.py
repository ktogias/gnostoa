"""Evaluate two shell parsers as the structure behind shell_reader's own policy.

Each adapter turns shell text into the argument lists of the commands it executes,
the commands whose word is dynamic, the constructs it could not parse, and the
here-document bodies a shell reads. The policy is shell_reader's: `_runs_git` on each
argument list, recursing into `sh -c`, `eval` and the like through `runs_git`, which
is replaced by the adapter's. The shell reader's own suite then measures each.
"""

from __future__ import annotations

import json
import subprocess
import sys
import unittest
from dataclasses import dataclass, field

sys.path.insert(0, "/repo")
from tools import shell_reader as sr  # noqa: E402

DYNAMIC = None


@dataclass
class Analysis:
    commands: list[list[str | None]] = field(default_factory=list)
    stdin_bodies: list[tuple[list[str | None], str]] = field(default_factory=list)
    unsupported: list[str] = field(default_factory=list)


def policy_runs_git(analysis: Analysis, depth: int, recurse) -> bool:
    if depth > 4:
        return False
    for argv in analysis.commands:
        if not argv or argv[0] is None:
            continue
        words = [w if w is not None else "\x00" for w in argv]
        if sr._runs_git(words, depth):
            return True
    for argv, body in analysis.stdin_bodies:
        words = [w for w in argv if w is not None]
        if words and sr._reads_stdin(words) and recurse(body, depth + 1):
            return True
    return False


# --- tree-sitter-bash -------------------------------------------------------------
import tree_sitter_bash as tsb  # noqa: E402
from tree_sitter import Language, Parser  # noqa: E402

LANG = Language(tsb.language())
KEEP: list = []


def ts_static(node) -> str | None:
    t, text = node.type, node.text.decode(errors="replace")
    if t == "word":
        out, i = [], 0
        while i < len(text):
            if text[i] == "\\" and i + 1 < len(text):
                if text[i + 1] != "\n":
                    out.append(text[i + 1])
                i += 2
            else:
                out.append(text[i])
                i += 1
        return "".join(out)
    if t == "raw_string":
        return text[1:-1]
    if t == "string":
        if any(c.type != "string_content" for c in node.named_children):
            return None
        return "".join(c.text.decode() for c in node.named_children).replace('\\"', '"').replace("\\\\", "\\").replace("\\$", "$").replace("\\`", "`")
    if t == "concatenation":
        parts = [ts_static(c) for c in node.named_children]
        return None if any(p is None for p in parts) else "".join(parts)
    if t == "number":
        return text
    return None


def ts_argv(command) -> list[str | None]:
    argv: list[str | None] = []
    for child in command.named_children:
        if child.type == "variable_assignment" or "redirect" in child.type:
            continue
        target = child.named_children[0] if child.type == "command_name" and child.named_children else child
        argv.append(ts_static(target))
    return argv


def ts_first_command(node):
    stack = [node]
    while stack:
        n = stack.pop(0)
        if n.type == "command":
            return n
        stack[:0] = list(n.named_children)
    return None


def ts_analyse(text: str) -> Analysis:
    source = text.encode()
    tree = Parser(LANG).parse(source)
    KEEP.append((source, tree))
    result = Analysis()
    stack = [tree.root_node]
    while stack:
        node = stack.pop()
        if node.is_error or node.is_missing:
            result.unsupported.append(node.type)
        if node.type == "command":
            result.commands.append(ts_argv(node))
        if node.type == "redirected_statement":
            redirect = next((c for c in node.named_children if c.type == "heredoc_redirect"), None)
            body_node = node.child_by_field_name("body")
            if redirect is not None and body_node is not None:
                first = ts_first_command(body_node)
                body = "".join(c.text.decode() for c in redirect.named_children if c.type == "heredoc_body")
                if first is not None:
                    result.stdin_bodies.append((ts_argv(first), body))
        stack.extend(node.named_children)
    return result


def ts_runs_git(text: str, depth: int = 0) -> bool:
    return policy_runs_git(ts_analyse(text), depth, ts_runs_git)


# --- mvdan/sh (shfmt --to-json) ---------------------------------------------------
SHFMT = "/spike/shfmt314"


def sh_unescape(value: str) -> str:
    out, i = [], 0
    while i < len(value):
        if value[i] == "\\" and i + 1 < len(value):
            if value[i + 1] != "\n":
                out.append(value[i + 1])
            i += 2
        else:
            out.append(value[i])
            i += 1
    return "".join(out)


def sh_dq_unescape(value: str) -> str:
    out, i = [], 0
    while i < len(value):
        if value[i] == "\\" and i + 1 < len(value) and value[i + 1] in '$`"\\\n':
            if value[i + 1] != "\n":
                out.append(value[i + 1])
            i += 2
        else:
            out.append(value[i])
            i += 1
    return "".join(out)


def sh_static(word) -> str | None:
    if not word:
        return None
    out = []
    for part in word.get("Parts") or []:
        kind = part.get("Type")
        if kind == "Lit":
            out.append(sh_unescape(part.get("Value", "")))
        elif kind == "SglQuoted":
            out.append(part.get("Value", ""))
        elif kind == "DblQuoted":
            inner = part.get("Parts") or []
            if any(p.get("Type") != "Lit" for p in inner):
                return None
            out.append("".join(sh_dq_unescape(p.get("Value", "")) for p in inner))
        else:
            return None
    return "".join(out)


def sh_first_call(node):
    stack = [node]
    while stack:
        n = stack.pop(0)
        if isinstance(n, dict):
            if n.get("Type") == "CallExpr":
                return n
            stack[:0] = [v for v in n.values() if isinstance(v, (dict, list))]
        elif isinstance(n, list):
            stack[:0] = n
    return None


def sh_hdoc_text(word) -> str:
    out = []
    for part in (word or {}).get("Parts") or []:
        if part.get("Type") == "Lit":
            out.append(part.get("Value", ""))
        else:
            out.append("_")
    return "".join(out)


def sh_analyse(text: str) -> Analysis:
    result = Analysis()
    done = subprocess.run([SHFMT, "--to-json", "-ln", "bash"], input=text, capture_output=True, text=True, check=False)
    if done.returncode != 0:
        result.unsupported.append(done.stderr.strip()[:80])
        return result
    tree = json.loads(done.stdout)

    def visit(node):
        if isinstance(node, list):
            for item in node:
                visit(item)
            return
        if not isinstance(node, dict):
            return
        kind = node.get("Type")
        if kind == "CallExpr":
            result.commands.append([sh_static(w) for w in node.get("Args") or []])
        if "Cmd" in node and node.get("Redirs"):
            for redirect in node["Redirs"]:
                if redirect.get("Hdoc") is not None:
                    first = sh_first_call(node.get("Cmd"))
                    if first is not None:
                        argv = [sh_static(w) for w in first.get("Args") or []]
                        result.stdin_bodies.append((argv, sh_hdoc_text(redirect["Hdoc"])))
        if kind == "CoprocClause":
            # coproc NAME stmt: the statement is visited as any other.
            pass
        for value in node.values():
            if isinstance(value, (dict, list)):
                visit(value)

    visit(tree)
    return result


def sh_runs_git(text: str, depth: int = 0) -> bool:
    return policy_runs_git(sh_analyse(text), depth, sh_runs_git)


ADAPTERS = {"tree-sitter-bash": ts_runs_git, "shfmt": sh_runs_git}


def run_suite(name: str) -> None:
    original = sr.runs_git
    sr.runs_git = ADAPTERS[name]  # type: ignore[assignment]
    try:
        import tests.test_owned_responsibilities as t

        loader = unittest.TestLoader()
        suite = unittest.TestSuite(
            [loader.loadTestsFromTestCase(t.ShellReaderTests), loader.loadTestsFromTestCase(t.ShellReaderUnitTests)]
        )
        result = unittest.TestResult()
        result.failfast = False
        # Count each subTest failure on its own.
        suite.run(result)
        failures = [(str(test), err.strip().splitlines()[-1][:160]) for test, err in result.failures + result.errors]
        print(f"== {name}: ran {result.testsRun} tests; {len(failures)} failing (test or subtest)")
        for test, last in failures:
            print(f"   {test.split("(")[0]} {test[test.find("(", test.find(")")):][:120]} -> {last[:60]}")
    finally:
        sr.runs_git = original  # type: ignore[assignment]


if __name__ == "__main__":
    for adapter in sys.argv[1:] or list(ADAPTERS):
        run_suite(adapter)
