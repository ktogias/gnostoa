import re, subprocess, sys, yaml
exec(open("/spike/spike.py").read().split("CORPUS: list")[0])
reg = yaml.safe_load(open("/repo/policy/owned-responsibilities.yaml"))
patterns = [re.compile(s["pattern"]) for r in reg["responsibilities"] if r["id"] == "trusted-execution" for s in r.get("signatures") or [] if s.get("pattern") and s.get("id") == "git-execution"]
files = subprocess.run(["git", "-C", "/repo", "ls-files"], capture_output=True, text=True, check=True).stdout.split()
total = net = reader = neither = 0
missed = []
for name in files:
    try:
        lines = open(f"/repo/{name}", encoding="utf-8").read().split("\n")
        found = sr.shell_lines(name, lines)
    except Exception:
        continue
    if not found:
        continue
    numbers = sorted(found)
    source = "\n".join(found[n][0] for n in numbers).encode()
    tree = Parser(LANG).parse(source)
    # Collect first, with no parse in between: a nested parse during a walk crashed
    # the binding.
    collected = []
    stack = [tree.root_node]
    while stack:
        node = stack.pop()
        if node.type == "command":
            collected.append((node.start_point.row, _argv(node)))
        stack.extend(node.named_children)
    for row, argv in collected:
        if argv and argv[0] != DYNAMIC and sr._runs_git([w if w != DYNAMIC else "_" for w in argv], 0):
            original = numbers[row] if row < len(numbers) else None
            text = lines[original - 1] if original else ""
            total += 1
            by_net = any(p.search(text) for p in patterns)
            by_reader = _ADHOC(found[original][0]) if original else False
            net += by_net
            reader += by_reader
            if not (by_net or by_reader):
                neither += 1
                missed.append((name, original, text.strip()[:100]))
print(f"git commands the parser finds: {total}; caught by the line net: {net}; by the reader: {reader}; by neither: {neither}")
for m in missed:
    print("  MISSED", m)
