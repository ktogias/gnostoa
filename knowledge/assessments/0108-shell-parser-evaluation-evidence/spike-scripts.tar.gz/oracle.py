import json, re, sys, yaml
sys.argv = ["x"]
exec(open("/spike/corpus_scripts.py").read().split('print(f"{len(masked)} scripts')[0])
oracle = []
for p, s in masked:
    for argv in ts_analyse(s).commands:
        if argv and argv[0] is not None and sr._runs_git([w if w is not None else "\x00" for w in argv], 0):
            oracle.append({"path": p, "argv": argv})
json.dump(oracle, open("/spike/oracle.json", "w"), indent=0)
from collections import Counter
for p, n in sorted(Counter(o["path"] for o in oracle).items()):
    print(f"{n:3} {p}")
print("total", len(oracle))
