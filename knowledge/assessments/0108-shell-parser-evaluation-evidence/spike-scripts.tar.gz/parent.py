import json, os, re, subprocess, sys, time, yaml
exec(open("/spike/corpus_scripts.py").read().split('print(f"{len(masked)} scripts')[0])
batch = [s for _, s in masked]
for crash in ("", "1"):
    started = time.perf_counter()
    env = dict(os.environ, CRASH=crash)
    try:
        done = subprocess.run([sys.executable, "/spike/worker.py"], input=json.dumps(batch), capture_output=True, text=True, timeout=60, env=env)
        if done.returncode != 0:
            verdict = f"UNKNOWN for all {len(batch)} scripts: worker exited {done.returncode}"
        else:
            result = json.loads(done.stdout)
            verdict = f"{len(result)} analyses"
    except subprocess.TimeoutExpired:
        verdict = "UNKNOWN: worker timed out"
    elapsed = time.perf_counter() - started
    print(f"crash={bool(crash)}: {verdict}; {elapsed:.2f}s for the whole batch")
started = time.perf_counter()
for s in batch:
    ts_analyse(s)
print(f"in-process: {time.perf_counter() - started:.2f}s for the whole batch")
