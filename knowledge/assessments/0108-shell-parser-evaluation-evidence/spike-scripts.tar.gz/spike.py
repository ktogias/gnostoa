"""Spike: tree-sitter-bash for structure, shell_reader's own argv policy for meaning.

Not repository code. Compares the current ad-hoc reader with a parser-backed reader
on a corpus of hard cases from #369's reviews, and scans the repository's tracked
shell surfaces for parse errors and dynamic command words.
"""

from __future__ import annotations

import subprocess
import sys
import time
from dataclasses import dataclass, field

import tree_sitter_bash as tsb
from tree_sitter import Language, Node, Parser

sys.path.insert(0, "/repo")
from tools import shell_reader as sr  # noqa: E402

LANG = Language(tsb.language())
PARSER = Parser(LANG)
TREES: list = []
DYNAMIC = "\x00dynamic"


@dataclass
class ShellAnalysis:
    runs_git: bool = False
    dynamic_commands: list[str] = field(default_factory=list)
    unsupported: list[str] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        if self.runs_git:
            return "GIT"
        if self.unsupported or self.dynamic_commands:
            return "UNKNOWN"
        return "NONE"


def static(node: Node) -> str | None:
    """A word's text as the shell passes it, if no expansion can change it."""
    t = node.type
    text = node.text.decode(errors="replace")
    if t == "word":
        out, i = [], 0
        while i < len(text):
            if text[i] == "\\" and i + 1 < len(text):
                out.append(text[i + 1])
                i += 2
            else:
                out.append(text[i])
                i += 1
        return "".join(out)
    if t == "raw_string":
        return text[1:-1]
    if t == "string":
        if any(c.type not in ("string_content",) for c in node.named_children):
            return None
        return "".join(c.text.decode() for c in node.named_children)
    if t == "ansi_c_string":
        return None
    if t == "concatenation":
        parts = [static(c) for c in node.named_children]
        return None if any(p is None for p in parts) else "".join(parts)  # type: ignore[arg-type]
    if t == "number":
        return text
    return None


def analyse(text: str, depth: int = 0, result: ShellAnalysis | None = None) -> ShellAnalysis:
    result = result or ShellAnalysis()
    if depth > 4:
        result.unsupported.append("depth")
        return result
    # A parser per analysis: a nested parse with a shared parser crashed the binding.
    source = text.encode()
    tree = Parser(LANG).parse(source)
    TREES.append((source, tree))
    _walk(tree.root_node, depth, result)
    return result


def _walk(node: Node, depth: int, result: ShellAnalysis) -> None:
    if node.is_error or node.is_missing:
        result.unsupported.append(f"{node.type}: {node.text.decode(errors='replace')[:40]!r}")
    if node.type == "command":
        _command(node, depth, result)
    if node.type == "redirected_statement":
        _heredocs(node, depth, result)
    for child in node.named_children:
        _walk(child, depth, result)


def _argv(command: Node) -> list[str]:
    argv: list[str] = []
    for child in command.named_children:
        if child.type == "variable_assignment" or child.type.endswith("redirect"):
            continue
        target = child.named_children[0] if child.type == "command_name" else child
        word = static(target)
        argv.append(DYNAMIC if word is None else word)
    return argv


def _command(command: Node, depth: int, result: ShellAnalysis) -> None:
    argv = _argv(command)
    if argv and argv[0] == DYNAMIC:
        result.dynamic_commands.append(command.text.decode(errors="replace")[:60])
        return
    if any(word == DYNAMIC for word in argv) and argv and sr._command_name(argv[0]) in {"eval", *sr._SHELLS}:
        result.dynamic_commands.append(command.text.decode(errors="replace")[:60])
    # The policy is shell_reader's: wrappers, shells' -c, eval, coproc. Its
    # recursion into a command string re-enters this parser-backed reader.
    if sr._runs_git([w if w != DYNAMIC else "_" for w in argv], depth):
        result.runs_git = True


def _heredocs(statement: Node, depth: int, result: ShellAnalysis) -> None:
    body = next((c for c in statement.named_children if c.type == "heredoc_redirect"), None)
    commands = [c for c in statement.named_children if c.type == "command"]
    if body is None or not commands:
        return
    text = "".join(c.text.decode() for c in body.named_children if c.type == "heredoc_body")
    argv = _argv(commands[0])
    if argv and argv[0] != DYNAMIC and sr._reads_stdin(argv):
        analyse(text, depth + 1, result)


def ts_runs_git(text: str, depth: int = 0) -> bool:
    return analyse(text, depth).runs_git


# The parser-backed reader replaces the text-level entry point that the argv policy
# recurses into.
_ADHOC = sr.runs_git
sr.runs_git = ts_runs_git  # type: ignore[assignment]

CORPUS: list[tuple[str, bool]] = [
    ("git status", True), ("sudo git status", True), ("x=1 git status", True),
    ("echo $(git status)", True), ("echo `git status`", True),
    ("echo '`git status`'", False), ("echo \\`git status\\`", False),
    ('echo "\\`git status\\`"', False), ("echo '$(git status)'", False),
    ('echo "$(git status)"', True), ("eval 'git status'", True), ("eval 'echo git'", False),
    ("x=`date` git status", True), ("x=a`date`b git status", True), ("`date` git", False),
    ("echo `date` git", False), ("echo 'see ` lonely' ; x=`git status`", True),
    ("echo 'a\\' ; x=`git status`", True), ("echo \"it's\" ; x=`git status`", True),
    ("echo `echo \\`git status\\``", True),
    ("echo 'abc\ndef`git status`ghi'", False), ("echo 'a\nb; git status'", False),
    ('echo "a\n; git gc"', False), ("echo a\ngit status", True), ("x=1 \\\ngit status", True),
    ("coproc git status", True), ("coproc JOB { git fetch; }", True), ("coproc JOB git fetch", False),
    ("{ git gc; }", True), ("( git gc )", True), ("if true; then git pull; fi", True),
    ("a | git log", True), ("a && git log || b", True), ("! git diff", True),
    ("2>/dev/null git fetch", True), (">out git status", True), ("cat <(git log)", True),
    ("time git status", True), ("exec git gc", True), ("sh -c 'git status'", True),
    ("bash -c \"echo; git fetch\"", True), ("env -S 'git status'", True),
    ("flock /tmp/l git gc", True), ("timeout 5 git fetch", True), ("nice -n 5 git gc", True),
    ("sudo -u git echo ok", False), ("chrt -f 99 grep git", False),
    ("echo git status", False), ("grep git file", False), ("# git status", False),
    ("echo 'git status'", False), ("case x in y) git gc;; esac", True),
    ("f() { git log; }", True), ("[[ -n $(git status) ]]", True),
    ("bash <<EOF\n\"git\" status\nEOF", True), ("cat <<EOF\ngit status\nEOF", False),
    ("bash 2>&1 <<EOF\ngit status\nEOF", True), ("( bash ) <<EOF\ngit log\nEOF", True),
    ("{ cat; } <<EOF\ngit gc\nEOF", False), ("bash 0<<EOF\ngit fetch\nEOF", True),
    ("$GIT status", False), ("cmd=git; $cmd status", False),
]


def compare() -> None:
    rows = []
    for text, expected in CORPUS:
        adhoc = _ADHOC(text)
        a = analyse(text)
        rows.append((text, expected, adhoc, a.runs_git, a.verdict))
    wrong_adhoc = [r for r in rows if r[2] != r[1]]
    wrong_ts = [r for r in rows if r[3] != r[1]]
    print(f"corpus {len(rows)}: ad-hoc wrong {len(wrong_adhoc)}, parser-backed wrong {len(wrong_ts)}")
    for text, expected, adhoc, ts, verdict in rows:
        if adhoc != expected or ts != expected or verdict == "UNKNOWN":
            print(f"  expected={expected!s:5} adhoc={adhoc!s:5} parser={ts!s:5} {verdict:7} {text!r}")


def scan() -> None:
    files = subprocess.run(["git", "-C", "/repo", "ls-files"], capture_output=True, text=True, check=True).stdout.split()
    texts = []
    for name in files:
        try:
            lines = open(f"/repo/{name}", encoding="utf-8").read().split("\n")
        except (UnicodeDecodeError, IsADirectoryError, FileNotFoundError):
            continue
        try:
            found = sr.shell_lines(name, lines)
        except Exception:  # noqa: BLE001
            continue
        for number, (text, *_rest) in found.items():
            texts.append((name, number, text))
    started = time.perf_counter()
    disagree, unknown, errors = [], [], 0
    for name, number, text in texts:
        a = analyse(text)
        adhoc = _ADHOC(text)
        if a.unsupported:
            errors += 1
        if a.verdict == "UNKNOWN":
            unknown.append((name, number, text, a.dynamic_commands, a.unsupported[:1]))
        if adhoc != a.runs_git:
            disagree.append((name, number, text, adhoc, a.runs_git))
    elapsed = time.perf_counter() - started
    print(f"repo surfaces: {len(texts)} shell texts in {len({t[0] for t in texts})} files, parsed in {elapsed:.2f}s")
    print(f"  parse errors: {errors}; UNKNOWN (dynamic or unparsed): {len(unknown)}; ad-hoc vs parser disagree: {len(disagree)}")
    for row in unknown[:25]:
        print("  UNKNOWN", row[0], row[1], repr(row[2][:70]), row[3][:1], row[4])
    for row in disagree[:25]:
        print("  DIFF", row[0], row[1], repr(row[2][:70]), "adhoc", row[3], "parser", row[4])


if __name__ == "__main__":
    compare()
    scan()


def scan_documents() -> None:
    """Each file's shell lines, joined in order, parsed as one script: a run block or
    a RUN instruction keeps its continuation lines together."""
    files = subprocess.run(["git", "-C", "/repo", "ls-files"], capture_output=True, text=True, check=True).stdout.split()
    docs = []
    for name in files:
        try:
            lines = open(f"/repo/{name}", encoding="utf-8").read().split("\n")
            found = sr.shell_lines(name, lines)
        except Exception:  # noqa: BLE001
            continue
        if found:
            docs.append((name, "\n".join(found[n][0] for n in sorted(found))))
    errors, dynamic = [], []
    adhoc_git = parser_git = 0
    for name, text in docs:
        a = analyse(text)
        if a.unsupported:
            errors.append((name, a.unsupported[:2]))
        if a.dynamic_commands:
            dynamic.append((name, a.dynamic_commands[:3]))
        adhoc_git += _ADHOC(text)
        parser_git += a.runs_git
    print(f"documents: {len(docs)}; with a parse error: {len(errors)}; with a dynamic command word: {len(dynamic)}")
    print(f"  documents read as running Git: ad-hoc {adhoc_git}, parser {parser_git}")
    for row in errors:
        print("  ERROR", row)
    for row in dynamic:
        print("  DYNAMIC", row)


if __name__ == "__main__" and "--documents" in sys.argv:
    scan_documents()
