import json, sys
import tree_sitter_bash
from tree_sitter import Language, Parser
LANGUAGE = Language(tree_sitter_bash.language())
TREES = []
count = {"parses": 0}
def walk(source, depth):
    tree = Parser(LANGUAGE).parse(source)
    TREES.append(tree)
    count["parses"] += 1
    stack = [tree.root_node]
    while stack:
        node = stack.pop()
        if node.type in ("command", "redirected_statement", "pipeline", "subshell", "command_substitution") and depth < 3:
            walk(node.text, depth + 1)                     # a nested parse during the walk
            _ = (node.type, node.start_point, node.text, node.parent, node.next_sibling)  # node access after it
        stack.extend(node.children)
for script in json.load(sys.stdin):
    walk(script.encode(), 0)
print(json.dumps(count))
