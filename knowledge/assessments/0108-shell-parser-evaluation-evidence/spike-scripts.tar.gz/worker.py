"""Parser worker: reads a JSON list of scripts on stdin, writes one analysis per script."""
import json, os, signal, sys
exec(open("/spike/evaluate314.py").read().split("ADAPTERS = {")[0])
scripts = json.load(sys.stdin)
if os.environ.get("CRASH"):
    os.kill(os.getpid(), signal.SIGSEGV)
out = []
for s in scripts:
    a = ts_analyse(s)
    out.append({"commands": a.commands, "unsupported": a.unsupported, "stdin": [[argv, body] for argv, body in a.stdin_bodies]})
json.dump(out, sys.stdout)
