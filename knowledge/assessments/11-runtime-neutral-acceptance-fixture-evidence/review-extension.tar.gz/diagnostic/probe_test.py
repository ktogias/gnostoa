"""Disposable review discriminators; not part of the admitted F01-F10 oracle."""

import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(os.environ["REVIEW_FIXTURE"])
OUTPUT = Path(os.environ["REVIEW_RESULTS"])
EXPECTED = {
    "F11": {
        "result": {
            "disposition": "PENDING", "reconciliation": "PENDING",
            "worker_check": "NOT_REQUIRED", "reason": "worker-not-completed",
        },
        "worker_terminal": "failed",
    },
    "F12": {
        "result": {
            "disposition": "PENDING", "reconciliation": "PENDING",
            "worker_check": "OMITTED", "reason": "verification-missing",
        },
        "worker_terminal": "completed",
    },
}


class ReviewProbes(unittest.TestCase):
    def test_additional_conditions(self):
        OUTPUT.mkdir(parents=True, exist_ok=True)
        for case_id, expected in EXPECTED.items():
            for adapter in ("tagged", "batched"):
                with self.subTest(case=case_id, adapter=adapter):
                    result_path = OUTPUT / f"{case_id}-{adapter}.json"
                    command = [
                        sys.executable, str(ROOT / "run_fixture.py"),
                        "--case", case_id, "--adapter", adapter,
                        "--implementation", "candidate", "--output", str(result_path),
                    ]
                    run = subprocess.run(command, capture_output=True, text=True)
                    (OUTPUT / f"{case_id}-{adapter}.runner.stdout").write_text(run.stdout)
                    (OUTPUT / f"{case_id}-{adapter}.runner.stderr").write_text(run.stderr)
                    self.assertEqual(run.returncode, 0, "Infrastructure failure: " + run.stderr)
                    consumed = subprocess.run(
                        [sys.executable, str(ROOT / "read_result.py"), str(result_path)],
                        capture_output=True, text=True,
                    )
                    (OUTPUT / f"{case_id}-{adapter}.reader.stdout").write_text(consumed.stdout)
                    (OUTPUT / f"{case_id}-{adapter}.reader.stderr").write_text(consumed.stderr)
                    self.assertEqual(consumed.returncode, 0, "Reader failure: " + consumed.stderr)
                    actual = json.loads(consumed.stdout)
                    self.assertEqual(actual, json.loads(run.stdout))
                    self.assertEqual(actual["case_id"], case_id)
                    self.assertEqual(actual["adapter"], adapter)
                    self.assertEqual(actual["result"], expected["result"])
                    self.assertEqual(actual["observations"]["worker_terminal"], expected["worker_terminal"])
                    self.assertEqual(actual["observations"]["dispatch_count"], 1)
                    self.assertEqual(actual["observations"]["checks"], [])


if __name__ == "__main__":
    unittest.main()
