"""Reproduce two review mutants without editing the PR checkout."""

import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys

SOURCE = Path("/workspace")
OUTPUT = Path("/review")
FIXTURE = SOURCE / "tests/fixtures/managed_acceptance"
TEST = SOURCE / "tests/test_managed_acceptance_fixture.py"
CORE = (FIXTURE / "candidate.py").read_text()
TERMINAL_GUARD = '''    if services.worker_terminal != "completed":
        return _result("PENDING", "PENDING", worker_check, "worker-not-completed")
'''
SUBSTITUTION_GUARD = '''    if check_plan in {"planned", "finalization"} and (
        case["assigned_checker"] == "supervisor"
        or case["allow_supervisor_substitution"]
    ):
'''
assert CORE.count(TERMINAL_GUARD) == 1
assert CORE.count(SUBSTITUTION_GUARD) == 1
VARIANTS = {
    "original": CORE,
    "M4": CORE.replace(TERMINAL_GUARD, ""),
    "M7": CORE.replace(SUBSTITUTION_GUARD, '    if check_plan in {"planned", "finalization"}:\n'),
}
PROPOSED_CASES = {
    "F11": {
        "description": "Review probe: failed worker despite otherwise acceptance-eligible no-op.",
        "native_streams": {
            "tagged": [
                {"type": "instruction", "operation": "dispatch"},
                {"type": "terminal", "status": "error"},
            ],
            "batched": {"messages": [
                ["work", {"queued": ["followup"]}], ["done", {"exit_code": 1}],
            ]},
        },
    },
    "F12": {
        "description": "Review probe: worker assigned, supervisor substitution forbidden.",
        "assigned_checker": "worker",
        "check_plan": "finalization",
        "allow_supervisor_substitution": False,
    },
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def capture(command, label, env):
    result = subprocess.run(command, env=env, capture_output=True, text=True)
    (OUTPUT / f"{label}.stdout").write_text(result.stdout)
    (OUTPUT / f"{label}.stderr").write_text(result.stderr)
    failures = re.search(r"FAILED \(failures=(\d+)(?:, errors=(\d+))?\)", result.stderr)
    record = {
        "command": command, "returncode": result.returncode,
        "failures": int(failures.group(1)) if failures else 0,
        "errors": int(failures.group(2) or 0) if failures else 0,
        "stderr_sha256": digest(OUTPUT / f"{label}.stderr"),
    }
    (OUTPUT / f"{label}.metadata.json").write_text(json.dumps(record, indent=2) + "\n")
    return record


source_paths = sorted(FIXTURE.glob("*.py")) + sorted(FIXTURE.glob("*.json")) + [TEST]
source_hashes = {str(path.relative_to(SOURCE)): digest(path) for path in source_paths}
retained = OUTPUT / "source-at-ad88768"
retained.mkdir()
for path in source_paths:
    destination = retained / path.relative_to(SOURCE)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)
(OUTPUT / "proposed-case-overrides.json").write_text(json.dumps(PROPOSED_CASES, indent=2) + "\n")
(OUTPUT / "source-hashes.json").write_text(json.dumps(source_hashes, indent=2) + "\n")
summary = {
    "head": "ad88768fc83163850db46eda198bf18f8965cab3",
    "image": "sha256:8255b1b15c12421e3db25a7f209386909dc9afe8d1602a24fde9f71b12b60748",
    "python": platform.python_version(),
    "scope": "Disposable diagnostics only; original frozen F01-F10 oracle and PR source unchanged.",
    "variants": {},
}
for name, core in VARIANTS.items():
    root = OUTPUT / "variants" / name
    variant_fixture = root / "tests/fixtures/managed_acceptance"
    shutil.copytree(FIXTURE, variant_fixture, ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy2(TEST, root / "tests" / TEST.name)
    (variant_fixture / "candidate.py").write_text(core)
    env = dict(os.environ, GNOSTOA_FIXTURE_IMPLEMENTATION="candidate")
    old_oracle = capture(
        [sys.executable, "-m", "unittest", "discover", "-s", str(root / "tests"),
         "-p", TEST.name, "-v"], f"{name}-F01-F10", env,
    )
    assert old_oracle["returncode"] == 0, old_oracle
    inputs = json.loads((variant_fixture / "cases.json").read_text())
    inputs["cases"].update(PROPOSED_CASES)
    (variant_fixture / "cases.json").write_text(json.dumps(inputs, indent=2) + "\n")
    env.update(REVIEW_FIXTURE=str(variant_fixture), REVIEW_RESULTS=str(OUTPUT / "results" / name))
    probes = capture([sys.executable, str(OUTPUT / "probe_test.py"), "-v"], f"{name}-F11-F12", env)
    expected_exit = 0 if name == "original" else 1
    assert probes["returncode"] == expected_exit, probes
    if name != "original":
        assert probes["failures"] == 2 and probes["errors"] == 0, probes
    rows = []
    for case_id in PROPOSED_CASES:
        for adapter in ("tagged", "batched"):
            record = json.loads((OUTPUT / "results" / name / f"{case_id}-{adapter}.json").read_text())
            rows.append({
                "case": case_id, "adapter": adapter, **record["result"],
                "checks": len(record["observations"]["checks"]),
                "dispatch_count": record["observations"]["dispatch_count"],
            })
    summary["variants"][name] = {
        "candidate_sha256": digest(variant_fixture / "candidate.py"),
        "unchanged_F01_F10_oracle": old_oracle,
        "additional_F11_F12_probes": probes,
        "results": rows,
    }
assert source_hashes == {str(path.relative_to(SOURCE)): digest(path) for path in source_paths}
summary["source_unchanged"] = True
(OUTPUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
