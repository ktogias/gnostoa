"""Retain all candidate records from the actual fixture runner and reader."""

import json
from pathlib import Path
import subprocess
import sys

fixture = Path('/workspace/tests/fixtures/managed_acceptance')
output = Path('/evidence')
for case_id in json.loads((fixture / 'cases.json').read_text())['cases']:
    for adapter in ('tagged', 'batched'):
        path = output / f'{case_id}-{adapter}.json'
        runner = subprocess.run([
            sys.executable, str(fixture / 'run_fixture.py'), '--case', case_id,
            '--adapter', adapter, '--implementation', 'candidate', '--output', str(path),
        ], capture_output=True, text=True, check=True)
        consumer = subprocess.run([
            sys.executable, str(fixture / 'read_result.py'), str(path),
        ], capture_output=True, text=True, check=True)
        record = json.loads(consumer.stdout)
        assert record == json.loads(runner.stdout)
        print(consumer.stdout.strip(), flush=True)
