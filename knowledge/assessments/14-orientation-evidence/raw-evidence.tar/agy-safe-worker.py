import json
import subprocess
import sys

assignment = json.load(sys.stdin)
brief = assignment["brief"]
prompt = f"""Perform one independent, text-only acceptance-oracle review of this synthetic public brief for Gnostoa roadmap #14.

Do not use tools, edit files, run commands, create provider effects, or infer human approval. Review only the supplied generic facts and public URLs. Return no more than 10 critical consumer-level acceptance cases, covering false-complete, stale, partial, no-lane, budget, and truthful current-versus-next distinctions. For each give trigger, expected observable result, and why it matters. Then recommend accept, revise, or reject for this proposal brief, with limitations and unknowns. Do not invent private project history, source paths, account facts, or implementation admission.

PUBLIC BRIEF:
---
{brief}
---
"""
argv = ["agy", "--disable-slash-commands", "--model", "gemini-3.8-flash-low", "--mode", "plan", "--print=" + prompt]
result = subprocess.run(argv, text=True, capture_output=True, timeout=240)
sys.stdout.write(result.stdout)
sys.stderr.write(result.stderr)
raise SystemExit(result.returncode)
