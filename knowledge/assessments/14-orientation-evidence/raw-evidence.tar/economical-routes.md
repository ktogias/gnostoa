# Economical agent routes for bounded #14 review

Initial inspection date: 2026-09-11 (Europe/Athens). The initial research
section involved no model call, install, login, account creation, configuration
change, or provider mutation. A later, separately recorded reduced synthetic
brief review did make one native `agy` model call; its capture and limitations
are recorded below.

## Local availability

| Route | Local observation | Consequence |
|---|---|---|
| Antigravity `agy` | `/home/ktogias/.local/bin/agy`, version **1.1.28**. `agy models` succeeded when allowed to use its existing user-level runtime state and listed Gemini 3.8/3.7/3.6 Flash, Gemini 3.1 Pro, Claude 4.6, and GPT-OSS 120B variants. The binary is a stripped ELF (SHA-256 `38f130cdd0757e1d22e151baa48ace4074a5bd3d960eb2dcc7f44bdf2ad4c0fd`); `strings` exposes Google3/Antigravity symbols. Google’s [Antigravity CLI docs](https://antigravity.google/docs/cli/install/) document the `agy` installer/auth route, and the [pricing page](https://antigravity.google/pricing) lists a $0/month individual tier with Gemini Flash/Pro access and basic weekly limits. The local OAuth cache is present but its contents were not read. | This is the immediately available Gemini route. Free access is documented, but actual entitlement/quota and any overage setting remain account state; the cache alone is not proof. Use low Flash and fail closed on quota rather than falling back to credits. Standalone `gemini` is absent. |
| OpenCode | `/home/ktogias/.opencode/bin/opencode`, version **1.18.26**. `opencode auth list` reports one configured **OpenCode Zen** credential; its secret was not read. A current read-only `opencode models opencode --verbose` catalog inspection lists `opencode/big-pickle` with input/output/cache costs all `0`; other catalog models are chargeable. | The exact free model can be explicitly pinned as `opencode run --model opencode/big-pickle "..."` (message is positional per local help). Model cost metadata is zero at inspection time, but account eligibility, quota and gateway behavior remain unknown; no model call was made. Treat this as a qualified research candidate with no fallback, not proof of a no-charge outcome. |
| GitHub Copilot CLI | `/usr/local/bin/copilot`, **1.0.80**. | Installed, but no auth status was queried. A Copilot Free account/login and quota eligibility would still need confirmation. |
| Ollama | No `ollama` executable found. | Local inference would require installation and model downloads; it is a later option, not currently available. |

## Recommended bounded review invocation

Use the existing `agy` OAuth route for a read-only evidence review, with plan
mode and the lowest suitable Flash variant. This particular sandbox invocation was not executed; the later actual reduced-text invocation and its weaker observed controls are recorded below:

```bash
agy --print --mode plan --sandbox \
  --model gemini-3.8-flash-low \
  --add-dir "$PWD" \
  "Review the admitted #14 evidence and roadmap context in this repository. Read files only; do not edit, run mutating commands, create provider effects, or infer approval. Return a bounded list of observations, contradictions, and exact file paths/line references. Stop before proposing implementation outside the admitted scope."
```

If the model catalog changes, use `agy models` and select the lowest-cost
Flash entry that remains adequate. Keep the prompt bounded to the admitted
#14 slice and retain the raw output plus exact `agy` version/model in the
evidence record. `--sandbox` and plan wording reduce mutation risk, but the
owner must still review the command and output semantically.

## Practical alternatives

**Official Gemini CLI.** Gemini CLI is Apache-2.0 and its current README says a
personal Google account has a free allowance of 60 requests/minute and 1,000
requests/day, with Gemini 3 and a 1M-token context. The authentication guide
says Google OAuth credentials are cached locally and that quotas, pricing,
terms, and privacy depend on the authentication method. The official command
would be `gemini --prompt ...` after installing `@google/gemini-cli` and logging
in. It is suitable only if installation/login is separately authorized; the
binary is absent here, and using an API key or Vertex AI can introduce billing.
Sources: [Gemini CLI README](https://github.com/google-gemini/gemini-cli#readme),
[authentication](https://github.com/google-gemini/gemini-cli/blob/main/docs/get-started/authentication.mdx).

**OpenCode Zen free models.** OpenCode is MIT licensed. Its official Zen page
lists temporary free models such as MiMo-V2.5 Free, Nemotron 3 Ultra Free,
Nemotron 3.5 Lightning Free, and Big Pickle, but explicitly describes them as
available for a limited time. The provider guide says Zen requires sign-in,
billing details and an API key; the local auth listing confirms a credential is
already configured, without proving it is free or spend-capped. Candidate
shape (after verifying the current catalog and zero-charge boundary) is:
`opencode run --model opencode/<current-free-model> "..."`.
Do not assume a free model name or fallback: OpenCode says to use the current
catalog, and its docs describe pay-per-request Zen operation. Sources:
[Zen](https://github.com/anomalyco/opencode/blob/dev/packages/web/src/content/docs/zen.mdx),
[providers](https://opencode.ai/docs/providers/),
[models](https://opencode.ai/v2/docs/models).

**GitHub Copilot Free CLI.** GitHub documents Copilot CLI as available on all
Copilot plans, with `/login` required when unauthenticated. Copilot Free is
personal-use with a GitHub AI Credits allowance, 2,000 inline completions per month, limited agents and auto model selection. The earlier 50-premium-request claim is not retained as current: the current official plans page uses AI Credits and the actual account allowance must be observed. `copilot --mode plan -p "..."` is a plausible bounded
review shape, but the installed CLI's account and quota were not inspected.
It requires a GitHub account and may prompt to upgrade at quota exhaustion, so
it is not a guaranteed no-charge route without account-level confirmation.
Sources: [Copilot CLI](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/overview),
[current plans](https://docs.github.com/en/copilot/get-started/plans).

**Ollama local.** Ollama’s server/client is MIT licensed and can run models
locally; official OpenCode docs show a local Ollama provider at
`http://localhost:11434/v1`. A future candidate is
`opencode run --model ollama/<downloaded-model> "..."`, after Ollama
installation, model download, hardware/context measurement, and config. This
has no hosted inference charge but has local compute, storage, and model-license
costs. It is currently unavailable (`command -v ollama` returned no path).
Sources: [Ollama license](https://github.com/ollama/ollama/blob/main/LICENSE),
[OpenCode Ollama provider](https://opencode.ai/docs/providers/).

## Routing recommendation

1. **Exercised #14 text review:** existing `agy` OAuth + requested low Flash and a small public brief; retain raw output. The observed flags did not establish plan-mode/read-only enforcement; qualify controls separately before exposing source-writing tools.
2. **Secondary no-charge candidate:** OpenCode with the explicitly pinned `opencode/big-pickle` entry observed at zero catalog cost; verify account quota at execution time and fail closed on any billing prompt or unavailable model.
3. **Other secondary route:** Copilot Free, only after confirming personal Free eligibility and remaining quota; pin `--max-ai-credits` and plan mode where supported.
4. **Future zero-hosted-cost experiment:** Ollama, after an admitted hardware/model-license and quality measurement.

All free-plan limits, model catalogs, telemetry/privacy terms, and tool behavior
are dynamic. Recheck at execution time and preserve the exact observation.

## Account-budget boundary

The current official account pricing guidance is
[Learn ChatGPT / pricing](https://learn.chatgpt.com/docs/pricing) (checked by the
coordinating agent on 2026-09-11). It describes model roles and token-credit
rates, while the account dashboard remains authoritative for the actual shared
local/cloud allowance. This memo does not infer realized savings from those
rates. Do not silently switch to a paid model or a paid API fallback when a
selected free route is unavailable; fail closed and record the dynamic quota or
authentication reason.

## Actual reduced Gemini oracle review

Three outcomes are retained. The full 34 KB proposal was rejected by
automatic tool review before launch; no native stderr artifact exists for that
tool-layer rejection. The first reduced synthetic-brief attempt launched but
returned code 2 because `--print` consumed the next flag as its prompt. The
corrected invocation then made one native `agy` call using only a 1,263-byte
frozen assignment containing generic #14 contract facts and two public issue
URLs, with requested `gemini-3.8-flash-low`, `--disable-slash-commands`, and no
private history, source paths or account data. Exact native streams and receipt
are retained at:

`/tmp/gnostoa-review-exchange/agy-#14-safe-run2/jobs/gemini-flash-low/`

Receipt SHA-256 fields bind assignment
`05d8dbd3e3da41f043690d66ec0028275d140a3be0223df60ef345112ade2d46`, stdout
`b831b9044e85b554bbc89d6b89622df6d270455c529d2d9be5692e8fa242b450`, and stderr
`3a7f8550106d86abb322e8ed0fb30a0296c0e97c6be03d5a8033b99d16737459`. The
model returned ten cases and recommended **ACCEPT** for the bounded proposal
brief. Its useful oracle coverage includes current/proposed separation, empty
“now”/no-lane, false-complete, stale, partial, conflict, `OVER_BUDGET`, blocker
plus next action, read-only invariants, and human/structured parity. Its stated
limitations are missing exact budget, freshness, tie-breaking and structured
schema definitions. The command’s `--mode plan` had no effect because slash
command expansion was disabled; no tool event trace proves read-only
enforcement, so the no-tools constraint was advisory prompt text only. This is
model evidence only: it is not human approval,
implementation admission, proof of productivity benefit, or proof of account
billing status. The fixture’s plain normalizer rejected the prose as non-JSON,
so `review.json` was not created; raw stdout/stderr and the successful receipt
remain the retained exchange. The actual served model metadata is UNKNOWN; only
the requested model is bound by the command.

The earlier full-proposal attempt was stopped before launch by automatic review.
The exact rejection exists in the tool-layer result, not as a native process
stderr file: sending the 34 KB proposal to authenticated Antigravity/Google was
judged unacceptable without specific payload/destination authorization. No
native process started and no full proposal was transferred. The two reduced
brief attempts are enumerated in the companion oracle record.

## Root qualification of cost, privacy and licensing

The root reopened official current pages on 2026-09-11. [Antigravity pricing](https://antigravity.google/pricing) supports a free individual tier with basic weekly limits, not an unlimited no-billing claim for this account. The installed `agy` binary is used as an external tool; no open-source license or redistribution permission for that binary was established. Official Gemini CLI is a separate Apache-2.0 project. Nothing here vendors either tool.

The [Zen pricing/privacy page](https://opencode.ai/docs/zen/) lists Big Pickle as temporarily free and says data from its free period may be used to improve the model. NVIDIA free endpoints have trial-use and no personal/confidential data restrictions. These terms materially affect routing: public synthetic tasks are candidates; private project data must not be routed merely because inference is free. Model-level zero catalog cost is useful evidence but does not attest account settings, future pricing, or auxiliary requests. No OpenCode inference was attempted in this turn.

The root corrected the stale Copilot request-count claim using the current [plans page](https://docs.github.com/en/copilot/get-started/plans). No new account, subscription, credits, installation or billing-setting change occurred. Tool licenses, hosted-service access terms and licensing of generated/imported code remain separate questions; this research grants no general legal clearance.
