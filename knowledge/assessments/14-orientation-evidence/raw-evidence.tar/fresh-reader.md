Fresh-reader route check (2026-09-11)

I read `README.md`, `AGENTS.md`, and the source-bound compact orientation
`tasks/issue-14-orientation.md` in `/tmp/gnostoa-orientation-14`. To answer the
orientation's routed roadmap/lifecycle facts, I also read
`docs/roadmap.md`, `knowledge/lifecycles/evidence-gated-capability-evolution.md`,
and `tasks/issue-33-c4v0-readiness-predicate.yaml` there. I used no provider,
model, test, or other external context.

Gnostoa is a Git-native toolkit that keeps project knowledge usable by people
and interchangeable agents through structured Markdown/YAML, explicit
authority, deterministic validation, bounded context views, and provider-neutral
governance. Existing capability includes the source/OCI toolkit, task-envelope
projection, context packs, experiment Capsule, acceptance/review fixtures, and
bounded self-hosting evidence. Generic portfolio projection, broad provider
lifecycle control, a thin host dispatcher, protected acceptance, and full Phase
D remain proposed or unperformed.

The selected work is Issue #14 / D14-O1: construct the bounded Gnostoa-self
orientation. Its next action is to verify the exact D14-O1 candidate and prepare
it for owner review. The proposed successor is evaluating #237's component
reuse recommendation after disposition; it is explicitly `PROPOSED` and not
admitted by D14-O1.

The material adoption blocker is that full Phase D has not run and L10
protected-consumer refusal remains open. Task-specific qualification defects
are separate and are not universal blockers. After D14-O1 disposition, return
to adoption by selecting the future task and applying only that task's oracle,
qualification, and launch gates; this orientation is not universally required.
Use suitable economical models for admitted evaluation; do not silently
substitute Astra or a paid fallback, and retain requested/served identity when
known.

The projection was observed/evaluated 2026-09-11 and has 86,400-second
freshness; earliest expiry is 2026-09-12T10:32:08Z. Its local hashes are
locally recomputed, while recorded GitHub/provider observations are explicitly
“recorded-not-authenticated.” Therefore it does not prove live provider truth,
semantic approval, mutation, merge, or readiness. No missing or contradictory
fact was found within the routed materials; provider lifecycle remains
authoritative.
