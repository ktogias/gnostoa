# Economical role routing during #14 D14-O1

Status: observed practice and proposed reuse, not an installed autonomous scheduler.

Current objective: implement the approved compact orientation view under #14. The related actor/tool-routing work belongs to #10/#201; it must not become a new prerequisite for this slice. Main/work selection and next action remain on the #14 admission record.

| Work | Default route | Escalation condition |
|---|---|---|
| Hashes, extraction, formatting, test execution, source comparison | Existing deterministic commands; no inference | A semantic ambiguity remains after inspection |
| Bounded discovery, catalog/availability checks, structured capture | Luna or an explicitly qualified free route | Unsupported conclusions or unresolved source conflict |
| Local implementation of an agreed contract | Terra or another qualified economical coding agent; current Sol agent completes the already-established #14 contract | Cross-cutting semantic ambiguity or repeated meaningful failure |
| Fresh public-contract review / reader exercise | Explicit Gemini Flash through qualified existing auth; no silent alternate provider | Missing capability, unavailable quota or unclear billing stops that route |
| Difficult design/authority review | Sol, with a narrowly scoped task | Root/owner resolves remaining high-level disagreement |
| Exceptional high-level supervision | Astra only where needed; do not duplicate bulk implementation/research there | New use beyond current supervising session must be an explicit choice |

Use one compact assignment per role: exact subject, desired observable result, allowed effects, budget/stop conditions and required output. Do not fork the full conversation merely to delegate extraction or code changes. Distinguish tools/models advertised, locally installed, configured, authenticated and actually exercised; none implies the others.

Do not infer quality from price or count agreement as evidence independence. Preserve each original reviewer recommendation and root disposition. Re-run only affected questions after a changed subject; unchanged evidence can be reused after identity checks. A timeout or absent early receipt is not proof of loss: observe the existing job before launching a duplicate.

Free models and catalogs are mutable. Verify model-level terms and explicit selection before execution; tool license, model/service terms, account entitlement and copied-code licensing are separate. No quota purchase, key-based paid fallback, premium escalation or undocumented subscription proxy. Public project text is the default external review payload; secret/private source is never sent merely because a route is free.

Record attempted/actual model, tool version, auth category, subject/prompt/output identities, execution outcome, local/native usage where available, and UNKNOWN for unobserved billing or internal routing. Token-credit rate comparisons are estimates of relative resource use, not invoices or measured savings. Official Codex guidance: https://learn.chatgpt.com/docs/pricing.

This practice is subject to revision after the observed #14 result. A new broker/orchestrator or generic policy implementation requires its own concrete outcome and admission; this memo does not authorize it.

Observed overhead in this turn: a root documentation search returned an oversized result containing unrelated material; subsequent inspection used targeted page sections. Bound tool output as well as model answers. The team service also refused another independent subagent because the thread limit was reached; the existing agents were reused rather than treating advertised concurrency as available capacity. Neither observation establishes measured cost savings.
