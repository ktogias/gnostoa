# Independent adapter review and mutation replay

Reviewer: `/root/native_oracle`, 2026-09-11. The reviewer authored the independent
oracle before the adapter correction, then reviewed the corrected adapter. This
is independence from adapter implementation authorship, **not** independence from
oracle authorship or human semantic acceptance.

## Reviewed scope and contract

Reviewed the working candidate's `storage.py` native-result branch and
`exchange.py` dispatch registration against Decision 0064 and N02/N03/N05,
primary Claude structured-output documentation, and the independently frozen
oracle. Exact copied source/test identities are retained in each mutation
directory's `source-manifest.json` under
`/tmp/gnostoa-review-exchange-next-prep/mutants/`.

The correction selects a unique result event, requires the success subtype and
literal false error flag, takes its `structured_output`, and then applies the
existing domain checks. The explanatory `result` string cannot supply an absent
structured response. Nonobject streams, malformed results and malformed findings
remain normalization errors for their job. Existing adapters retain their prior
semantics. Dispatch admits the declared new adapter name; no native runtime or
authority claim follows from that allowlist entry.

No adapter defect was found within this bounded contract. The offline oracle
materializes completed synthetic captures and exercises real `collect` and `view`
processes; it does not establish native invocation, real schema generation,
actual successor tool execution, authentication or billing. Those live properties
remain separate N01/N04/N06 evidence.

## Self-found oracle limitation OR1 and disposition

**Original finding:** negative subcases in the first oracle reused a job
directory. After a mutant wrongly collected a response, later subcases could
inherit that `review.json`; the collector correctly skipped rewriting it. The
first mutation failure was real, but subsequent failure counts could overstate
the number of independent discriminating inputs.

**Original reviewer recommendation:** isolate each negative input before quoting
mutation failure counts as separate controls. Severity is a test-diagnostic
limitation, not a corrected-adapter defect.

**Executor disposition: ADDRESSED** within the parent-authorized #235 test scope.
Each negative subcase now initializes a distinct workspace from the same roster.
It does not remove or edit the collector's persisted state, and preserves earlier
observations. `oracle-isolation.diff` retains the exact change.
`oracle-isolation-comparison.json` records an AST comparison proving that removing
the new helper and its four calls restores the previous test AST exactly;
assertions and native input bytes are unchanged. The original frozen oracle,
initial RED, formatted pre-fix oracle, original mutation runs and fresh isolated
runs all remain available. No earlier result was overwritten.

## Actual replay results

Each mutation changed only an isolated fixture copy. The root's adapter and
collector were not mutated. Commands, stdout/stderr, native capture records,
separate view results and exact source snapshots were retained.

| Subject | Seven test methods | Interpretation |
|---|---|---|
| Corrected adapter, original formatted oracle | PASS | Initial independent confirmation |
| M1: remove success-subtype requirement, original oracle | 7 assertion failures, 0 errors | Killed, but later negative-row failures can cascade |
| M2: parse text `result` if structured output is absent/null, original oracle | 5 assertion failures, 0 errors | Killed, same diagnostic limitation |
| Corrected adapter, isolated negative rows | PASS | Final independent confirmation |
| M1, isolated negative rows | **3 assertion failures, 0 errors** | Missing subtype, error subtype, and separate two-job isolation scenario wrongly collect A |
| M2, isolated negative rows | **2 assertion failures, 0 errors** | JSON-only prose and null structured output wrongly collect A |
| Original pre-correction collector, isolated negative rows | **2 assertion failures, 0 errors** | Same two valid-structured-response RED cases as before |

An additional fresh-workspace diagnostic independently exercised all 17 Claude
negative streams against each adapter copy. The corrected adapter rejected all;
M1 accepted only `missing-subtype`/`error-subtype`, and M2 accepted only
`prose-json-only`/`structured-null`. That diagnostic explains the earlier inflated
counts rather than treating them as additional coverage. Its script, output and
full result views are retained as `replay_isolated_inputs.py`, `isolated.*` and
`isolated-input-results.json`.

All failures above are **behavioral assertion failures** after successful CLI
execution: the persisted view contains a collected job that should be pending,
or the old adapter lacks a collected job that should exist. They are not syntax,
import, launch or missing-infrastructure errors. Focused native replay was used
for independent synthetic mutation evidence; the parent executes applicable
container suites before delivery. No model inference or provider action ran.

## Original overall reviewer disposition

**PASS for the bounded corrected adapter and revised consumer oracle.** OR1 is
addressed and verified; no remaining finding was identified within the inspected
scope. Proceed with separately bounded live qualification and handoff evidence.
This review does not claim live success, protected acceptance, general portability
or readiness to merge the eventual whole candidate.
