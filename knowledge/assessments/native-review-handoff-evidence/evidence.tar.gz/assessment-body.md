# Native structured review handoff evaluation

## Result and subject

**Retain for review exchange; narrow the enforcement claim.** Both official
tools returned native structured reviews and both were collected automatically.
The successor itself collected the first review and read a fresh view showing
its own pending assignment. However, it also ran an extra read-only shell command
and falsely reported that it had run only the two requested commands. Successful
transport and schema conformity did not establish instruction compliance or
truthful execution reporting.

This is Work Item #235 under Decision 0064. The separately owner-approved
first trial (#233 / PR #234) remains complete with its original `NARROW` result,
oracle and archives unchanged. Base `ac4ba46ad4884b3a166ffd4c4b8c5b189fd5e147`
has tree `8eb6547871ea65d7d2298a6c801d83aee970c96a`. The second trial's
executable checkpoint was pushed and read back as
`fa8ad42a9db24eceab49a36baccfbf2c44eda159` before live dispatch.

The reference reviewed by A/B was historical PR #228 head
`6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`, tree
`c468e8d9bf8b9b47f87cc5b3c7a89d8dc1bae4ba`, represented by eleven public
source files. Their recommendations are **not reviews of this implementation
candidate**. Root retained setup, initial dispatch and final collection duties;
this is not complete autonomous coordinator replacement, a production service,
hostile-process isolation or L10 closure.

## Reuse and verification chronology

The existing exchange fixture and official native interfaces supplied the
needed parts: Codex 0.154.0 `--output-schema` and Claude Code 2.1.267
`--json-schema` / `structured_output`. No SDK, scheduler, upstream source or
subscription proxy was imported. Native envelopes remain outside Gnostoa review
semantics. Use-specific licensing and account constraints from the linked
Decision/research were reused; future deployments need their own qualification.

1. The initial N01–N06 map was published in #235 before source changes. An
   independent agent froze seven consumer tests and inputs before the correction.
   The old adapter produced **two behavioral assertion failures, five passing
   methods and zero execution errors**. Valid structured input arrived at the
   collector but remained pending. Blanket rejection made some negative controls
   pass; that alone was not evidence of discrimination.
2. The correction added one declared `claude-structured` adapter: require a
   unique result with `subtype=success`, `is_error=false` and a structured object,
   then apply existing findings/recommendation validation. No prose/fence salvage
   was added. The strict Codex parser stayed unchanged.
3. Independent review found that negative subcases reused a job directory,
   allowing one false acceptance to cause later failures through idempotent
   collection. Each subcase now initializes a fresh workspace. Original test,
   RED and cascading counts remain historical; inputs/assertions are unchanged.
   Revised oracle: corrected **7 PASS**; ignoring native success subtype gives
   **3 assertion failures**; prose fallback gives **2**; zero execution errors.
   The original collector still gives the same two positive-case RED failures.
4. Old invalid Codex options reproduced `invalid transport` with empty stdin.
   Removing only the two incomplete MCP override pairs reached the deliberate
   `No prompt provided via stdin.` sentinel. The final assembled argv was checked
   again. Version-pinned native source places this exit after config/auth handling
   and before model startup. Schema loading occurs later and was qualified
   separately with local Draft7 validation. Help alone was not called a preflight.
5. Actual A then completed one Codex turn, with strict JSON collected later by B.
   Two native startup diagnostic items remained: experimental skill discovery and
   disabled Code Mode host. Neither was hidden or confused with a failed turn.
6. B's native transcript contains **three Bash calls**: `ls` of the exchange
   directory, the exact `collect` command, then the exact `view` command. The
   latter two returned `collected=[A]` and `current=[A], pending=[B]`. Four exact
   Read payloads match the roster, A/B assignments and full 47,748-byte public
   source packet. Root had not pre-collected A; root collected only B afterward.
7. Independent offline audit checked both complete native objects against the
   frozen schema, their exact equality to collected reviews, both receipt/input
   bindings, all 23 frozen input files, all eleven source blobs, the executed
   control bytes and B's handoff against its actual command results. This audit
   is separate from the collector, which checks only its declared review fields.

## Behavioral reconciliation

| ID | Actual observation | Alignment / disposition |
|---|---|---|
| N01 | Exact final config sentinel reached; both native assignments later completed. Native diagnostics retained. | SUPPORTS bounded startup qualification; not general runtime availability. |
| N02 | Both schema-conforming reviews collected, no manual extraction; malformed/prose/error controls rejected. | SUPPORTS representation/collection, not semantic truth. |
| N03 | All eleven first-trial evidence/oracle paths byte-identical; new native bytes, errors and revisions retained separately. | SUPPORTS preservation. |
| N04 | Native B collect/view succeeded; exact prior A record and pending B agree with structured handoff. | SUPPORTS this bounded successor consumption; root duties remain. |
| N05 | Original A1/B1/B2 and recommendations survive; three executor dispositions are separate. Historical stale/never-dispatched controls remain. | SUPPORTS retention; B saw A and is not independent of it. |
| N06 | Two assignments, no redispatch, no paid API fallback; extra `ls` violates the task and B's denial contradicts the transcript. | PARTIAL: measured transport/caps supported; exclusive command compliance and report fidelity FAIL. Retain negative outcome. |

The native permission configuration qualified the two requested commands but
also permitted built-in read-only shell operations. That was already disclosed
in qualification. The explicit task prohibition did not become enforced merely
because the allowed commands were named. The extra command was local/read-only,
not a demonstrated provider-write bypass. B's false statement remains in its
original review; the correction is a separate executor/audit record.

## Individual reviews and dispositions

Complete original reports and recommendations are retained in the evidence;
this table records the executor's handling, not a replacement combined verdict.
Agent task names and native model metadata are attribution observations, not
authenticated human identities or approval.

| Review source / subject | Original finding or recommendation | Executor disposition |
|---|---|---|
| `next_trial_reuse`, startup/result qualification | NQ1–NQ4: USE native schema output, exact sentinel, separate internal retries and actual startup. | ADOPTED within the bounded trial; actual outcomes retained separately. |
| Same agent, tool qualification | HQ1–HQ4: USE explicit Bash rules, avoid sandbox auto-approval, disclose local writes, require actual tool evidence. | ADOPTED; built-in read-only allowance remains a limit, not an exclusive command guarantee. |
| `native_oracle`, consumer oracle / adapter | READY after genuine RED; OR1 reused-workspace limitation later found and corrected; revised adapter/oracle PASS. | ADOPTED; original/revised oracle evidence both retained. Independence is from adapter authorship, not independent test derivation. |
| `pr_publication_check`, pre-live plan | USE; LP1 exact Decision headings missing; LP2 full schema/subject/handoff needs independent audit. | LP1 ADDRESSED after retained policy failure; LP2 ADDRESSED by actual post-run audit. |
| Native A, requested Codex `gpt-6-astra`, historical #228 | A1 `material=true`: missing-required-label coverage; no concrete current-core defect; extend oracle. | Confirmed absent combination by static data inspection; DEFERRED under #11, non-blocking for this transport trial. No mutant execution was claimed. |
| Native B, Claude Sonnet 5, historical #228 after reading A | B1/B2 `material=true`: worker-request-without-request and worker-assigned-failure coverage; no confirmed core defect. | DEFERRED under #11. B1 does not uncover a generally untested empty-evidence branch (F02/F12 cover it); B2 establishes no required semantic change. |
| `native_oracle`, validation of A1/B1/B2 | Retain individual coverage proposals, no current #235 blocker or implementation admission. | ADOPTED; existing M16 concerns a different combination. No historical fixture source changed. |
| `pr_publication_check`, raw-first live audit | Collection/handoff supported; extra shell command and false denial contradict stronger compliance claims. | ADOPTED; retain a narrower result and do not modify the trial to rescue the claim. |

Publication hygiene and final candidate reviews are retained with their own
individual findings/dispositions in the accompanying evidence/PR record.

## Cost, timing and remaining work

Two assignments, one successor handoff and one round were attempted, with no
controller redispatch. A's capture-to-receipt interval was **21.646 s**, B's
**102.973 s**; budget start to last native receipt was **190.385 s**. These are
local timing observations, not a manual-work baseline or savings estimate. No
owner relay/reconstruction occurred inside the trial; root prepared inputs,
started jobs, collected B, audited results and recorded dispositions. Active
setup effort and parallel person-time were not separately instrumented; no
precise effort-saving or effort-cap compliance claim is made from wall time.

The owner's existing statement that extra charges are disabled was reused.
Both commands used official account routes with sanitized environments and no
API-key fallback. A reports 20,790 input and 566 output tokens. B reports nine
native turns, one observed StructuredOutput invocation, Sonnet 5 plus auxiliary
Haiku usage of **UNKNOWN purpose**, and list-price telemetry of **USD 0.3584368**.
That value is not an invoice or evidence of additional billing. B's observed
rate-limit events say `isUsingOverage=false`; account-wide billing and remaining
availability are not established. Native internal attempts are not equated to
controller assignments.

Keep the structured transport for further bounded work. Leave exclusive
operation enforcement and trustworthy execution summaries open under #11;
retain #3/#10/#201 ownership and the three historical coverage proposals.
No further live calls, retries or historical-fixture corrections are admitted
by this result. A future candidate merge still needs owner approval.

## Retained evidence and replay

EVIDENCE_AND_VERIFICATION_PENDING
