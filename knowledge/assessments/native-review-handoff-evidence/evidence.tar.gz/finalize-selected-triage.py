from pathlib import Path
import hashlib,json,collections,re
from detect_secrets.core import scan
from detect_secrets.settings import default_settings
r=Path('/tmp/gnostoa-review-exchange-next-prep');out=r/'hygiene-output';v=json.loads((out/'publication-triage-initial.json').read_text());cache={}
with default_settings() as s:
 s.disable_filters('detect_secrets.filters.allowlist.is_line_allowlisted')
 for x in v['records']:
  if x['category']!='UNRESOLVED':continue
  name=x['path']
  if name not in cache:cache[name]={z.secret_hash:z.secret_value for z in scan.scan_file(str(r/name))}
  value=cache[name].get(x['scanner_hash']);x['exact_value_reidentified']=value is not None;x['candidate_length']=len(value) if value else None
  if value and value.startswith(('/tmp/gnostoa-review-exchange-next-prep/','/evidence/')) and name.endswith('.json'):
   data=json.loads((r/name).read_text())
   if value.rstrip('\\') in data.get('argv',[]):x.update(category='synthetic-test-argv-path',rationale='Exact detected value is a local controlled-test path in retained argv array; no credential syntax')
  elif value=='GNOSTOA_QUALITY_OUTPUT=/evidence/quality':x.update(category='container-output-path-setting',rationale='Exact public quality-output environment setting, not a credential')
v['classification_counts']=dict(collections.Counter(x['category'] for x in v['records']));v['unresolved_count']=sum(x['category']=='UNRESOLVED' for x in v['records']);(out/'publication-triage.json').write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');print(json.dumps({k:a for k,a in v.items() if k!='records'}))
print('unresolved sample',json.dumps([x for x in v['records'] if x['category']=='UNRESOLVED'][:8]))
