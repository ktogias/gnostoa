from pathlib import Path
from detect_secrets.core import scan
from detect_secrets.settings import default_settings
import collections,hashlib,json,re
root=Path('/tmp/gnostoa-review-exchange-next-prep');all_digests=set()
for name in ['evidence-selection.json','evidence-final-delta.json']:
 all_digests.update(x['sha256'] for x in json.loads((root/name).read_text()).values())
with default_settings() as settings:
 settings.disable_filters('detect_secrets.filters.allowlist.is_line_allowlisted')
 v=json.loads((root/'hygiene-output/publication-triage.json').read_text());cache={}
 for x in v['records']:
  if x['category']!='UNRESOLVED':continue
  p=root/x['path']
  if p not in cache:cache[p]={z.secret_hash:z.secret_value for z in scan.scan_file(str(p))}
  value=cache[p].get(x['scanner_hash'])
  if value and value.startswith(('/tmp/gnostoa-review-exchange-next-prep/','/evidence/')) and x['path']=='mutants/isolated-input-results.json':x.update(category='synthetic-mutation-log-path',rationale='Exact local controlled-test path in retained mutant argv record',exact_value_reidentified=True)
 v['classification_counts']=dict(collections.Counter(x['category'] for x in v['records']));v['unresolved_count']=sum(x['category']=='UNRESOLVED' for x in v['records']);(root/'hygiene-output/publication-triage.json').write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');print('original',v['classification_counts'])
 for base,outdir in [(root,root/'hygiene-delta-output'),(root/'hygiene-inner-input',root/'hygiene-inner-output')]:
  sc=json.loads((outdir/'publication-secret-scan.json').read_text());records=[]
  for name,findings in sc['results'].items():
   p=base/name;lines=p.read_text().splitlines();values={z.secret_hash:z.secret_value for z in scan.scan_file(str(p))}
   for f in findings:
    value=values.get(f['hashed_secret']);n=f['line_number'];context=' '.join(lines[max(0,n-2):n+1]);cat='UNRESOLVED';reason='Needs exact context review'
    if value in all_digests:cat='recomputed-selected-file-sha256';reason='Exact value equals independently rehashed selected input'
    elif value and re.fullmatch('[a-fA-F0-9]{64}',value) and any(t in context.lower() for t in ['sha256','sha-256','digest']):cat='declared-artifact-or-evidence-digest';reason='Explicit SHA-256 artifact/evidence field, not credential syntax'
    elif value and re.fullmatch('[a-fA-F0-9]{40}',value) and any(t in context.lower() for t in ['commit','tree','head','revision']):cat='declared-git-reference';reason='Explicit Git revision identity, not a credential'
    elif value=='GNOSTOA_QUALITY_OUTPUT=/evidence/quality':cat='container-output-path-setting';reason='Exact output location, not a credential'
    elif value and value.startswith('KNOWLEDGE_KIT_REVISION=') and re.fullmatch('[0-9a-f]{40}',value.split('=',1)[1]):cat='container-revision-setting';reason='Exact Git revision environment binding, not a credential'
    elif name.endswith('CACHEDIR.TAG') and value=='8a477f597d28d172789f06886806bc55':cat='standard-cache-directory-tag';reason='Generated cache marker; file excluded from final publication anyway'
    records.append({'path':name,'line':n,'type':f['type'],'scanner_hash':f['hashed_secret'],'exact_value_reidentified':value is not None,'candidate_length':len(value) if value else None,'category':cat,'rationale':reason})
  report={'occurrences':len(records),'classification_counts':dict(collections.Counter(x['category'] for x in records)),'unresolved_count':sum(x['category']=='UNRESOLVED' for x in records),'records':records};(outdir/'publication-triage.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(outdir.name,json.dumps({k:v for k,v in report.items() if k!='records'}));print('unresolved',json.dumps([x for x in records if x['category']=='UNRESOLVED'][:10]))
