# Claude's native tool route for real exchange continuation

Date: 2026-09-11. Reviewer: `/root/next_trial_reuse`.
Subject: #235 job B, reviewer and replacement coordinator. No model invocation,
credential read, provider write, or repository edit occurred in this qualification.

**Recommendation: USE an explicitly restored Bash tool with two exact command
allow rules for the existing exchange CLI, plus Read/Glob/Grep.** This can test
actual continuation through `collect` and `view`, rather than only reading a
coordinator-authored snapshot. Live permission success remains untested.

## Installed semantics and the smallest proposed changes

Claude Code 2.1.267 help says `--restricted` removes command-running tools unless
individually named in `--tools`. It is therefore compatible with explicit
`--tools Read,Glob,Grep,Bash`; `--tools default` is not the substitute. Restricted
mode fences built-in file tools, rejects bypassPermissions and ignores ordinary
settings; it does not impose an unconditional read-only Bash policy. Safe mode
keeps builtin tools and ordinary permissions. Both still respect managed policy.
Official docs also identify managed-hook exceptions, so neither flag alone
proves the absence of all startup effects. Keep the existing explicit hook
restriction and inspect native observations.
[CLI reference](https://code.claude.com/docs/en/cli-reference).

Retain the already qualified safe/restricted flags, explicit first-party model,
empty setting sources, `dontAsk`, `--permission-prompts none`, strict empty MCP,
no Chrome/custom commands, no fallback, and sanitized environment. Add Bash to
`--tools`. Replace only the allowlist with the following argument-array segment,
after replacing both uppercase placeholders with concrete absolute paths:

```python
[
    "--tools", "Read,Glob,Grep,Bash",
    "--allowedTools",
    "Read", "Glob", "Grep",
    "Bash(/usr/bin/python3 -B EXACT_FIXTURE_PATH/exchange.py --workspace EXACT_EXCHANGE_PATH collect)",
    "Bash(/usr/bin/python3 -B EXACT_FIXTURE_PATH/exchange.py --workspace EXACT_EXCHANGE_PATH view)",
]
```

There is no trailing wildcard, generic `Bash` allow, directory-changing prefix,
redirect, shell expansion or wrapper in these two rules. Give B exactly the same
two concrete command strings. Use two separate foreground Bash invocations so
the native record shows each result. `-B` prevents incidental Python bytecode
writes; it does not restrict what the Python program can do. Do not use `-I`
without changing imports: the existing fixture imports sibling modules.

In the existing `--settings` object add:

```json
{"sandbox":{"autoAllowBashIfSandboxed":false}}
```

Merge this key into that object; do not replace its auth/model/hook controls.
This preserves any existing sandbox while requiring the normal permission
check for sandboxed commands. It does not enable a sandbox where none exists.
The official sandbox describes separate filesystem/network restrictions, whose
actual host availability has not been tested here.
[Sandbox configuration](https://code.claude.com/docs/en/sandboxing).

Permission rules match command text; exact rules permit these forms. Native
compound-command handling checks individual subcommands. Deny/ask rules take
precedence over allow, so do not add `Bash(*)` deny/ask as a purported default
with exceptions: it would block the selected commands. `dontAsk` denies other
unapproved calls, but builtin read-only shell commands remain implicitly
available. Therefore this is not a claim that exactly two Bash commands can ever
run. Command-text rules are not an OS isolation boundary, and managed rules can
still refuse either command.
[Permission semantics](https://code.claude.com/docs/en/permissions).

## What the two commands actually do

Inspection of the existing fixture shows `collect` verifies persisted receipts
and native output hashes, then writes `review.json` or `normalization-error.json`
inside the exchange job directories. It does not launch a worker. `view` uses
the frozen roster and current records; the shared CLI opens its local `.lock`
for both commands. These are **local exchange effects**, so the job must not be
described as wholly read-only. Neither selected operation makes provider calls
or writes GitHub in the inspected fixture. Keep dispatch/revise/disposition/init
outside B's granted command forms.

Place the curated source, pinned fixture/imports and exchange state under one
trial working root. This avoids an accidental write outside an enabled native
sandbox's working directory. Grant no additional project or home directory.
The actual exchange and interpreter must be usable under the enclosing process
permissions. Pin the executed script and imported files to their inspected
bytes; remove ambient `PYTHONPATH`, `PYTHONHOME`, and
`GNOSTOA_EXCHANGE_IMPLEMENTATION` through the existing environment allowlist.
A full Python allow rule with a mutable script/import path would not preserve
the intended effect boundary. Hostile mutation/isolation is outside this trial.

## Required evidence and fail-closed boundary

Capture native initialization (Bash present; expected MCP/plugins/model), both
Bash tool inputs/results and exit status, and the resulting on-disk exchange
records. Require B to collect A and then read the fresh view while B's own
assignment remains pending; it cannot collect its own unfinished response.
Its final structured handoff must agree with that view, preserving unanswered
or stale work. A claim in prose that it ran the commands is insufficient.

If a managed rule, shell restriction, sandbox, missing executable or permission
check denies execution, retain the refusal and mark the continuation
unestablished. Do not silently relax the rule, add broad Bash permission or have
the root execute it and call that B's continuation. Installed help and docs
qualify the proposed route, not a completed permission-engine test.

## Original findings and recommendation

| ID | Finding | Reviewer recommendation |
|---|---|---|
| HQ1 | Restricted mode permits individually named Bash; the old Read-only tool set cannot perform collect. | Add explicit Bash and two exact command rules. |
| HQ2 | Native sandbox auto-approval could broaden effective Bash permission. | Set autoAllowBashIfSandboxed=false without disabling sandbox. |
| HQ3 | collect writes normalized local state; even view opens a lock. | Describe bounded local effects, not wholly read-only execution. |
| HQ4 | Native reads/claims alone do not establish coordinator action. | Require actual Bash calls/results and updated exchange state. |

Overall disposition: **USE this bounded proposal, with actual native execution
and continuation still to be measured.** Root records executor dispositions.
