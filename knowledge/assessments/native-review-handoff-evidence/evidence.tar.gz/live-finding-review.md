# Validation of live review findings A1, B1 and B2

Reviewer: `/root/native_oracle`, 2026-09-11. Subject: the retained public-source
packet for historical PR #228 head
`6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`.

The original A/B review objects were read from the exchange's persisted
`jobs/A/review.json` and `jobs/B/review.json`. The reviewer separately read the
historical core, services, input cases, output oracle, runner and assessment.
`live-finding-review-evidence.json` retains exact source/review hashes, complete
original review objects and a static expansion of all twelve cases. This is
source/data validation, **not** independent execution of their historical tests
or mutants. No historical fixture changes, model calls or provider writes occurred.

## Provenance and original dispositions

A reports a static source review with tests **NOT RUN**, one material finding
`A1`, no concrete corrected-core defect and a recommendation to extend the oracle
for missing required labels while retaining historical bounds.

B reports that it ran the two exchange commands and separately performed static
source review, with historical tests **NOT RUN**. It reports material findings
`B1` and `B2`, no concrete corrected-core defect and recommends extending the
oracle if these combinations are selected as in scope. This review validates
the source claims; the parent separately checks native tool-call evidence for
B's reported command execution.

B saw A's original review through the exchange. Its description of its additions
as independent does not establish reviewer or evidence independence from A.
Keep A and B as separate original reports, but do not count their agreement as
independent corroboration. All three original `material: true` flags remain
unchanged; the following proposed executor dispositions are separate judgements.

## A1: missing required label

**Original claim and recommendation:** all cases retain the required `bug`
label; F09 tests the forbidden `roadmap:now` label only. Add an empty-label case
that requires a false label match and REFUSED disposition/reconciliation.

**Independent validation:** confirmed as a coverage gap. The common input has
`required_present=["bug"]`, all twelve expanded cases include `bug`, and F09's
only target override adds `roadmap:now`. The service uses a conjunction of
required-presence and forbidden-absence conditions. Thus replacing its
required-presence condition with true cannot alter that predicate for the
existing inputs. This is a static data argument, not a replayed mutant result.
The current predicate would reject the proposed missing-label snapshot; no
current implementation defect was identified.

**Proposed executor disposition: CONFIRMED, DEFERRED coverage extension under
#11; non-blocking for #235.** The extension is useful before relying on the
fixture for both directions of label contradiction, but does not invalidate the
historical twelve measured rows. Freeze the new expectation and demonstrate the
required-presence mutant only after a separately selected fixture extension.

## B1: worker-request plan without a request event

**Original claim and recommendation:** no case uses a worker-request check plan
without an actual check request; add that combination and expect
PENDING/PENDING with worker_check OMITTED.

**Independent validation:** the missing combination is confirmed. F06 is the
only worker-request-plan case, and both its native adapters include a request.
The current core adds worker-request evidence only on that observed event; with
the proposed completed stream lacking it, no planned/finalization check applies
and the existing empty-evidence guard returns pending. Complete invocation
observation with worker assignment then gives OMITTED.

The stronger interpretation that the no-evidence rejection path is generally
untested is unsupported: F02 and F12 already assert pending results with empty
checks. B1 extends the interaction between plan and event absence, rather than
discovering a wholly uncovered rejection branch or a current core defect.

**Proposed executor disposition: CONFIRMED combination gap, DEFERRED under #11;
non-blocking for #235.** Retain B's original material flag, while recording this
narrower executor assessment. A later admission may select the combination if
the fixture will be used to substantiate worker-request plans specifically.

## B2: failed worker assigned to checking

**Original claim and recommendation:** OMITTED can be returned for a failed
worker with complete observations and no request, but F11 assigns the supervisor.
Select and test the intended attribution if this combination matters downstream.

**Independent validation:** the absent combination is confirmed. F11 is the only
failed-terminal case; it inherits supervisor assignment and expects NOT_REQUIRED.
The current `_worker_check` requires an actual started worker, no observed
request, worker assignment, complete invocation observation and a known terminal
before returning OMITTED. It does not require successful termination. The outer
core independently refuses to accept failed completion and returns
PENDING/PENDING with reason `worker-not-completed`.

No ambiguous code path or wrong acceptance is established. With the supplied
complete-observation assumption, absence of the request remains an observed fact
even when the worker fails. OMITTED does not by itself prove intent, fault or why
the request was absent. If downstream use would attach such stronger meaning,
that semantic contract must first be selected instead of deriving it from the
current implementation or this review's suggested test.

**Proposed executor disposition: CONFIRMED untested combination; no requirement
to change its attribution semantics established; DEFERRED under #11 and
non-blocking for #235.**
Preserve B's original ambiguity/materiality wording separately. Any new oracle
row requires explicit intended attribution, not automatic endorsement of the
current string as the universal correct answer.

## Existing ownership and overall disposition

The existing [M16 follow-up](https://github.com/ktogias/gnostoa/issues/11#issuecomment-5619928995)
was read directly. It concerns **supervisor assignment with an observed worker
request**, including a separate request obligation. It does not duplicate A1,
B1 or B2. All can remain under the existing #11 fixture-coverage ownership with
their distinct predicates and future admission conditions; do not create another
mechanism or imply that merely touching this fixture admits every retained gap.

**Overall recommendation: retain all original findings and individual
recommendations; record the three proposed deferred dispositions; continue the
bounded #235 exchange evaluation.** These reviews provide useful coverage
observations but do not require changing the historical fixture inside a review
transport experiment. This disposition does not close L10, approve a merge or
admit implementation of A1/B1/B2.
