# Independent static live-plan review — #235 / Decision 0064

Reviewer: session agent `/root/pr_publication_check`; not authenticated model identity.
Date: 2026-09-11.
Scope: prospective second-trial plan under `/tmp/gnostoa-review-exchange-next-prep/live-run`, current Decision 0064, work item, reuse qualification and handoff-tool qualification. No live/model calls, provider writes or source changes were made by this reviewer.

## Original findings and recommendation

**Recommendation: USE the bounded live plan with the acceptance-observation condition below; CORRECT the Decision headings before the bundle/publication gate.** This is static qualification, not evidence of successful native startup, native permissions or exchange.

| ID | Concrete observation | Original recommendation |
| --- | --- | --- |
| LP1 | Decision 0064 has `Context and authority`, `Reuse and decision`, `Verification and consequences`. The active core profile requires exact sections `Context`, `Decision`, `Consequences`, and validate_bundle compares required headings. This is the same class of documentary gate mismatch retained in #233. | Correct the headings before final bundle validation; no content or runtime expansion is needed. This is not itself evidence that a live route is unsafe. |
| LP2 | The copied collector/normalizer validates native success plus the existing findings/recommendation contract. It does not locally enforce all newly requested schema fields, subject_commit equality, inspected-path membership or handoff arrays against actual state. Native output-schema requests do not independently establish those semantics. | As a required post-run assessment, validate the actual native object against the frozen schema and independently reconcile subject/paths/roster/collect/view/native command results before claiming N02/N04 success. Do not describe the existing collector as a complete schema/subject validator, and do not manually repair or inject output to rescue this run. No parser broadening is recommended. |

Executor dispositions remain for root to record separately.

## Reproduced static bindings

A read-only Python inspection reproduced:

- All **23** current frozen files match `live-input-manifest.json` byte lengths and SHA-256; zero mismatches.
- Roster contains exactly A/B, with separate assignment locators, independent of dispatch records.
- A and B carry the identical published subject: PR #228, commit `6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`, tree `c468e8d9bf8b9b47f87cc5b3c7a89d8dc1bae4ba`.
- All **11** source-packet texts and public ordinary-file copies are byte-identical to their Git blobs at that historical commit. The packet itself preserves the previous trial's public subject.
- All five copied control/schema files match the currently inspected source bytes: exchange.py, storage.py, candidate.py, worker_capture.py and native-review.schema.json.
- The live exchange workspace did not exist when inspected. No live job had been dispatched. Before dispatch, initialize from this exact roster and verify copied assignments/active digests; the preparation manifest alone is not evidence that registration already occurred.
- Each spec uses a 900-second deadline. Two sequential deadlines fit inside 45 minutes, but root must track total live wall-clock time including intervening preparation, rather than treating per-worker deadlines as the full experiment clock.

## Invocation, account and limits

A invokes the version-pinned official Codex path, requested `gpt-6-astra`, `exec --json`, `--output-schema` bound to the copied schema, read-only sandbox, forced ChatGPT login and OpenAI provider. The two incomplete synthesized MCP entries from #233 are absent. Ordinary user configuration is ignored; strict config and explicit feature restrictions are present. This review did not execute the no-model sentinel. Root's pending exact final-argv/cwd/environment sentinel and separate schema validation remain prerequisites; the sentinel does not validate native schema acceptance or next-call availability.

B invokes the version-pinned official Claude path with requested `claude-sonnet-5`, native `--json-schema` object identical to the common schema, stream-json output, safe/restricted settings, forced claude.ai login, no configured fallback, empty MCP, disabled hooks/slash commands/Chrome and noninteractive permission denial. Explicit safe/restricted flag presence is not proof of every effective managed-policy capability; native initialization and tool results must be retained.

Both argv arrays begin with `/usr/bin/env -i` and a finite environment list. No API-key/provider endpoint override, PYTHONPATH, PYTHONHOME or GNOSTOA_EXCHANGE_IMPLEMENTATION is passed. Existing HOME/auth remains available by design; no credential file was read or copied in this review. Owner disabled-extra-charge evidence is copied with its original timestamp and limited claim, not fabricated as a fresh billing read-back. Same-day account qualification is explicitly reused. Remaining quota, account-wide costs and any internal native retry/auxiliary-model activity remain unmeasured until reported by actual native records.

The command plans contain two assignments and no re-dispatch loop. Existing dispatch refuses a pre-existing job directory. The fixture does not by itself enforce the global trial-round/cost limit against an operator creating another workspace; root must preserve the admitted two-job/no-retry scope. No automatic API-paid fallback is configured.

## B's actual permitted local effects

The B assignment's two exact commands match the two explicit Bash allow rules:

1. `/usr/bin/python3 -B /tmp/gnostoa-review-exchange-next-prep/live-run/control/exchange.py --workspace /tmp/gnostoa-review-exchange-next-prep/live-run/exchange collect`
2. The same command ending in `view`.

Read/Glob/Grep and Bash are explicitly exposed; there is no wildcard Python/Bash allow rule, dispatch/revise/disposition/init command or shell redirection in these granted forms. `sandbox.autoAllowBashIfSandboxed=false` is present.

The inspected collect command reads receipts/native hashes, normalizes completed captures and writes review.json or normalization-error.json atomically. Shared CLI startup creates/opens the workspace lock; view reads active/roster/original/disposition state. These are bounded **local exchange writes**, not wholly read-only work. The inspected selected paths perform no network/provider operation and do not launch another worker. The absence of broad explicit allow rules is not an OS isolation proof or proof that no implicit read-only shell command can be permitted by Claude.

Keep copied interpreter/import/control bytes fixed during the live run, and retain a post-run identity comparison. If a managed permission or sandbox refuses either command, preserve that refusal; do not silently grant broader Bash or have root run the command and attribute it to B.

## What would support N04

- A's terminal receipt exists before B is started. Root may observe it, but should not pre-collect A if the chosen observation is that B itself performs the collection.
- Native B evidence shows two actual foreground Bash invocations in order with the specified command strings and successful outputs, not merely a final claim.
- The first command's collected list and the second command's original records/current/pending IDs agree with durable state. B should remain pending while its own process has no terminal receipt.
- Original A response/recommendation and any missing/stale/unresolved result survive. B's exposure to A is explicitly disclosed; it is not an independent review of A's source.
- B's structured subject and handoff report agree with those observations. On refusal/unavailable state, limitations/execution must explicitly mark UNKNOWN; empty arrays must not be interpreted as a proven empty population.
- Root's setup, A/B launches and final B collection are counted separately. Even a successful run supports tool-driven continuation by a fresh successor, not fully autonomous coordinator replacement, general runtime portability or L10 enforcement.

The common schema requires findings, recommendation, subject_commit, inspected_paths, execution, limitations and all four handoff arrays, with additionalProperties false at its declared object levels. Findings preserve id/text/material. It specifies representation; exact identity, completeness, truth and recommendation remain separate checks.

## Public-retention hygiene considerations

Inputs currently consist of public historical source, operator command configuration, an owner settings statement and local paths/session identifiers. This plan does not establish that future native output is publishable. Retain original stdout/stderr before normalization, then inspect actual extracted inputs for credentials, ambient metadata, opaque provider signatures, unexpected personal data and source disclosure before publication. Native stack errors or tool results may disclose more than the prepared prompt. Distinguish scanner candidates from confirmed secrets and opaque bytes from decoded-content assurance.

Retain original source/reviews and separate executor dispositions, no silent normalization repair, and preserve all #233 archives unchanged. Output and failure records should bind exact copied control/schema/input hashes, observed models/tools, timing and native usage; one assignment is not one inference request. No publication or merge authority is inferred from this reviewer recommendation.

