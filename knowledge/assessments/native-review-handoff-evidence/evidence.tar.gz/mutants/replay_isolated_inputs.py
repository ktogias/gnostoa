"""Diagnose mutant discrimination with fresh persisted state for every input."""

import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = (
    "prose-json-only", "prose-fenced-only", "structured-null", "structured-string",
    "structured-array", "missing-result", "missing-subtype", "error-subtype",
    "error-true", "missing-error-flag", "duplicate-result", "nonobject-event",
    "missing-findings", "bad-recommendation", "duplicate-finding",
    "nonboolean-material", "missing-finding-text",
)
summary = {}
for implementation in ("corrected", "M1-ignore-success-subtype", "M2-fallback-to-result-text"):
    snapshot = ROOT / implementation
    os.environ["GNOSTOA_EXCHANGE_FIXTURE_ROOT"] = str(snapshot / "tests/fixtures/review_exchange")
    os.environ["GNOSTOA_NATIVE_EXCHANGE_EVIDENCE"] = str(snapshot / "isolated-calls")
    spec = importlib.util.spec_from_file_location("native_oracle", snapshot / "tests/test_native_review_exchange.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    cls = module.NativeReviewExchangeTests
    cls.setUpClass()
    rows = []
    for name in CASES:
        test = cls("test_N02_structured_review_wins_over_conflicting_prose")
        test.setUp()
        row = {"input": name, "workspace": str(test.workspace)}
        try:
            test.captured("A", name)
            test.cli("collect")
            row["actual"] = test.cli("view")
            test.assert_rejected("A")
            row["outcome"] = "PASS"
        except AssertionError as exc:
            row["outcome"] = "BEHAVIORAL_FAIL"
            row["assertion"] = str(exc)
        except Exception as exc:
            row["outcome"] = "INFRASTRUCTURE_ERROR"
            row["error"] = repr(exc)
        finally:
            test.doCleanups()
        rows.append(row)
    summary[implementation] = rows
    print(implementation, [(r["input"], r["outcome"]) for r in rows if r["outcome"] != "PASS"])
(ROOT / "isolated-input-results.json").write_text(json.dumps(summary, indent=2) + "\n")
