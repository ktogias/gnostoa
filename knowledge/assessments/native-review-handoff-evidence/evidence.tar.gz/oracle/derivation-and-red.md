# Independent native-result oracle and initial RED

Author: `/root/native_oracle`. Scope: Work Item #235, Decision 0064, principally
N02/N03/N05. This is independent test derivation from the declared task and native
contract, not an independent review of the later corrected adapter.

The reviewer read Decision 0064, the N01–N06 Work Item map, the reuse qualification,
the existing collector/result reader and the existing domain validation. Primary
Claude documentation was inspected directly on 2026-09-11:

- https://code.claude.com/docs/en/agent-sdk/structured-outputs
- https://code.claude.com/docs/en/headless

The native result contract distinguishes a successful result with a structured
object from both explanatory text and unsuccessful or absent structured output.
The domain contract separately requires explicit findings, unique finding IDs,
string text/recommendation and boolean materiality. A schema-mode claim cannot
replace those checks. Codex remains on its existing final-message JSON contract;
this oracle characterizes completion and complete-value requirements rather than
claiming a new Codex adapter.

## Frozen cases

Seven test methods exercise the actual `collect` CLI and a separate `view` CLI
process. Inputs are synthetic native streams, not model-generated responses.

1. A unique successful structured result is collected even when `result` contains
   a contradictory approval. The structured dissent is preserved verbatim as the
   domain object; stdout/stderr bytes remain unchanged; eligible B stays pending
   and never dispatched.
2. JSON text, fenced text and absent/null/string/array structured values remain
   pending. The automatic collection path cannot salvage prose.
3. Missing result, missing success subtype, error subtype, true or absent error
   flag, duplicate results and a nonobject event remain pending.
4. Missing findings, invalid recommendation, duplicate finding IDs, numeric
   materiality and missing finding text are not valid domain reviews.
5. Invalid A does not prevent a valid Codex B response from being collected. Each
   native stream remains exact and each job keeps its own state.
6. Codex text still requires lifecycle completion and a complete JSON value;
   fenced text does not become a collected review.
7. Original structured dissent survives a separate executor disposition,
   collection replay and later subject drift. A becomes stale; B remains pending;
   neither review independence nor human approval is manufactured.

The tests materialize a completed **synthetic capture** with its independent
assignment/subject and raw-byte hashes. This deliberately exercises the consumer
without requiring the old dispatch parser to recognize a new adapter name. It
does not test native invocation, authentication, schema generation, capture
execution or actual agent handoff. N01/N04/N06 require their separately planned
qualification and live evidence. No credential, network provider action, model
inference or commit was performed by this reviewer.

## Initial execution and disposition

`python3 -m unittest discover -s tests -p test_native_review_exchange.py -v`

Focused native execution was selected as pre-implementation parity evidence;
the parent retains applicable container verification before delivery.

Result: **7 methods, 5 PASS, 2 assertion failures, 0 errors, exit 1**. The valid
structured response remains absent from `current_ids` in both the positive case
and the provenance case. The collector executes and records the old normalizer's
rejection; the persisted view reports pending. The assertions distinguish this
from the required collected result. Thus the RED concerns result consumption,
not a CLI startup or missing-test-infrastructure failure.

The malformed-result controls already pass on the old implementation because it
rejects the newly declared adapter altogether; these are not evidence that its
future validation is correct. They must remain green after the positive case is
enabled and should discriminate a permissive native-result mutant.

`freeze.json` binds the test, synthetic streams and unchanged old collector/storage
bytes before implementation. `preimplementation-source/` retains those files plus
the existing result views. `red.stdout`, `red.stderr`, `red.json` and `red-calls/`
retain the execution and each actual CLI result.

Recommendation: **READY FOR THE BOUNDED ADAPTER CORRECTION**, followed by the same
frozen oracle, original historical tests and a targeted native-result mutation.
This recommendation is neither final candidate review nor human acceptance.
