"""Assemble inspected second-trial evidence and verify every retained member."""
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

root=Path(__file__).resolve().parent
out=Path('/tmp/gnostoa-review-exchange/knowledge/assessments/native-review-handoff-evidence')
out.mkdir(exist_ok=True)
selected=json.loads((root/'evidence-selection.json').read_bytes())
delta=json.loads((root/'evidence-final-delta.json').read_bytes())
excluded={name:row for name,row in delta.items() if any(part in {'.ruff_cache','.mypy_cache','.coverage'} for part in Path(name).parts)}
files={**selected,**{name:row for name,row in delta.items() if name not in excluded}}
for name,row in files.items():
    path=root/name
    assert not path.is_symlink()
    raw=path.read_bytes()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],name
additional=['publication-hygiene.md','evidence-selection.json','evidence-final-delta.json','pack-evidence.py']
additional += json.loads((root/'hygiene-retain-list.json').read_bytes())
for name in additional:
    path=root/name
    assert path.is_file() and not path.is_symlink(),name
    raw=path.read_bytes()
    files[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
files=dict(sorted(files.items()))
archive=out/'evidence.tar.gz'
assert not archive.exists(), 'Never overwrite a retained evidence archive'
with archive.open('wb') as dest, gzip.GzipFile(fileobj=dest,mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as packed:
    for name,row in files.items():
        data=(root/name).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
        packed.addfile(item,io.BytesIO(data))
raw=json.dumps(files,sort_keys=True,separators=(',',':')).encode()
manifest=out/'members.json.gz';manifest.write_bytes(gzip.compress(raw,mtime=0))
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'member_index':{'file':manifest.name,'sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'uncompressed_sha256':hashlib.sha256(raw).hexdigest(),'entries':len(files)},'scope':{'initial_selected':len(selected),'final_delta_kept':len(delta)-len(excluded),'excluded_derived_caches':list(excluded),'generated_scan_and_pack_records':len(files)-len(selected)-(len(delta)-len(excluded)),'note':'Exact selected native bytes and test results retained; derived build caches excluded. Original scan submissions and final kept subset remain distinguishable. Scanner reports do not recursively establish their own safety.'}}
lines=[]
for line in json.dumps(index,indent=2).splitlines():
    if '"sha256":' in line or '"uncompressed_sha256":' in line:
        key=line.split('"')[1];comma=',' if line.endswith(',') else ''
        line=line.rstrip(',')+', "_'+key+'_note": "pragma: allowlist secret -- public retained evidence digest"'+comma
    lines.append(line)
(out/'index.json').write_text('\n'.join(lines)+'\n')
with tarfile.open(archive) as packed:
    members=packed.getmembers();assert len(members)==len(files)
    assert len({m.name for m in members})==len(members)
    for m in members:
        assert m.isfile() and m.name in files
        data=packed.extractfile(m).read();row=files[m.name]
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
(root/'pack-verification.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'archive_bytes':index['bytes'],'archive_sha256':index['sha256'],'members':len(files),'excluded_cache_files':len(excluded)}))
