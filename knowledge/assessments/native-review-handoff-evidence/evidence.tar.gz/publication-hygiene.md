# Publication hygiene for the native review-exchange continuation

Date: 2026-09-11. Reviewer: `/root/next_trial_reuse`.

**Original disposition: ACCEPT the exact selected 5,106 inputs and the 25-file
kept final delta for public evidence retention, with the limits below.** This
is a content-hygiene recommendation, not human approval of the experiment's
claims or a general secrecy/legal guarantee. Root owns publication disposition.

## Exact bytes and actual scans

All supplied paths were checked as regular, non-symlink files with safe relative
names, and their byte counts and SHA-256 values matched their frozen selection.
The actual files were scanned with detect-secrets 1.5.0 in the existing local
`gnostoa:development-native-review` container, input mounted read-only and
`--network none`. Default plugins/filters were used except that inline allowlist
annotations were disabled for this separate evidence scan. No token verification
request or upload was made. The initial unprivileged Docker access failed with
socket permission denied; the authorized container run completed normally.

| Scope | Files / bytes | Scanner candidates | Final unresolved |
|---|---:|---:|---:|
| Original selection | 5,106 / 2,254,752 | 1,972 | 0 |
| Submitted final delta, retained as scan history | 63 / 7,938,920 | 267 | 0 |
| Safely expanded unique oracle ZIP contents | 14 / 20,734 | 32 | 0 |

The original set contains seven byte-identical oracle ZIPs. Each outer digest
was checked; their one unique archive was safely expanded and its fourteen
actual members scanned separately. Compressed-byte scanning is not represented
as member-content inspection. The inner candidates were Git/content digests.

Original candidates were recomputed file hashes (1,352), synthetic argv paths
(552), synthetic mutation-log paths (35), historical Git identities (31), a
Git reference (1), and a container output setting (1). Exact scanner candidate
fingerprints and per-occurrence rationales are retained. Delta candidates were
artifact/evidence hashes, Git bindings, native tool-call identifiers, output
settings and two standard cache-directory markers. No candidate was dismissed
solely because it appeared in a log or because CI was green.

Independent byte-pattern checks for private-key headers, GitHub/provider/AWS
tokens, JWTs, long bearer values and embedded URL credentials found no matches
across the original selection, all submitted delta bytes, and expanded members.
These checks have finite coverage; zero matches is not proof that arbitrary
encoded or novel secret formats are absent.

## Final publication subset

The submitted delta includes generated `.ruff_cache`, `.mypy_cache` and
`.coverage` data. The text scanner does not decode their binary contents. Root
accepted excluding these derived caches while retaining readable coverage.json,
quality reports and native suite logs. The exact exclusion record contains
**38 files / 6,617,737 bytes**. No native response, assignment or test-result
record was excluded. The final kept delta is **25 files / 1,321,183 bytes**,
bound by `evidence-final-delta-kept.json`.

The final selected evidence population is therefore **5,131 files / 3,575,935
bytes**, before adding these generated hygiene reports. The original 63-file
submitted-delta scan remains historical; its green scanner result does not
clear the excluded binary caches for publication. This review does not claim
to recursively scan its own reports or later packaging bytes.

## Public input and native-output inspection

All eleven retained public source files match the historical Git objects at
PR #228 commit `6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`, as well as their
source-packet byte counts and hashes. The trial assignments concern that public
fixture and local exchange data. No private repository input was identified in
the selected source set.

A's native stdout is 3,141 bytes; B's is 308,929 bytes; both stderr files are
empty. Native review text, command inputs, result metadata and source-bearing
tool records were inspected. They retain local temporary/home paths, session
UUIDs, tool-call identifiers and a local messaging-socket path. These are
operational metadata, not anonymized records. No authentication credential was
identified. B reports `apiKeySource: none`; this is a metadata label, not a
billing-control or universal credential-absence proof.

B includes four opaque `thinking.signature` fields. They remain the exact
native protocol bytes. Their field placement does not make them access tokens,
and they were not decoded. **No claim is made that their decoded contents are
public, harmless or inspected.** The decoded-content limit is retained instead
of silently replacing or deleting native evidence.

Native B evidence shows an initial read-only `ls` in addition to the exact
`collect` and `view` commands. Its final text incorrectly claims no other shell
command. Root already retained that discrepancy as LR1/LR2 with a separate
executor correction; the original response is preserved. The primary and
auxiliary model-usage metadata likewise remains native evidence rather than an
inferred fallback or billed-extra-spend claim.

## Individual findings and original recommendations

- **PH1:** Native signatures and operational identifiers require bounded claims.
  Recommendation: retain exact native bytes and explicit opacity/metadata limits.
  Disposition: retained with limits.
- **PH2:** Generated binary caches lack decoded text coverage and add no required
  raw trial evidence. Recommendation: exclude the derived cache subset.
  Disposition: root adopted the explicit 38-file exclusion.
- **PH3:** ZIP scanning alone misses contained text. Recommendation: scan the
  safe extracted unique members. Disposition: executed, 32 candidates classified.
- **PH4:** B's no-other-command statement contradicts native `ls`.
  Recommendation: preserve its original claim and our correction separately.
  Disposition: already retained by root; no rewrite of native output.

Machine scope, findings and dispositions: `publication-hygiene.json`.
Raw scanner outputs, manifests, candidate mappings, ZIP bindings and supplemental
checks: `hygiene-output/`, `hygiene-delta-output/`, `hygiene-inner-output/`.
Only paths listed in `hygiene-retain-list.json` are proposed as added hygiene
records; extracted duplicate input staging is not part of that list.
