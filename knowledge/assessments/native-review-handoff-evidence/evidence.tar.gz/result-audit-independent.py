"""Offline read-only comparison of retained native trial records."""
import hashlib
import importlib.metadata
import json
import subprocess
from pathlib import Path
from jsonschema import Draft7Validator

ROOT = Path('/tmp/gnostoa-review-exchange-next-prep/live-run')
PREP = ROOT.parent
REPO = Path('/tmp/gnostoa-review-exchange')
def read(p): return json.loads(p.read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def events(j): return [json.loads(x) for x in (ROOT/'exchange/jobs'/j/'stdout.bin').read_bytes().splitlines() if x.strip()]
report = {'audit_kind': 'offline existing Python/jsonschema; not a live call or repository suite', 'jsonschema_version': importlib.metadata.version('jsonschema')}
manifest = read(PREP/'live-input-manifest.json')
for name, row in manifest.items():
    p = ROOT/name
    assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], name
report['unchanged_manifest_members'] = len(manifest)
assert (ROOT/'roster.json').read_bytes() == (ROOT/'exchange/roster.json').read_bytes()
roster = read(ROOT/'roster.json'); active = read(ROOT/'exchange/active.json')
assert roster['eligible_job_ids'] == ['A','B']
assert active['subject'] == roster['subject']
assert sorted(p.name for p in (ROOT/'exchange/jobs').iterdir()) == ['A','B']
schema = read(ROOT/'control/native-review.schema.json'); Draft7Validator.check_schema(schema)
validator = Draft7Validator(schema)
records = {}; report['jobs'] = {}
for j in ('A','B'):
    job = ROOT/'exchange/jobs'/j
    assignment = ROOT/f'{j}.json'; spec = ROOT/f'spec-{j}.json'
    assert assignment.read_bytes() == (ROOT/'exchange/assignments'/f'{j}.json').read_bytes() == (job/'assignment.json').read_bytes()
    assert spec.read_bytes() == (job/'spec.json').read_bytes()
    intent, receipt = read(job/'intent.json'),read(job/'receipt.json')
    assert receipt['assignment_sha256'] == intent['assignment_sha256'] == active['assignments'][j] == sha(assignment)
    assert receipt['subject'] == intent['subject'] == read(assignment)['subject'] == roster['subject']
    assert receipt['stdout_sha256'] == sha(job/'stdout.bin') and receipt['stderr_sha256'] == sha(job/'stderr.bin')
    assert receipt['returncode'] == 0 and receipt['process_started'] is True and receipt['capture_error'] is None
    ev = events(j)
    if j == 'A':
        completed = [e for e in ev if e.get('type')=='turn.completed']; assert len(completed)==1
        messages = [e['item']['text'] for e in ev if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message']
        assert len(messages)==1
        native = json.loads(messages[0])
    else:
        terminal = [e for e in ev if e.get('type')=='result']; assert len(terminal)==1
        terminal=terminal[0]; assert terminal['subtype']=='success' and terminal['is_error'] is False
        native = terminal['structured_output']
    validator.validate(native)
    assert native == read(job/'review.json')
    assert native['subject_commit'] == roster['subject']['commit']
    records[j]=native
    report['jobs'][j]={'receipt_and_assignment_binding':'PASS','full_frozen_schema':'PASS','native_equals_collected_review':True,'stdout_sha256':sha(job/'stdout.bin'),'stderr_sha256':sha(job/'stderr.bin'),'review_sha256':sha(job/'review.json'),'capture_start_ns':read(job/'capture-start.json')['time_ns'],'receipt_mtime_ns':(job/'receipt.json').stat().st_mtime_ns,'intent_recorded_ns':intent['recorded_ns']}
    report['jobs'][j]['capture_to_receipt_seconds']=(report['jobs'][j]['receipt_mtime_ns']-report['jobs'][j]['capture_start_ns'])/1e9
assert report['jobs']['A']['receipt_mtime_ns'] < report['jobs']['B']['intent_recorded_ns']
ev=events('B'); uses={}; results={}; read_observations=[]; tools=[]
for e in ev:
    if e.get('type')=='assistant':
        for c in e.get('message',{}).get('content',[]):
            if c.get('type')=='tool_use':
                uses[c['id']]=c; tools.append({'id':c['id'],'name':c['name'],'input':c['input'] if c['name'] in ('Read','Bash') else 'retained native structured object'})
    if e.get('type')=='user':
        for c in e.get('message',{}).get('content',[]):
            if c.get('type')=='tool_result': results[c['tool_use_id']]={'content':c.get('content'),'is_error':c.get('is_error'),'native':e.get('tool_use_result')}
for uid,use in uses.items():
    assert uid in results
    result=results[uid]; assert result['is_error'] in (None,False)
    if use['name']=='Read':
        p=Path(use['input']['file_path']); f=result['native']['file']
        assert f['filePath']==str(p) and f['startLine']==1 and f['numLines']==f['totalLines']
        assert f['content'].encode()==p.read_bytes(), str(p)
        read_observations.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p),'exact_native_content':True})
    elif use['name']=='Bash':
        assert result['native']['stderr']=='' and result['native']['interrupted'] is False
        assert result['content']==result['native']['stdout']
    elif use['name']=='StructuredOutput':
        assert use['input']==records['B']
        assert result['native']=='Structured output provided successfully'
    else: raise AssertionError(use['name'])
report['native_tool_calls']=tools; report['exact_reads']=read_observations
bash=[t for t in tools if t['name']=='Bash']; assert len(bash)==3
assert bash[0]['input']['command']==f'ls {ROOT}/exchange'
expected=read(ROOT/'B.json')['commands']; assert [t['input']['command'] for t in bash[1:]]==expected
collect=json.loads(results[bash[1]['id']]['native']['stdout']); view=json.loads(results[bash[2]['id']]['native']['stdout'])
assert collect=={'collected':['A']}
assert view['original_review_records']['A']==records['A']
assert view['current_ids']==['A'] and view['pending_ids']==['B'] and view['eligible_count']==2
assert view['unknown_dispatch_ids']==['B'] and view['never_dispatched_ids']==[]
assert view['unresolved_material_finding_ids']==['A1'] and view['executor_dispositions']=={}
assert records['B']['handoff']=={'eligible_job_ids':roster['eligible_job_ids'],'collected_ids':collect['collected'],'current_ids':view['current_ids'],'pending_ids':view['pending_ids']}
assert all(value==[] for value in records['A']['handoff'].values())
assert 'no other shell command was executed' in records['B']['limitations']
report['extra_bash_task_violation']=bash[0]
report['false_shell_activity_report']='B limitations denies other shell command; native first Bash is ls'
report['B_view_original_A_exact']=True
report['B_handoff_matches_native_collect_and_view']=True
packet=read(ROOT/'public/source-packet.json')
for row in packet['files']:
    data=subprocess.run(['git','show',packet['subject']['commit']+':'+row['path']],cwd=REPO,capture_output=True,check=True).stdout
    assert data==row['text'].encode()==(ROOT/'public/source'/row['path']).read_bytes()
paths={row['path'] for row in packet['files']}
assert set(records['A']['inspected_paths'])==paths
assert set(records['B']['inspected_paths'])==paths | {str(ROOT/'exchange/roster.json'),str(ROOT/'exchange/assignments/A.json'),str(ROOT/'exchange/assignments/B.json')}
report['historical_source_blobs_unchanged']=len(paths)
final=read(ROOT/'final-view.json'); assert final['current_ids']==['A','B'] and final['pending_ids']==[]
assert final['original_review_records']==records
assert final['human_approval'] is False and final['automatic_retry_count']==0 and final['real_provider_portability']=='UNESTABLISHED'
assert final['unresolved_material_finding_ids']==['A1','B1','B2'] and final['executor_dispositions']=={}
assert read(ROOT/'root-final-collect.json')=={'collected':['B']}
report['final_current_ids']=final['current_ids'];report['final_unresolved_findings']=final['unresolved_material_finding_ids']
sentinel=read(PREP/'final-preflight-A.json'); specA=read(ROOT/'spec-A.json')
assert sentinel['spec_sha256']==sha(ROOT/'spec-A.json') and sentinel['argv']==specA['argv'] and sentinel['cwd']==specA['cwd']
assert sentinel['input_bytes']==0 and sentinel['returncode']==1 and sentinel['stderr']=='No prompt provided via stdin.\n'
report['exact_final_sentinel_binding']='PASS; no live request made by this audit'
budget=read(ROOT/'budget-start.json'); assert budget['input_manifest_sha256']==sha(PREP/'live-input-manifest.json')
assert budget['start_ns']<min(v['intent_recorded_ns'] for v in report['jobs'].values())
report['budget_start_to_last_receipt_seconds']=(max(v['receipt_mtime_ns'] for v in report['jobs'].values())-budget['start_ns'])/1e9
assert report['budget_start_to_last_receipt_seconds']<budget['live_limit_seconds']
for p in (ROOT/'control').glob('*'):
    if p.is_file():
        old=subprocess.run(['git','show',budget['implementation_commit']+':tests/fixtures/review_exchange/'+p.name],cwd=REPO,capture_output=True,check=True).stdout
        assert old==p.read_bytes()
report['control_matches_remote_recorded_commit']=budget['implementation_commit']
report['generated_unfrozen_path']='control/__pycache__/storage.cpython-314.pyc; not in frozen23-member population; cause not attributed by this audit'
report['A_usage']=[e['usage'] for e in events('A') if e.get('type')=='turn.completed'][0]
report['A_native_diagnostics']=[e['item']['message'] for e in events('A') if e.get('item',{}).get('type')=='error']
report['B_native_usage']={k:terminal[k] for k in ('num_turns','modelUsage','total_cost_usd','permission_denials','subagent_stats','duration_ms','duration_api_ms')}
report['B_rate_limit_observations']=[e['rate_limit_info'] for e in ev if e.get('type')=='rate_limit_event']
(PREP/'live-result-independent-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checked_manifest':len(manifest),'full_schema_reviews':2,'exact_reads':len(read_observations),'bash_calls':len(bash),'other_tool_calls':len(tools)-len(bash),'A_original_matches_B_view':True,'handoff_state_matches':True,'known_violations':['extra ls','false no-other-shell report'],'live_seconds':report['budget_start_to_last_receipt_seconds']},indent=2))
