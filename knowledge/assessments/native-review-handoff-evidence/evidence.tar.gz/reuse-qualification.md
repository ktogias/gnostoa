# Native startup and structured-output reuse qualification

Date: 2026-09-11. Reviewer: `/root/next_trial_reuse`.
Scope: the separately selected continuation of PR #234; local qualification,
existing study reuse, and primary-source inspection. **No model inference,
credential-file reads, installation, or provider writes were performed.**

**Recommendation: reuse the installed official native schema modes and their
result contracts.** Keep Gnostoa review semantics outside vendor envelopes. Do
not add a generic prose/fence repair parser or a new orchestration dependency
for these two failures. The prior failed live run remains unchanged evidence.

## Observed installed versions

Fresh help/version and executable hashing confirmed the prior binaries:

| Tool | Version | Executable SHA-256 |
|---|---|---|
| Codex | 0.154.0 | `3188814c35471432d4123203e0eb38e5bddc60226e3d7ddf0e59e649ea140022` |
| Claude Code | 2.1.267 | `0399c793ff571d5946ef923d80b4f330d05ac4b6842a6b0775468f5d389403c0` |

Authentication/plan observations from the same-day prior qualification are
reused, not claimed freshly rechecked: ChatGPT `prolite`, Claude first-party
Pro, and owner confirmation that additional charges are disabled. Actual
remaining quota and next-call success are not established by this report.

## Reuse the provider's declared result contract

Codex `exec --json --output-schema <schema-file>` requests a JSON Schema-bound
final response while retaining native JSONL events. `--output-last-message`
can retain an additional final-response copy but is not a second source of
semantic authority. The adapter should require the appropriate completed turn,
parse the bound final agent message as a complete JSON value, and then apply
Gnostoa's review validation. Do not interpret lifecycle completion as a valid
review. [Official noninteractive execution](https://learn.chatgpt.com/docs/non-interactive-mode#create-structured-outputs-with-a-schema).

Claude supports `--json-schema <schema-json>`; its native result carries the
object in `structured_output`. The text `result` can remain explanatory text.
Use a distinct declared structured-output adapter; require a unique successful
terminal event with a non-null object, then validate the domain schema. Do not
fall back to extracting a fenced block when that object is absent. Retain the
complete native stream and its usage/session/error metadata. Installed help
confirms the schema and stream-json flags. [CLI output contract](https://code.claude.com/docs/en/headless#get-structured-output).

Claude's SDK reference says schema validation may re-prompt internally. A
successful result can still lack structured output and must be rejected; an
exhausted structured-output attempt has an error subtype. Thus one assignment
is not necessarily one model request, and the live record must distinguish
controller redispatch from native retries. Use a small draft-07-compatible
schema; schema validity does not establish truth or completeness of findings.
The same reference places structured output on result messages, supporting
stream retention rather than depending on the explanatory result string.
[Structured outputs and error handling](https://code.claude.com/docs/en/agent-sdk/structured-outputs).

Suggested common domain fields retain the existing `findings` array and
`recommendation` string, with explicit handoff/subject fields only if admitted.
Keep object properties explicit and required, reject additional fields where
appropriate, and independently verify the exact assignment/subject. Vendor
schema generation is a serialization aid, not acceptance of the review.

## Native Codex config discrimination: actually executed, without inference

The prior command combined ignored user configuration with two newly synthesized
MCP entries containing only `enabled=false`. Those entries lacked transports.
Removing those two override pairs avoids inventing servers; it does not remove
existing deny rules or introduce a replacement MCP transport.

The version-pinned official source establishes the safe sentinel ordering:
`build_exec_config` precedes `run_exec_session`; normal execution resolves the
prompt before starting `InProcessAppServerClient`. Forced empty stdin exits at
that prompt check. Native telemetry, policy/auth checking, and SQLite setup may
precede it. This is a no-model parser probe, not a claim of zero local runtime
activity. [Codex 0.154.0 exec source](https://github.com/openai/codex/blob/rust-v0.154.0/codex-rs/exec/src/lib.rs) (config 571–586; prompt 907–918; client start 937–942; empty stdin 2161–2166).

Using the exact prior assembled exec options, a curated temporary cwd, the prior
allowlisted environment, and **empty bytes** on stdin:

| Probe | Native result | Interpretation |
|---|---|---|
| Old invalid options | exit 1; zero stdout; `invalid transport` diagnostic; 0.012 s | Original configuration defect reproduced before any model turn. |
| Same options minus only the two incomplete MCP override pairs | exit 1; zero stdout; `No prompt provided via stdin.`; 0.083 s | Native config/policy/auth stages reached the deliberately terminating prompt sentinel. This is parser qualification, not a successful reviewer start. |

Raw stdout/stderr, exact argv and classifications are retained separately in
`native-preflight/old-invalid.*` and
`native-preflight/corrected-empty-stdin.*`. Both exit 1 intentionally; comparing
exit codes alone would erase the discriminating observation. No thread/turn
request is reached on the inspected source path. The binary version/hash was
observed; a reproducible-build equivalence proof was not attempted.

**Before actual dispatch**, run this same empty-stdin sentinel on the final
assembled Codex invocation with its final cwd/environment/options. Record their
binding. A later argument or configuration change invalidates that qualification.
The empty prompt occurs before output-schema file loading, so additionally
validate the intended schema bytes/file separately; this probe does not prove
native schema acceptance or actual inference availability. `--help` alone and a
successful differently configured app-server call are insufficient substitutes.

Claude's last live run already established its selected acquisition flags at
that old invocation. Adding `--json-schema` is still a new combination. Validate
the schema locally and retain the next native initialization/result observations;
do not call help parsing an executed live preflight. No safe no-inference Claude
probe equivalent to the demonstrated Codex sentinel was established here.

## Reuse, authority and license boundaries

The same-day broader study already assessed official CLIs, ACP wrappers,
agent-deck and Agent Orchestrator. This smaller question adds no new dependency
or copied upstream implementation. Invoke the owner's unmodified installed
clients with their own existing login; do not copy OAuth tokens, introduce a
subscription gateway, or silently choose an API-paid fallback. The CLI software
license and provider service/subscription terms remain distinct. Existing
license/service findings in `provider-feasibility.md` and `oss-landscape.md`
remain applicable to this unchanged use; they are not blanket legal clearance.
A later distributed/multi-user integration needs its own use-specific review.

## Individual findings and disposition

| ID | Finding | Original reviewer recommendation |
|---|---|---|
| NQ1 | Native structured fields already exist; the first attempt requested prose JSON only. | USE native schema modes and strict declared-field normalization; preserve prior failure. |
| NQ2 | Successful metadata/help checks did not validate the failed exact exec options. | USE the demonstrated empty-stdin native parser sentinel, bound to final invocation. |
| NQ3 | A native structured-output retry is not controller redispatch. | Retain native attempts/errors and UNKNOWN where unavailable; no inferred one-call accounting. |
| NQ4 | Corrected config parsing is not actual worker/model startup. | Mark parser qualification separately; live success remains unestablished until the next bounded run. |

Overall reviewer disposition: **USE for the bounded next trial, with actual
startup and result-consumption outcomes still to be measured.** This is agent
qualification, not human semantic approval. Root owns executor dispositions.
