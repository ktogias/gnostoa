import datetime
import json
import subprocess
import time
from pathlib import Path

repo=Path('/tmp/gnostoa-review-exchange')
out=Path('/tmp/gnostoa-review-exchange-next-prep/verification')
out.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
image=subprocess.check_output(['docker','image','inspect','gnostoa:development-native-review','--format','{{.Id}}'],text=True).strip()
records=[]
for suite in ['policy','fast','regression','smoke','extended']:
    command=['docker','run','--rm','--user','1000:1000','--mount',f'type=bind,source={repo},target=/workspace,readonly','--mount',f'type=bind,source={out},target=/evidence','--workdir','/workspace','--env','KNOWLEDGE_KIT_ROOT=/workspace','--env',f'KNOWLEDGE_KIT_REVISION={head}','--env','PYTHONPATH=/workspace','--env','XDG_CACHE_HOME=/tmp/gnostoa-cache','--env','GNOSTOA_QUALITY_OUTPUT=/evidence/quality','gnostoa:development-native-review','./ci/verify',suite]
    start=time.time_ns()
    with (out/(suite+'.log')).open('wb') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=False)
    records.append({'suite':suite,'returncode':result.returncode,'command':command,'head':head,'image':image,'started_ns':start,'ended_ns':time.time_ns()})
    (out/'index.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps({'suite':suite,'returncode':result.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}),flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
