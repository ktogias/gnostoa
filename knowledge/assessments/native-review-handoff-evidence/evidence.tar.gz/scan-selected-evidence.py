from pathlib import Path
import hashlib,json,os,time
from collections import Counter
from detect_secrets.core.secrets_collection import SecretsCollection
from detect_secrets.settings import default_settings
from importlib.metadata import version
root=Path('/input'); output=Path('/output'); manifest=root/os.environ.get('GNOSTOA_HYGIENE_MANIFEST','evidence-selection.json'); selected=json.loads(manifest.read_text()); checked=[];bad=[];nontext=[]
for name, expected in selected.items():
 path=root/name
 if path.is_symlink() or not path.is_file() or '..' in Path(name).parts or Path(name).is_absolute():raise RuntimeError('Unsafe/missing selected path '+name)
 data=path.read_bytes();actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 if actual!=expected:bad.append(name)
 try:data.decode('utf-8')
 except UnicodeDecodeError:nontext.append(name)
 checked.append({'path':name,**actual})
if bad: raise RuntimeError('Changed selected evidence '+str(bad))
os.chdir(root);start=time.monotonic();secrets=SecretsCollection()
with default_settings() as settings:
 settings.disable_filters('detect_secrets.filters.allowlist.is_line_allowlisted')
 for name in selected:secrets.scan_file(name)
 payload={'version':version('detect-secrets'),**settings.json(),'results':secrets.json()}
 (output/'publication-secret-scan.json').write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n')
summary={'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'files':len(selected),'bytes':sum(x['bytes'] for x in selected.values()),'all_selected_bytes_match':not bad,'non_utf8':nontext,'scanner_version':version('detect-secrets'),'duration_seconds':round(time.monotonic()-start,3),'network':'Docker --network none','scan_sha256':hashlib.sha256((output/'publication-secret-scan.json').read_bytes()).hexdigest(),'candidate_occurrences':sum(len(v) for v in secrets.json().values()),'types':dict(Counter(x['type'] for v in secrets.json().values() for x in v))}
(output/'publication-scan-run.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');(output/'publication-verified-inputs.json').write_text(json.dumps(checked,indent=2,sort_keys=True)+'\n');print(json.dumps(summary))
