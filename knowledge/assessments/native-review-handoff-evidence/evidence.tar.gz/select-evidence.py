"""Select explicit second-trial evidence; no original archive is rewritten."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
names=set()
for directory in ['oracle','mutants','native-preflight','live-run','green-native']:
    for path in (root/directory).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and '.git' not in path.parts:
            assert not path.is_symlink()
            names.add(str(path.relative_to(root)))
for name in [
 'work-item.md','reuse-qualification.md','handoff-tool-qualification.md',
 'live-plan-review.md','adapter-review.md','live-finding-review.md',
 'live-finding-review-evidence.json','prepare-live.py','live-input-manifest.json',
 'final-preflight-A.json','final-preflight-A.stdout','final-preflight-A.stderr',
 'prelive-policy.log','prelive-policy-corrected.log','run-verification.py',
 'development-build.log',
]:
    assert (root/name).is_file(),name
    names.add(name)
manifest={name:{'bytes':(root/name).stat().st_size,'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest()} for name in sorted(names)}
(root/'evidence-selection.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'bytes':sum(x['bytes'] for x in manifest.values())}))
