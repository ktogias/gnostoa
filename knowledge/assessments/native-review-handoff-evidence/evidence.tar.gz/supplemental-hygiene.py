from pathlib import Path
import hashlib,json,re,subprocess,collections
root=Path('/tmp/gnostoa-review-exchange-next-prep');out=root/'hygiene-output'
patterns={'private-key-header':rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----','github-token':rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})\b','provider-token':rb'\bsk-(?:ant-[A-Za-z0-9_-]{20,}|proj-[A-Za-z0-9_-]{20,}|[A-Za-z0-9]{40,})\b','aws-access-key':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b','jwt':rb'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b','long-bearer':rb'(?i)\bBearer\s+[A-Za-z0-9._~-]{24,}','credentials-in-url':rb'https?://[^\s/@:]+:[^\s/@]+@'}
scopes=[];matches=[]
for folder,manifest in [(root,'evidence-selection.json'),(root,'evidence-final-delta.json'),(root/'hygiene-inner-input','evidence-selection.json')]:
 selected=json.loads((folder/manifest).read_text());scopes.append({'root':str(folder),'manifest':manifest,'files':len(selected),'bytes':sum(x['bytes'] for x in selected.values())})
 for name,row in selected.items():
  data=(folder/name).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes']
  for typ,pattern in patterns.items():
   for m in re.finditer(pattern,data):matches.append({'scope':manifest,'path':name,'type':typ,'offset':m.start(),'candidate_sha256':hashlib.sha256(m.group()).hexdigest()})
packet=json.loads((root/'live-run/public/source-packet.json').read_text());sources=[]
for row in packet['files']:
 path=row['path'];disk=(root/'live-run/public/source'/path).read_bytes();git=subprocess.run(['git','-C','/tmp/gnostoa-review-exchange','show',packet['subject']['commit']+':'+path],capture_output=True,check=True).stdout
 # The packet text is itself an escaped source representation; source acquisition uses retained actual files too.
 sources.append({'path':path,'retained_file_matches_historical_git':disk==git,'declared_bytes_match':len(disk)==row['bytes'],'declared_sha256_matches':hashlib.sha256(disk).hexdigest()==row['sha256']})
metadata={}
for name in ['A','B']:
 events=[json.loads(x) for x in (root/f'live-run/exchange/jobs/{name}/stdout.bin').read_text().splitlines()];sigs=[];calls=[]
 for e in events:
  for b in e.get('message',{}).get('content',[]):
   if isinstance(b,dict) and b.get('signature'):sigs.append({'length':len(b['signature']),'sha256':hashlib.sha256(b['signature'].encode()).hexdigest(),'decoded':False})
   if isinstance(b,dict) and b.get('type')=='tool_use':calls.append({'tool':b.get('name'),'input':b.get('input') if b.get('name')!='StructuredOutput' else {'kind':'domain-review-object'}})
 metadata[name]={'stdout_bytes':(root/f'live-run/exchange/jobs/{name}/stdout.bin').stat().st_size,'stderr_bytes':(root/f'live-run/exchange/jobs/{name}/stderr.bin').stat().st_size,'event_types':dict(collections.Counter(e.get('type') for e in events)),'signatures':sigs,'tool_calls':calls}
report={'scopes':scopes,'pattern_matches':matches,'historical_public_source_binding':sources,'native_metadata':metadata,'signature_limit':'Opaque native protocol signatures, not decoded; no claim that their decoded contents are public or harmless.'}
(out/'publication-supplemental-screen.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps({'pattern_matches':matches,'source_files':len(sources),'all_source_matches':all(all(v for k,v in x.items() if k!='path') for x in sources),'opaque_signatures':len(metadata['B']['signatures'])}))
