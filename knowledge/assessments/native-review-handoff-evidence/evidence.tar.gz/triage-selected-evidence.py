from pathlib import Path
import hashlib,json,re,collections,zipfile,io
from detect_secrets.plugins.high_entropy_strings import HexHighEntropyString,Base64HighEntropyString
root=Path('/tmp/gnostoa-review-exchange-next-prep'); out=root/'hygiene-output'; selected=json.loads((root/'evidence-selection.json').read_text()); scan=json.loads((out/'publication-secret-scan.json').read_text())
digests={r['sha256'] for r in selected.values()}; public_git={'6ee2deb9584ebb9a8f4fa4076fef10f9500903b9','c468e8d9bf8b9b47f87cc5b3c7a89d8dc1bae4ba'}
prior={}
for path in [Path('/tmp/gnostoa-review-exchange-prep/hygiene-triage.json'),Path('/tmp/gnostoa-review-exchange-prep/live-publication-triage.json'),Path('/tmp/gnostoa-review-exchange-prep/validation-hygiene-triage.json')]:
 if path.exists():
  for r in json.loads(path.read_text()).get('records',[]):prior[r['scanner_hash']]=r
signatures={}
for name in ['A','B']:
 for line in (root/f'live-run/exchange/jobs/{name}/stdout.bin').read_text().splitlines():
  e=json.loads(line)
  for block in e.get('message',{}).get('content',[]):
   if isinstance(block,dict) and block.get('signature'):signatures[block['signature']]='native Claude thinking.signature; opaque non-credential protocol field; decoded contents not inspected'
plugins={'Hex High Entropy String':HexHighEntropyString(),'Base64 High Entropy String':Base64HighEntropyString()};records=[]
for path,findings in scan['results'].items():
 lines=(root/path).read_text(errors='replace').splitlines();cache={}
 for f in findings:
  n=f['line_number'];kind=f['type'];key=f['hashed_secret'];line=lines[n-1]
  if (n,kind) not in cache:cache[n,kind]={x.secret_hash:x.secret_value for x in plugins[kind].analyze_line(path,line,n,enable_eager_search=True)}
  value=cache[n,kind].get(key);cat='UNRESOLVED';reason='Exact context needs review'
  if value is not None:
   if value in signatures:cat='opaque-native-thinking-signature';reason=signatures[value]
   elif value in digests:cat='recomputed-selected-file-sha256';reason='Exact candidate equals independently rehashed selected member digest'
   elif value in public_git:cat='public-historical-git-identity';reason='Exact selected PR228 commit/tree identity'
   elif key in prior:cat='prior-reviewed-'+prior[key]['category'];reason='Exact scanner candidate fingerprint previously classified in prior retained hygiene records'
   elif re.fullmatch('[0-9a-fA-F]{64}',value) and any(s in line.lower() for s in ['sha256','digest','hash']):cat='declared-content-fingerprint';reason='Explicit content digest field/reference; not credential syntax'
   elif re.fullmatch('[0-9a-fA-F]{40}',value) and any(s in line.lower() for s in ['commit','tree','head','base','revision','sha']):cat='declared-git-object-reference';reason='Explicit Git object reference in source/provenance/test data; not credential syntax'
  records.append({'path':path,'line':n,'type':kind,'scanner_hash':key,'exact_value_reidentified':value is not None,'candidate_length':len(value) if value else None,'category':cat,'rationale':reason})
result={'occurrences':len(records),'classification_counts':dict(collections.Counter(x['category'] for x in records)),'unresolved_count':sum(x['category']=='UNRESOLVED' for x in records),'records':records}
(out/'publication-triage-initial.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='records'}))
for x in records:
 if x['category']=='UNRESOLVED': print(json.dumps(x))
