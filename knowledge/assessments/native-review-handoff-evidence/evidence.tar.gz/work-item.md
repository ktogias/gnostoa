# Validate native structured review exchange and tool-driven handoff

## Outcome, observation and separate owner admission

Follow the completed first experiment #233 / merged PR #234, whose live result was narrower than its controlled result: Codex failed during configuration loading, and Claude returned an original review that the strict text normalizer could not collect. Keep that original evidence and disposition unchanged.

After the explanation of those results and the proposed next experiment, owner `human:ktogias` said **«εγκρίνω. Κάνε merge και ξεκίνα το επόμενο.»** This separately selects and authorizes the next bounded construction/evaluation after its Work Item, Decision and pre-implementation evidence gates. It also authorized the preceding PR's merge; it does not authorize merge of this future candidate.

Determine whether qualified official tool startup, native schema-constrained responses and a successor agent's actual use of the existing exchange commands can complete one exchange without owner relay or task reconstruction.

Current integration base: `ac4ba46ad4884b3a166ffd4c4b8c5b189fd5e147`, tree `8eb6547871ea65d7d2298a6c801d83aee970c96a`. Provider read-back found no other open PR or existing focused Work Item for this second trial. Broader #3/#10/#11/#201 remain separately owned; this does not admit their full backlogs.

## Reuse before construction

Reuse the [existing study](https://github.com/ktogias/gnostoa/issues/10#issuecomment-5626244123), [route qualification](https://github.com/ktogias/gnostoa/issues/201#issuecomment-5626222572), [version/license assessment](https://github.com/ktogias/gnostoa/issues/201#issuecomment-5626236985), and the integrated exchange fixture. Installed Codex 0.154.0 already exposes `--output-schema`; Claude 2.1.267 exposes `--json-schema` and its native structured result field. Qualify these exact interfaces using local help and official version-bound documentation/source before using them. Use their native features instead of another orchestrator or a parser that extracts plausible JSON from prose.

Native executables remain external tools; no third-party code, SDK dependency or service implementation is copied into Gnostoa. Earlier use-specific licensing/account constraints remain applicable. Official schema mode does not prove semantic review quality or billing entitlement; internal generation retries and auxiliary model use must remain distinguishable from assignment counts.

## Proposed surface and classification

**Normal, Gnostoa-self-only experimental/test change.** Prospective changes: `tests/fixtures/review_exchange/` native result adapters, schema/config qualification helpers and test inputs; a focused additional test file; draft Decision **0064**; a separate assessment/evidence addendum; knowledge index. Existing first-trial native archives and frozen oracle remain byte-identical.

No supported CLI, public schema, new dependency, policy, CI behavior, production gate, browser automation or credentials copy. The reference review subject remains published PR #228 head `6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`. Native tool availability may change; unqualified routes remain unavailable rather than silently switching to a paid API.

## Initial behavior map before implementation

All rows: verification **NOT RUN**, alignment **UNKNOWN**, executor/reviewer dispositions **PENDING**. Planned evidence is an independently derived offline oracle first, followed by the separately budgeted live trial where prerequisites hold.

| ID | Task/source obligation | Intended path and expected observable evidence |
|---|---|---|
| N01 | First trial startup error | Qualify the actual constructed invocation with a no-inference native preflight where supported. The old invalid configuration must remain diagnosed as a startup failure, not a model/review failure. Help alone does not establish configuration validity. |
| N02 | First trial uncollectable native response | Reuse native schema output and strict native-field normalization. Valid structured output is collected; prose/fences, missing structured fields, malformed or unsuccessful native results remain pending with original bytes retained. |
| N03 | Preservation and honest failure | Retain first-trial failures unchanged; no manual extraction may be injected as an automatically collected review. A successful native exit without required result is not a successful exchange. |
| N04 | User-requested continuation through another tool | A fresh successor agent uses the existing `collect`/`view` command path itself, recovers exact subject, full eligible roster, previous original response and remaining work from durable state, and supplies its own response. Retain native tool-call evidence rather than infer execution from its prose. |
| N05 | Pending and provenance | Preserve missing, never-dispatched and stale work, each original finding/recommendation and separate executor dispositions. A successor that sees the earlier review is not claimed independent of it. Root setup/final collection and any intervention are reported separately. |
| N06 | Cost and capability boundary | At most two new assignments, one successor handoff and one round; no automatic re-dispatch or paid API fallback. Unsupported access/schema/tool capability or deadline stops the live route with a narrower result. |

## Construction and live boundaries

Freeze the independent new expectations and establish applicable failing/characterization evidence before changing the result adapter. Replay the unchanged historical tests and new oracle; include a discriminating mutation. Run exact-candidate review and applicable container suites.

This is a second trial, not a retry hidden inside #233. Budget: at most two hours adapter/setup effort; at most 45 minutes total live execution; two assignments (A: source reviewer; B: successor reviewing coordinator), one intentional handoff, one review round, no automatic assignment retry. Reuse the owner's explicit confirmation that additional charges are disabled; no API keys or paid API fallback are introduced. Account metadata and billed-cost visibility remain separate, with UNKNOWN where unobserved.

The root prepares the public source, fixed assignments and roster, starts A and B, and may collect B after its terminal result. B must itself perform the declared exchange consumption; read-only context acquisition alone does not meet N04. No claim of complete autonomous coordinator replacement follows while the root retains those duties. B's permitted tool use is bounded to local public source reading and the declared experimental exchange commands, with no GitHub/source mutation.

## Acceptance / exit

- [ ] Pre-implementation expectations and startup/result failure evidence retained.
- [ ] Historical oracle and first evidence unchanged; new controlled checks and discriminating mutation retained.
- [ ] One bounded live attempt records startup, native result collection and successor command evidence, or explicitly reports the failed/unavailable step.
- [ ] Each supplied review's findings, original recommendation and executor dispositions retained separately.
- [ ] Costs, internal/native usage, interventions and missing observations reported without invented savings.
- [ ] Reviewed evidence packet recommends use, narrow or abandon; ordinary publication/read-back/close-last follows, with future merge requiring separate owner approval.

A negative result completes the trial. Stop at capability/cost/time boundaries; do not broaden the mechanism to rescue it.
