"""Retain finite final validation records without changing primary evidence."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile

prep = Path(__file__).resolve().parent
stage = prep / 'publication-validation-stage'
scan = prep / 'publication-validation-scan-output'
repo = Path('/tmp/gnostoa-review-exchange')
out = repo / 'knowledge/assessments/native-review-handoff-evidence'
archive = out / 'publication-validation.tar.gz'
index_path = out / 'publication-validation-index.json'
assert not archive.exists() and not index_path.exists(), 'Never replace retained evidence'
protected = [out / n for n in ('evidence.tar.gz','members.json.gz','index.json','verify_evidence.py')]
protected.append(repo / 'knowledge/assessments/native-structured-review-handoff.md')
before = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
selected = json.loads((stage / 'evidence-selection.json').read_bytes())
sources = {name:stage/name for name in selected}
for name, row in selected.items():
    data = sources[name].read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
sources['evidence-selection.json'] = stage / 'evidence-selection.json'
for name in ('publication-secret-scan.json','publication-scan-run.json','publication-verified-inputs.json','publication-triage.json','scan-command.json','retention-review.md'):
    sources['scan/' + name] = scan/name
sources['pack-publication-validation.py'] = Path(__file__)
members = {}
with archive.open('wb') as dest, gzip.GzipFile(fileobj=dest, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as packed:
    for name, source in sorted(sources.items()):
        assert not source.is_symlink() and source.is_file()
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        data = source.read_bytes()
        item = tarfile.TarInfo(name); item.mode = 0o644; item.mtime = 0; item.size = len(data)
        packed.addfile(item, io.BytesIO(data))
        members[name] = {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

recipe = '''import hashlib, json, tarfile
from pathlib import Path
root = Path('knowledge/assessments/native-review-handoff-evidence')
index = json.loads((root / 'publication-validation-index.json').read_bytes())
path = root / index['archive']
data = path.read_bytes()
assert len(data) == index['bytes']
assert hashlib.sha256(data).hexdigest() == index['sha256']
with tarfile.open(path) as archive:
    members = archive.getmembers()
    assert len(members) == len(index['members'])
    assert {m.name for m in members} == set(index['members'])
    for member in members:
        assert member.isfile()
        data = archive.extractfile(member).read()
        expected = index['members'][member.name]
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256']
print('Verified supplement and', len(members), 'regular members; no extraction or provider calls')
'''
index = {'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'scope':{'scanned_inputs':len(selected),'selected_input_bytes':sum(r['bytes'] for r in selected.values()),'generated_selection_scan_pack_records':len(members)-len(selected),'scanner_candidates':22,'unresolved_candidates':0,'original_hygiene_disposition':'ACCEPT exact selected validation records; finite scanner/provenance limits','note':'Earlier failures and later successes retained separately. Generated reports are not recursively claimed scanned. Original reviewed index reconstructed only after its hash matched earlier independent review.'},
    'primary_evidence_preservation':before,
    'members':members,
    'verification_recipe':'python3 - <<\'PY\'\n' + recipe + 'PY\n'}
# Inline markers are metadata for known public digests, not evidence redaction.
lines = []
for line in json.dumps(index, indent=2).splitlines():
    if '"sha256":' in line:
        comma = ',' if line.endswith(',') else ''
        line = line.rstrip(',') + ', "_sha256_note": "# pragma: allowlist secret -- public retained evidence digest"' + comma
    elif any('"' + name + '":' in line for name in before):
        # Mapping values are also public file identities, placed on annotated lines.
        comma = ',' if line.endswith(',') else ''
        key = line.split('"', 2)[1]
        line = line.rstrip(',') + ', "' + key + '_note": "# pragma: allowlist secret -- public retained evidence digest"' + comma
    lines.append(line)
index_path.write_text('\n'.join(lines)+'\n')
subprocess.run([sys.executable,'-B','-c',recipe],cwd=repo,check=True)
assert before == {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
result = {'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'index':str(index_path),'index_sha256':hashlib.sha256(index_path.read_bytes()).hexdigest(),'members':len(members),'scanned_inputs':len(selected),'generated_records':len(members)-len(selected),'primary_files_unchanged':True}
(prep/'publication-validation-pack-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
