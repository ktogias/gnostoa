## Authorized squash merge and integration read-back — #219

The bounded #219 repair is integrated. PR #222 was squash-merged at `2026-09-09T17:20:38Z` as **`a1dfd461cfb90c403e5847e886a760f9943fcc54`**, following the [recorded owner disposition](https://github.com/ktogias/gnostoa/pull/222#issuecomment-5605918705). The normal protected merge endpoint required the exact reviewed head; no administrative bypass or protection change was used. The owner's disposition is distinct from the external model reviews and their supplied execution claims.

### Integrated identity

| Subject | Read-back |
| --- | --- |
| Reviewed PR head | `cfd4163a70e768951d2eab28e70a3ae7da951579` |
| Integrated main commit | `a1dfd461cfb90c403e5847e886a760f9943fcc54` |
| Single parent | `6d8c4356866b3844f3439c7dc7ea374c39cfff2b` |
| Tree at both reviewed head and integrated main | `d316a168a150679eb5a0c61cf86457f6e0f08518` |
| Production Git blob | `d27a298fde26e5383ea5144409f2de7f0bea2d3b` |
| Production SHA-256 | `36e794b045f337b1b8ea6481d03ec2370996abe4f15f5e842aa3ac6f912ff72e` |
| Focused-test SHA-256 | `fbc3452e9dd4730944bdb8639013178f16f433bb9d03de23638be5d9eee70d32` |

Provider state and fetched Git agree on the integrated commit. `git diff --exit-code cfd4163a70e768951d2eab28e70a3ae7da951579 a1dfd461cfb90c403e5847e886a760f9943fcc54 --` returns zero with no diff. The four integrated paths are `tools/capsule/qualification.py`, `tests/test_qualification_report_validity.py`, the attributed #219 assessment and `knowledge/index.md`.

This whole-tree equality re-binds the existing **51 focused tests, 29 specified applicable mutation operators and development-container extended evidence** to the integrated source. Those measurements were not rerun or presented as newly executed. Their [original checkpoint](https://github.com/ktogias/gnostoa/pull/222#issuecomment-5604554830), RED commits and recorded limits remain applicable. The 29-operator matrix is sampled: 24 assertion-only (including diagnostic-only Q02), four runtime-only and one mixed; historical R3.W1 remains not applicable.

### New verification on integrated main

- [Main verification run 34382326019](https://github.com/ktogias/gnostoa/actions/runs/34382326019): **SUCCESS** on exact `a1dfd461`. Policy, fast, Python 3.11/3.12, regression and smoke passed. Actual Python 3.12 logs confirm Ruff format/lint, mypy and **648 tests, 646 PASS + two existing OCI skips**. Runtime regression also reports 648 tests with two skips and successful self-check stages.
- [Main CodeQL run 34382325241](https://github.com/ktogias/gnostoa/actions/runs/34382325241): **SUCCESS** on the same integrated SHA.
- Provider extended is **SKIPPED** by its scheduled/manual event condition. The PR-only exact-candidate binding step is also **SKIPPED** on the main push; this is not represented as a new PR binding run. The earlier PR binding passed on the reviewed tree.
- A fresh runtime was built with `ci/build-runtime` from a clean detached worktree at actual `a1dfd461`, with `GNOSTOA_CANDIDATE_REF` set to that full SHA. Image **`sha256:72b28909de94d5751574ffafa58c842a52e809c874f33d4942f08ce2b8a3c96f`** has both the revision label and `KNOWLEDGE_KIT_REVISION` equal to `a1dfd461`, and runs as non-root user `kit`. This is a local integration image, not a release or registry publication.
- Fresh integrated runtime self-check: **PASS**, exit 0; **648 tests in 130.938s, 646 PASS + two existing OCI skips**, followed by successful example, bundle, guardrail, change-control and CI-policy checks. Self-check log SHA-256: `a2f954ece5490bdc338a67d38314ee48f9f48dd4f80e48cd99fb6950d89a8149`; image inspection JSON SHA-256: `42e347e8989b9bd4022d8db413985cf6c67f5b38d19b29b28b417726724b3a22`.
- Container-read source and packaged-runtime public-surface digests are identical: **`sha256:1708b237c84cb4dac09524f9ad66e993896675467e41b02fbf2c9fb715232a73`**. The source worktree and its required Git metadata were mounted read-only. The first source-digest attempt refused an unresolved detached-worktree Git path; adding the existing metadata as another read-only mount allowed normal validation, without bypassing the binding check.

### #219 acceptance reconciliation

The issue remains **OPEN**. Original criteria **1, 3–8 and 10** are fulfilled within the admitted synthetic/parser/local-process repair: genuine RED; valid BASE/REFERENCE controls; invalid process/ERROR/incomplete/contradictory reports rejected; observed causes preserved; local completion and transport checked; regression/mutation discriminators; and unchanged broader backend/launch authority.

Two criteria remain incomplete:

- **Criterion 2 — #202:** actual pinned pytest plus mandatory OCI integration/reachability. The two existing OCI skips and external ad-hoc pytest 9.1.1 probes do not satisfy it.
- **Criterion 9 — #216:** historical receipt impact and retained/import/restore/READY validity. Preserving existing receipts, consumed claims and locks does not constitute this assessment.

The issue checklist is reconciled to these results; historical discovery text remains identifiable as history. Merge completed the admitted source repair, while whole-issue closure remains pending the remaining acceptance work and a separate owner disposition. The new source does not retroactively qualify historical evidence. No retained evidence was rewritten and no consumed qualification was retried.

The prospective per-case permitted-cause contract remains #225; systematic mutation verification remains #224; Node and routing remain #218/#215. None gains implementation admission from this merge. The unexecuted recovery probe inside the claimed-effect window remains a bounded evidence limitation: consumed-authority/recovery ownership already exists in #197/PR #200, while #207 is a merged pre-effect viability PR under #206. No new recovery defect or universal recoverability result is asserted.

### Micro-retrospective and next disposition

Expected: a complete, internally consistent report with an observed cause is required to support qualification, and local process/transport failures return structured infrastructure outcomes. Actual: the repair and regression evidence are integrated with an identical reviewed tree and newly verified main/runtime identities.

Late discoveries included inaccurate blanket GREEN statements, local infrastructure exceptions, cause borrowing, blank/padded cause names and exceptions raised before a report existed. Verification-first checkpoints, exact-head read-back and discriminating mutants caught these problems. They also rejected the proposed `errors="replace"` patch, which would have converted an undecodable infrastructure cause into false behavioral acceptance. The withdrawn patch remains explicitly marked as historical evidence in the [verbatim original archive record](https://github.com/ktogias/gnostoa/pull/222#issuecomment-5605728292); it was never applied. [Subsequent review reconciliation](https://github.com/ktogias/gnostoa/pull/222#issuecomment-5605859596) preserves the external/local evidence distinction.

One improvement worth considering is the already captured #224 systematic mutation workflow; the finite manual matrix does not implement it. Next owner disposition: select the remaining #219 acceptance work through its existing #202/#216 owners. This checkpoint starts no follow-up implementation, Phase-D experiment or release. If the integrated repair must be rolled back, use a reviewed revert; retained receipts and consumed authority remain untouched.
