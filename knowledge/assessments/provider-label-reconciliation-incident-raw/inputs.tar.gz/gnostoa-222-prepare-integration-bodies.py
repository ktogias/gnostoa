import json
from pathlib import Path

pr = json.loads(Path('/tmp/gnostoa-222-integration-before.json').read_text())
issue = json.loads(Path('/tmp/gnostoa-219-integration-before.json').read_text())
link = 'INTEGRATION_CHECKPOINT_URL'

body = pr['body']
old = 'Current candidate: `cfd4163a70e768951d2eab28e70a3ae7da951579`; base: `6d8c4356866b3844f3439c7dc7ea374c39cfff2b`. Merge and issue closure remain unadmitted.'
new = (
    '**MERGED — integration read-back PASS.** Reviewed head '
    '`cfd4163a70e768951d2eab28e70a3ae7da951579` was squash-merged as '
    '`a1dfd461cfb90c403e5847e886a760f9943fcc54` at `2026-09-09T17:20:38Z`, '
    'with single parent `6d8c4356866b3844f3439c7dc7ea374c39cfff2b`. '
    'Both commits have identical tree `d316a168a150679eb5a0c61cf86457f6e0f08518`. '
    '[Owner disposition](https://github.com/ktogias/gnostoa/pull/222#issuecomment-5605918705) '
    f'and [integrated verification / acceptance reconciliation]({link}) are recorded separately. '
    '**#219 remains OPEN** for its outstanding #202/#216 acceptance criteria; issue closure was not performed.'
)
assert body.count(old) == 1
body = body.replace(old, new)
old = 'That authorization covered thread resolution only. The new candidate requires its own checks and human semantic review.'
new = 'That earlier authorization covered thread resolution only. The subsequent owner disposition for the unchanged cfd4163 candidate authorized the squash merge and integration read-back recorded above; external model reviews were not represented as human approval.'
assert body.count(old) == 1
body = body.replace(old, new)
old = 'Obtain human exact-head semantic review and separate owner squash-merge authorization. After an authorized merge, integration read-back and explicit #219 reconciliation precede closure. Rollback uses a reviewed revert; it does not rewrite retained receipts or retry consumed qualifications.'
new = (
    '**Integrated verification:** [main CI](https://github.com/ktogias/gnostoa/actions/runs/34382326019) '
    'and [CodeQL](https://github.com/ktogias/gnostoa/actions/runs/34382325241) passed on exact a1dfd461. '
    'A fresh runtime built from that SHA passed self-check (648 tests, two existing OCI skips); '
    'revision label/env match a1dfd461 and source/runtime public-surface digests agree. '
    'Provider extended and the PR-only candidate-binding step were SKIPPED on the main push; '
    'previous PR binding and local extended evidence remain separately bound through the identical tree.\n\n'
    'Next owner disposition concerns the remaining #219 criteria through #202 (pinned real-pytest/OCI) '
    'and #216 (historical receipt impact). #224/#225 remain separate backlog. '
    'Rollback uses a reviewed revert; it does not rewrite retained receipts or retry consumed qualifications.'
)
assert body.count(old) == 1
body = body.replace(old, new)
Path('/tmp/gnostoa-222-integration-body.md').write_text(body)

marker = '## Historical discovery (retained)'
assert issue['body'].count(marker) == 1
history = marker + issue['body'].split(marker, 1)[1]
parts = history.split('- [ ] ')
assert len(parts) == 11
history = parts[0] + ''.join(
    ('- [ ] ' if n in (2, 9) else '- [x] ') + text
    for n, text in enumerate(parts[1:], 1)
)
status = f'''## Status

**CRITICAL REPAIR INTEGRATED — POST-MERGE READ-BACK PASS; ISSUE OPEN.**

[PR #222](https://github.com/ktogias/gnostoa/pull/222) was squash-merged as `a1dfd461cfb90c403e5847e886a760f9943fcc54` on 2026-09-09 following the [owner disposition](https://github.com/ktogias/gnostoa/pull/222#issuecomment-5605918705). The reviewed `cfd4163a70e768951d2eab28e70a3ae7da951579` and integrated main have the identical tree `d316a168a150679eb5a0c61cf86457f6e0f08518`.

The bounded Decision 0059 §G repair rejects invalid process/report completion and inconsistent evidence, preserves per-case causes, normalizes surrounding whitespace, and returns structured INFRASTRUCTURE for local OSError and UnicodeDecodeError. Strict decoding remains; the unsafe `errors="replace"` proposal was rejected and retained explicitly as withdrawn history. Compiler ordering, receipt schema, consumed claims and retry authority remain unchanged.

**[Integrated verification and acceptance reconciliation]({link}): PASS.** Exact integrated-main CI and CodeQL passed. A fresh runtime built from actual a1dfd461 passed self-check: **648 tests, 646 PASS + two existing OCI skips**, with exact revision label/env and equal source/runtime public-surface digests. Whole-tree equality re-binds the existing **51 focused PASS, 29 specified applicable operators detected and local development-container extended PASS**; these measurements were not rerun merely because squash changed the commit SHA. Provider extended and the PR-only binding step were SKIPPED on the main push. [Original candidate verification / RED history](https://github.com/ktogias/gnostoa/pull/222#issuecomment-5604554830) remains separate.

**Acceptance reconciliation:** criteria **1, 3–8 and 10** below are checked for the integrated, admitted synthetic/parser/local-process repair. **Criterion 2 remains open under #202** (actual pinned pytest plus mandatory OCI integration/reachability); **criterion 9 remains open under #216** (historical receipt impact and retained evidence validity). Existing OCI skips and external ad-hoc pytest probes do not satisfy #202. Leaving old receipts untouched does not satisfy #216's assessment.

The issue remains OPEN pending those acceptance criteria and a separate owner closure disposition. #224 (systematic mutation verification), #225 (prospective permitted causes), #218/#215 (Node/routing) remain separate; this integration grants no implementation admission for them. No retained evidence or consumed claim was rewritten, no qualification was retried, and no Phase-D or release was performed. The [integration checkpoint]({link}) also records the micro-retrospective and the existing #197/PR #200 ownership of consumed-authority recovery.

'''
Path('/tmp/gnostoa-219-integration-body.md').write_text(status + history)
print('Prepared PR and issue bodies; eight criteria fulfilled, two remain unchecked; checkpoint URL placeholder awaits publication.')
