Controlled review exchange evidence for #233. All members are regular files.
Absolute paths inside captured commands are historical execution locations.
Original runtime outputs and wrapper/driver observations are separate.
No live model calls occurred. Auth status is a deliberately sanitized whitelist,
not a raw credentials/auth response. Full vendor help and web pages are not bundled.
The qualification report links those sources; its help-file list describes
local research retention, not members promised by this archive.
Review-before candidate/baseline/test source was reconstructed after review
from retained sources and verified against the pre-existing reviewer hashes;
this is later retention, not a claim that those snapshots existed at review time.
Use repository test commands to replay controlled cases. No provider authenticity,
human approval, real portability or complete crash isolation is established.
