"""Capture one explicitly launched process independently of its coordinator."""

import os
import subprocess
import sys
import time
from pathlib import Path

from storage import digest, read, write, write_bytes


def main() -> None:
    job = Path(sys.argv[1])
    intent = read(job / "intent.json")
    spec = read(job / "spec.json")
    assignment = (job / "assignment.json").read_bytes()
    write(job / "capture-start.json", {"pid": os.getpid(), "time_ns": time.time_ns()})
    try:
        completed = subprocess.run(
            spec["argv"],
            input=assignment,
            capture_output=True,
            check=False,
            timeout=spec.get("timeout_seconds", 30),
            cwd=spec.get("cwd"),
        )
        out, err, code = completed.stdout, completed.stderr, completed.returncode
    except subprocess.TimeoutExpired as exc:
        out, err, code = exc.stdout or b"", exc.stderr or b"", None
    except OSError as exc:
        out, err, code = b"", str(exc).encode(), None
    # Persist native bytes even when execution or later normalization fails.
    write_bytes(job / "stdout.bin", out)
    write_bytes(job / "stderr.bin", err)
    if spec.get("drop_receipt", False):
        write(job / "fault-injected.json", {"kind": "lost-receipt"})
        return
    write(
        job / "receipt.json",
        {
            "assignment_sha256": digest(assignment),
            "subject": intent["subject"],
            "stdout_sha256": digest(out),
            "stderr_sha256": digest(err),
            "returncode": code,
            "capture_pid": os.getpid(),
        },
    )


if __name__ == "__main__":
    main()
