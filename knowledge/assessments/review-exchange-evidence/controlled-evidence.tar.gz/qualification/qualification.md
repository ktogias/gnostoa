# Local official-tool route qualification

Date: 2026-09-11 Europe/Athens; observations at 2026-09-10T23:02:33Z.
Task: the owner-selected first review-exchange/coordinator-replacement evaluation card, published as #10 comment 5626517082. This record qualifies prerequisites only. **No model calls, login, installation, token-file reads, source changes or provider writes were performed.**

## Observations and findings

| Route | Local evidence | Auth/billing evidence | Disposition |
|---|---|---|---|
| Codex | Official standalone ELF binary, `codex-cli 0.154.0`; SHA-256 `3188814c35471432d4123203e0eb38e5bddc60226e3d7ddf0e59e649ea140022`. | Official `codex login status` exit 0, ChatGPT authentication. Actual plan, quota, credit balance and automatic reload **UNKNOWN**. | Execution interface available; not yet unconditional live GO under the no-unplanned-paid-usage condition. |
| Claude Code | Official installed native binary, version `2.1.267`; SHA-256 `0399c793ff571d5946ef923d80b4f330d05ac4b6842a6b0775468f5d389403c0`. | Official `claude auth status --json` exit 0; logged in, `claude.ai`, `firstParty`, `pro`. Remaining quota and optional usage credits **UNKNOWN**. | Execution interface and subscription type established; no-extra-charge condition remains unestablished. |
| `grok` in PATH | Resolves to `/usr/local/lib/node_modules/@vibe-kit/grok-cli/dist/index.js`, not the official Grok Build tool researched in the study. | Not invoked; no credential/config inspection. | **Not qualified as an official route.** Do not infer Build/subscription support from this command name. |
| Gemini CLI | `gemini` absent from PATH. | No login or quota checked. | **Unavailable for this attempt** absent separately authorized installation; no such installation performed. |

**Q1 — Account authentication is established, but it is not an expenditure ceiling.** Every inspected API-key, alternate-auth/provider or base-URL environment override was absent; names and booleans only are retained. This excludes those observed environment routes, not credentials in settings/key helpers or optional subscription overage. Codex documents `forced_login_method="chatgpt"`, which can constrain the invocation's authentication route; its API key path uses separate Platform billing. [Codex configuration](https://learn.chatgpt.com/docs/config-file/config-reference#configtoml), [authentication](https://learn.chatgpt.com/docs/auth).

**Q2 — The remaining zero-extra-spend prerequisite is real and narrow.** Claude paid plans can enable additional usage credits charged at API rates; disabling them in Settings > Usage restricts use to included plan allowance. Hiding `/extra-usage` with `DISABLE_EXTRA_USAGE_COMMAND` is only a UI restriction, not evidence that already-enabled credits cannot be consumed. `--max-budget-usd` is an API-call budget mechanism, not a verified zero-charge switch that preserves subscription calls. Codex also documents credit-based additional usage. No public, verified invocation flag disabling already-enabled subscription credits was established in this bounded check. [Claude usage credits](https://support.claude.com/en/articles/12429409-manage-usage-credits-for-paid-claude-plans), [Claude environment variables](https://code.claude.com/docs/en/env-vars), [Codex pricing](https://learn.chatgpt.com/docs/pricing).

Consequently: preventing additional OpenAI Platform/API-key routing is different from excluding all metered usage beyond the prepaid subscription. The accepted card contains both zero additional paid API spend and the broader instruction not to use a route if unplanned paid usage cannot be excluded. **Do not infer that prerequisite from login success.** A provider usage/billing control readback or owner-confirmed disabled overage is still needed for each selected live route. A quota estimate alone is not a hard spending boundary, especially with concurrent sessions. This is not a request to authorize spending or to reopen the study.

**Q3 — Startup customization is an effect surface.** Ordinary `claude -p` loads ambient hooks/MCP without a trust dialog; `--bare` avoids that discovery but also refuses subscription OAuth and requires API/cloud credentials. The installed `--safe-mode` retains normal auth while disabling customizations; `--restricted` and explicit tool selection further narrow tools. These are preferable candidates here. Do not use `--bare`, `--dangerously-skip-permissions`, cloud dispatch or automatic model fallback for this subscription-only, local trial. [Claude headless execution](https://code.claude.com/docs/en/headless). Installed help captures the exact current safe/restricted flags.

## Supported forms for root's adapter construction

These are command shapes derived from installed help and official documentation, **not executed model invocations or already-qualified combinations**. Use subprocess argument arrays, explicit environment allowlisting and the frozen public candidate packet. Root retains responsibility for final actual invocation/control verification.

### Codex

- `codex exec --json --sandbox read-only --ignore-user-config -c 'forced_login_method="chatgpt"' -c 'approval_policy="never"' ... -` accepts the prompt/packet over stdin; `--output-last-message PATH` supplies a convenience final text copy, and `--output-schema PATH` can constrain that response.
- Pin `model_provider="openai"` and the chosen model explicitly; disable unnecessary apps/hooks/MCP/web/multi-agent capabilities and do not import ambient provider routing. `--ignore-user-config` preserves official auth but does not itself prove all project/managed configuration or tool surfaces absent.
- Keep session persistence enabled when needed; `--ephemeral` deliberately removes it. `exec resume` and `fork` exist. External durable assignment/raw-output files remain the recovery authority for the trial; a coordinator need not resume the same vendor conversation.
- The previously generated exact-version app-server schema supports `turn/interrupt`; that is a more explicit cancellation protocol than killing an opaque terminal. This check did not exercise cancellation. A subprocess deadline must retain partial raw output and mark interruption/pending, not synthesize a completed review. Do not use `thread/shellCommand` as a sandboxed worker path; documented behavior is outside the thread sandbox. [App-server](https://learn.chatgpt.com/docs/app-server).

### Claude

- Candidate narrow shape: `claude --safe-mode --restricted -p --output-format stream-json --verbose --tools Read,Glob,Grep --permission-mode dontAsk --permission-prompts none --strict-mcp-config ...` in a dedicated candidate export, with an explicit session ID/model and empty explicit MCP configuration. Alternatively `--tools ""` plus the complete frozen public source packet on stdin removes model-invoked tools entirely.
- Do not supply `--no-session-persistence`; retain native stdout and stderr before normalization, terminal result and exit status separately. The installed CLI supports `--resume` and `--session-id`; the external task record handles cross-tool coordinator replacement.
- Official SIGTERM behavior is exit 143 with the current turn unfinished; SIGINT/SDK interrupt differs. A timeout is therefore interruption, never successful review. Runtime `system/init` capability metadata and result records must be checked when the admitted live invocation occurs. `--permission-prompts none` denies unresolved prompts; it does not override a hook that already authorizes an action, hence the separate customization restriction. [Headless execution](https://code.claude.com/docs/en/headless).
- The installed `--tools` flag is an actual tool-list restriction; prompt prose saying read-only is not. Read-only file tools are still broad unless their reachable filesystem is constrained. An export/outer read-only mount or supplying source bytes with tools disabled avoids granting mutation access to candidate/GitHub. No protected-principal or hostile-isolation claim follows from this fixture.

## Original recommendation

**CONDITIONALLY USE Codex and Claude as the two real reference routes; live dispatch remains pending on the specific no-unplanned-paid-usage prerequisite.** Do not use the discovered third-party `grok` command as an official Build substitute; Gemini is unavailable locally. If the spend prerequisite cannot be established, complete the deterministic/fault-injection controls and report real two-tool portability as unestablished, as the card already permits. Do not trigger paid fallback or model calls merely to discover entitlement.

This recommendation does not prescribe a new approval cycle. Root can finish all independent construction/verification and resolve the single missing billing-control fact before the admitted live effect. Preserve the budget of two reviewer assignments and one coordinator handoff; internal retries and token accounting must be recorded where observable rather than counted as one model call per assignment.

## Retained evidence

- `local-route-inventory.json`: resolved paths, executable hashes, environment-name presence flags; no values.
- `auth-status-sanitized.json`: official auth-status outputs reduced to a strict whitelist; no tokens, email, account IDs or raw auth output retained.
- `codex-version.txt`, `codex-exec-help.txt`, `codex-login-help.txt`, `claude-version.txt`, `claude-help.txt`, `claude-auth-help.txt`: actual local version/help output.
- Earlier study schema inventory: `/tmp/gnostoa-coordination-research/codex-local-schema-inventory.json`, exact to the same Codex binary.

Codex emitted a non-fatal warning that PATH aliases could not be created on the read-only filesystem. Version/help/status still exited 0. This records the limitation; it is not a successful live-execution test. Documentation was accessed on 2026-09-11; unobserved account/runtime facts remain UNKNOWN.
