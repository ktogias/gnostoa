# Independent bounded code review — #233 review exchange

Reviewer: session agent `/root/code_review`. Date: **2026-09-11 Europe/Athens** (observations `2026-09-10T23:16–23:19Z`). Independent of controller and oracle authorship; not a human approver or an authenticated external reviewer.

**Original recommendation: CORRECT the three concrete capture/error/deadline findings below before claiming these paths are supported or using the wrapper for the admitted live trial.** The original eight controlled cases pass, and the central roster/persistence approach is aligned with the bounded card. Those passing cases do not establish the newly probed paths, live portability, paid-usage exclusion, hostile-process isolation or human acceptance.

## Reviewed subject and authority

Read the accepted evaluation-card text, #233 work-item body, draft Decision 0063, repository README/router and applicable self-hosted delivery/traceability route. Formed the task-to-code view before reading the oracle expectations and test implementation. The review subject is an uncommitted test-only candidate under `/tmp/gnostoa-review-exchange`, based on main `a0c71f3018876b192b6a98741c837b7074d8892e`. The historical review target remains PR #228 commit `6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`; it is distinct from the controller implementation under review.

The files initially reviewed, after the coordinator's mechanical Ruff pass, have these SHA-256 identities:

| Source | SHA-256 |
| --- | --- |
| tests/fixtures/review_exchange/exchange.py | `675bda45143160301a7294a88a842fa275cef3db5fff335e5d882ea864165d58` |
| tests/fixtures/review_exchange/candidate.py | `6bedba7bf2ff4ca97dc2cdbc4ba003ed15c84f83c31b712164340393779e388e` |
| tests/fixtures/review_exchange/storage.py | `e9a571429f2bbd811c85767578e7129ac95ea0a90130752fa8d4805204f2aa2e` |
| tests/fixtures/review_exchange/worker_capture.py | `73c64e851b178eaaf4d5ffdcdc9abad0eeef03d0c9b429ef5a15841299af7030` |
| tests/fixtures/review_exchange/scripted_worker.py | `8c950827946b76887fad8ef4f193665e299fddc733b07d4cd8ddc2825ad48eec` |
| tests/fixtures/review_exchange/baseline.py | `d12131fb1cc34dce938a4dc848bfb473f334f77c07166a89f899d2f38f7275bd` |
| tests/fixtures/review_exchange/replay_mutant.py | `1d596542450184e647a04017747b4c6f9cea9426f7745610f0898d8b54e983fa` |
| tests/test_review_exchange_fixture.py | `5620689e63dae3a76f86647a164498a612a74fde3143f3c52ad22a7a233f3e9d` |
| knowledge/decisions/0063-evaluate-portable-review-exchange-and-coordinator-replacement.md | `51f49baa9da51b424a0a02feedb087883cf9b46117a46e69204ceb854374a8ed` |

These are initial-review identities, not a claim to have reviewed later repair bytes. Findings and the original recommendation remain retained even if the executor subsequently corrects them.

## Task-to-code observations

- E01/E06: capture writes byte streams before a receipt; normalization writes a separate original review; dispositions live separately and do not rewrite recommendations/findings. The dissent case retains the material finding even after a DEFERRED disposition. Successful capture preserves CRLF/native spacing rather than re-serializing it.
- E02: the single-actor roster works without an independence or human-approval claim. Synthetic reviewer names are not treated as proof of independence.
- E03/E04: candidate view enumerates the frozen roster, not the dispatch registry. Persisted intent precedes launch; collection/view contain no dispatch operation. The workspace lock serializes cooperative coordinator CLI operations. Existing job directories block blind redispatch, including after loss of the launch acknowledgement.
- E05: active subject and assignment identities are compared with the original dispatch intent; revision preserves old assignment/review bytes. A changed assignment or candidate cannot inherit currency through the reviewed normal path.
- E07: explicit worker argv is an operator-qualified edge, not a safety policy or sandbox. Candidate/GitHub read-only behavior, public-input admission and zero paid spend must be established for the actual live invocation. Source does not pretend to enforce those properties. No live entitlement/spend conclusion follows from this review.

The view is a compact projection rather than the complete human review packet: it exposes a disposition body only when exactly one disposition exists and omits some original-review metadata. The retained files still contain all dispositions/original bytes. The final human packet must include or link those complete records; interpreting the view alone as the entire packet would overstate its contents. This is a packet-assembly limit, not a demonstrated loss from the durable workspace.

## Individual findings and original recommendations

### F1 — Wrapper launch diagnostic is mislabeled as native stderr

**Observed source:** `worker_capture.py:30–34` sets `err = str(exc).encode()` after a launch OSError, then writes that wrapper diagnostic into `stderr.bin`; the receipt digests it as stderr. The missing executable cannot have produced a native stream.

**Executed evidence:** a definitely absent executable produced empty stdout and `stderr.bin` containing `[Errno 2] No such file or directory: .../definitely-absent-worker`. Capture returned normally with `returncode=null`; the receipt bound the synthetic diagnostic as stderr. This is a provenance defect, not false review acceptance.

**Original recommendation:** keep absent native streams empty, explicitly distinguish process-not-started, and retain capture-layer exception type/detail in a separate field/file. Add a regression that checks both native bytes and separately labeled capture error.

**Executor disposition:** root selected this as an in-scope capture/provenance correction and proposed R01; implementation/review of the repair was pending at this initial report. **Reviewer disposition:** confirmed on the bound original source.

### F2 — Nonobject JSONL events abort collection of other jobs

**Observed source:** `storage.py:46–63` assumes each parsed JSONL event is a mapping. `null`, a list or another nonmapping JSON value reaches `.get` and raises AttributeError. `exchange.py:101` does not catch that exception.

**Executed evidence:** for both `codex-jsonl` and `claude-jsonl`, A captured `null\n`; B had a valid plain review. `collect` escaped AttributeError, A's raw bytes survived but no normalization-error record was written, and B's valid review was not collected. No provider native-output behavior is assumed: this is a synthetic malformed-input characterization for adapters the fixture currently offers.

**Original recommendation:** validate parsed event/nested shapes and reject malformed events with the documented normalization failure path, so A remains explicitly pending/error and collection can continue to B. Preserve raw bytes and do not invent an empty ACCEPT review. Add a regression outside the unchanged eight-case frozen oracle.

**Executor disposition:** root selected this as an in-scope uncertainty/error-collection correction and proposed R02; repair review pending in this initial report. **Reviewer disposition:** confirmed for both offered JSONL normalizers.

### F3 — Timeout stops the immediate worker but leaves ordinary descendants running

**Observed source:** `worker_capture.py:19–29` relies on `subprocess.run(timeout=...)` without a worker-owned process group. The timeout handles the immediate child, not its ordinary same-group descendants.

**Executed evidence:** a benign synthetic worker launched a child that waited one second and wrote a local marker. With selected timeout 0.2 seconds, capture returned after 0.276 seconds with `returncode=null`, but the descendant subsequently wrote the marker. No network, model, paid operation or hostile escape was involved; the probe included explicit cleanup.

**Original recommendation:** before treating the live job deadline as stopping assigned work, give the worker its own process group and terminate the cooperative group on timeout, then retain a clearly labeled timeout result and available native bytes. Alternatively, keep live dispatch unestablished until the chosen official invocation has an independently qualified external termination boundary. Do not claim protection against descendants that deliberately escape that group, host crashes or hostile processes.

**Executor disposition:** finding and minimal recommendation sent to root; source correction selection/verification pending at the initial report. **Reviewer disposition:** confirmed current deadline limitation, material to the admitted bounded live-execution claim, not a request for general process isolation.

## Oracle/test reconciliation and independent execution

The eight original controlled tests **PASS** independently. They read independently frozen expected projections, compare actual native bytes against frozen inputs, exercise absent B without manufacturing a dispatch record, and use actual child processes/launch markers. X03's P1 invocations terminate before fresh P2 collect/view invocations receive only the workspace locator and ordinary operation arguments. This supports same-host process persistence/acquisition, not replacement by a second real agent/tool.

X04 discriminates the registry-only baseline/M0 omission with an independent A+B denominator; X05 checks one actual launch across repeated fresh-process collect/view; X06 separately checks assignment then subject staleness; X07 keeps dissent/original recommendation distinct from a disposition; X08 checks native bytes despite failed plain normalization. The fixture's constant `automatic_retry_count=0` is not accepted alone as measurement: source inspection and external launch markers supply the relevant bounded evidence.

The original oracle intentionally does not cover spawn-failure provenance, malformed JSONL event types or descendant timeout effects. All eight tests passing is therefore compatible with F1–F3. The reviewer did not rewrite the oracle or infer semantic completeness from code/test agreement. Root owns retained baseline/M0 execution and all main container gates.

Native fallback was explicitly authorized for these small focused review/probes while root runs the main gates in the development container. Actual environment: Python **3.14.7**, executable `python3`, no dependency installation. Commands from `/tmp/gnostoa-review-exchange`:

```sh
PYTHONDONTWRITEBYTECODE=1 GNOSTOA_EXCHANGE_EVIDENCE=/tmp/gnostoa-review-exchange-prep/reviewer-focused python3 -B -m unittest discover -s tests -p test_review_exchange_fixture.py -v
python3 -B /tmp/gnostoa-review-exchange-prep/reviewer-probes.py
python3 -B /tmp/gnostoa-review-exchange-prep/timeout-probe.py
```

The focused suite executed eight tests in 4.499 seconds, zero failures/errors/skips. The additional probes characterize pre-repair behavior; their successful script exit means evidence capture completed, not that the candidate satisfied the required behavior.

| Evidence file in `/tmp/gnostoa-review-exchange-prep` | SHA-256 |
| --- | --- |
| reviewer-focused.log | `0afb9d5c87f5c4de390df7d759a8afe62c840a650b5ceccef293c311af727354` |
| reviewer-probes.json | `0d7ee899a4a34757f33812bb938dc4217cd067b68384066fb0cca9c660dd59e6` |
| timeout-probe.json | `11b2a9c05be636979e768f36b5041b03aed57d869d0f41f2282bc5fdd44b34bc` |

Runnable probe scripts and synthetic artifacts are retained beside this report. Source was read-only; only declared temporary review artifacts were written. No source/model/provider mutation, authentication, installation, real review dispatch or claim execution occurred. Parent worktree edits after the reviewed snapshot require a new subject binding and an appended disposition, not rewriting these original observations.

## Corrected-candidate read-back and final disposition

Appended at **2026-09-10T23:21:31Z** (2026-09-11 Europe/Athens), after root selected and implemented the three bounded corrections. The original observations/recommendations above remain unchanged.

**Final reviewer recommendation: CODE REVIEW PASS for the corrected test-only transport fixture and these three explicitly tested error paths.** No further material defect was found within that bounded subject. This does not authorize a live model call, establish zero paid-usage entitlement, prove real tool replacement, supply human approval or authorize merge.

The following source identities supersede only the corresponding initial implementation/test identities; the other Python fixture files are unchanged:

| Corrected source | SHA-256 |
| --- | --- |
| tests/fixtures/review_exchange/storage.py | `98e996c8f2423277f619f61f76da163b844011e750c18b6eb9aa97af675e4fc9` |
| tests/fixtures/review_exchange/worker_capture.py | `0ff77846b4953fe302e14e0e1e32fb094024a89e99feab9b0f173852a9264013` |
| tests/test_review_exchange_fixture.py | `dcc7432b1c2afaaae3d91c4df8c8fabdb4beeaba6a75215c67e77455f47cef4b` |

**F1 closure:** `worker_capture.py:45–50` now leaves absent native stdout/stderr empty, records a separate `capture-error.json`, and binds `process_started=false` plus `capture_error=FileNotFoundError` in the receipt. The independent missing-executable probe now observes empty stderr and the correct explicit receipt fields. The separate diagnostic file was also read and retains the exception type/message. Original recommendation adopted; reviewer disposition **CORRECTED / VERIFIED** for spawn failure.

**F2 closure:** `storage.py:41–45` rejects nonobject JSONL events with ValueError before adapter traversal; Codex nested-item traversal checks that the item is a mapping. The unchanged collector's per-job error handling now records A's normalization error and continues to B. Both independent `null\n` probes now report no escaped exception, exact retained raw bytes, an error record for A and a collected valid B. Original recommendation adopted; reviewer disposition **CORRECTED / VERIFIED** for the reported malformed-event cases. This is not an exhaustive vendor-protocol compatibility claim.

**F3 closure:** `worker_capture.py:22–44` starts the actual worker in its own session/process group and sends SIGKILL to that group on timeout, then drains the streams and records `TimeoutExpired` with no successful return code. The same benign descendant probe now returns after 0.252 seconds for a 0.2-second timeout, and the descendant does not write its post-deadline marker. R03 separately observes a descendant-start marker before testing its later write is absent. Original recommendation adopted; reviewer disposition **CORRECTED / VERIFIED** for cooperative same-group descendants. The source explicitly excludes escaped processes and remote effects already submitted; this review preserves those limits.

Root added R01/R02/R03 outside the unchanged eight-case frozen oracle. All **11 focused methods PASS**, zero failures/errors/skips, in **10.435 seconds**, under the same explicitly authorized native review fallback. The original frozen-file checks still execute. No prior before-report was overwritten: `reviewer-probes.json`, `timeout-probe.json` and `reviewer-focused.log` retain their original hashes, with additional `*-before` copies; corrected observations use separate `*-after` names.

Corrected execution commands:

```sh
python3 -B /tmp/gnostoa-review-exchange-prep/reviewer-probes-after.py
python3 -B /tmp/gnostoa-review-exchange-prep/timeout-probe-after.py
PYTHONDONTWRITEBYTECODE=1 GNOSTOA_EXCHANGE_EVIDENCE=/tmp/gnostoa-review-exchange-prep/reviewer-focused-after python3 -B -m unittest discover -s tests -p test_review_exchange_fixture.py -v
```

The `*-after.py` scripts differ from the before scripts only in the output-report pathname, preserving probe inputs and operations. Their source-selection hashes are retained in the JSON. The tests/probes ran from `/tmp/gnostoa-review-exchange` and wrote only temporary evidence/synthetic artifacts.

| Corrected evidence in `/tmp/gnostoa-review-exchange-prep` | SHA-256 |
| --- | --- |
| reviewer-probes-after.json | `d8b178b58f1c377718cb7eccd818022c1fb118f1d95e321af7ba91a5cc631cbe` |
| timeout-probe-after.json | `60ade9219f294e1a3bb9c9d41def85d2c5148ebd0d6aa55fd5c6d44ce606e670` |
| reviewer-focused-after.log | `2ccd7af75e524c4311fc610c4eb8bf0334acdf703826f8a612ffcb3dece45c5b` |

E01/E04 error provenance and continued collection are supported by the corrected independent observations. E07's local cooperative timeout boundary is now supported, while actual public-input/read-only/account/spend qualification remains external to this fixture. The other original controlled transport rows remain supported by the replay, with real-provider portability explicitly UNESTABLISHED. Main container suites, exact Git candidate binding, provider review state, any live trial and the final use/narrow/abandon assessment remain the coordinator's separate evidence and authority.

## P1 packet-projection observation — selected completion and final read-back

Appended at **2026-09-10T23:24:19Z** (2026-09-11 Europe/Athens).

**Original observation/recommendation, retained separately from F1–F3:** the durable workspace already preserved full originals and dispositions, but the compact `view` emitted only selected original fields and a disposition body only when exactly one existed. Therefore the final human packet needed to include or link complete records; the original observation did not allege deletion of durable records or require a general UI.

**Executor disposition:** root selected a bounded completion of that projection: `original_review_records` retains the full per-job original map, `executor_dispositions` retains all job-qualified disposition records, and `native_artifact_paths` links existing stdout/stderr/receipt files for each eligible job. Existing projection fields and their meanings remain unchanged. The same additional fields were added to the deliberately defective baseline, keeping its intended registry-only denominator defect distinct.

**Independent read-back:** `candidate.py:17–21` lists only existing artifact paths relative to the durable workspace, including an empty list for an eligible job with no captured artifacts. Lines 33–35 preserve the complete original record in addition to the existing selected-fields projection; lines 55–58 expose both complete records and the separate dispositions map. Nothing in this addition relaunches a job, rewrites an original, hides pending/stale membership or turns a disposition into approval.

R04 supplies two reviewers with the same reviewer-local finding ID, distinct original text/metadata and two dispositions. Its assertions check full original-record equality, distinct `A:same-local-id` and `B:same-local-id` keys, the correct separate reasons, and usable native file links. The coordinator's retained `/tmp/gnostoa-review-exchange-prep/evidence/packet-red.stderr.log` was read: one test, one assertion failure for missing `original_review_records`, zero infrastructure errors. This is read-back of coordinator RED, not an execution by this reviewer.

The independent corrected R04 execution **PASSed**, one test in **0.664 seconds**, no failure/error/skip:

```sh
PYTHONDONTWRITEBYTECODE=1 GNOSTOA_EXCHANGE_EVIDENCE=/tmp/gnostoa-review-exchange-prep/reviewer-packet-after python3 -B -m unittest discover -s tests -p test_review_exchange_fixture.py -k R04 -v
```

Final changed identities for this projection read-back:

| Source/evidence | SHA-256 |
| --- | --- |
| tests/fixtures/review_exchange/candidate.py | `5f4d5918933578dbc7510ece1b2e904118728196234c8b405b31c35909ae4535` |
| tests/fixtures/review_exchange/baseline.py | `bc755268ed9b05f66180da0aeb6adaa50b2d9c03bf9137cf3672214cab84a50e` |
| tests/test_review_exchange_fixture.py | `25018ac912bb3961d14da208a27060a889888f4a48cbab5eebcb1352db13a085` |
| /tmp/gnostoa-review-exchange-prep/reviewer-packet-after.log | `45cbf0c53a27c2d98def97471e7fb8146d2eac7c6e907e629c2c7b1eb200140a` |

The other fixture implementation hashes remain those already recorded after F1–F3. The previous eleven-test replay is bound to its prior test/projection subject; this last execution covers R04 on the final tiny addition. This record does not relabel earlier executions as a fresh twelve-test run; root owns final complete container/gate replay.

**P1 reviewer disposition: ADOPTED / VERIFIED. Overall candidate recommendation remains CODE REVIEW PASS for the bounded self-only fixture with F1–F3 and P1 corrected.** No additional blocker was identified in the selected final projection. Actual live-tool qualification, permitted public input, read-only effect boundaries, account/quota/zero-extra-paid-usage evidence, real coordinator replacement and the final experimental use/narrow/abandon disposition remain separate. The code review supplies neither a live-call permission nor human merge approval.
