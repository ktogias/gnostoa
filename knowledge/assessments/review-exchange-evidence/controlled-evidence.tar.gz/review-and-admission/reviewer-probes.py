"""Bounded read-only source probes for review exchange error provenance."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path('/tmp/gnostoa-review-exchange')
FIXTURE = ROOT / 'tests/fixtures/review_exchange'
sys.path.insert(0, str(FIXTURE))
import exchange
import storage

outdir = Path(tempfile.mkdtemp(prefix='reviewer-probes-', dir='/tmp/gnostoa-review-exchange-prep'))
report = {
    'source_sha256': {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in sorted(FIXTURE.glob('*.py'))},
    'evidence_root': str(outdir),
    'python': sys.version,
}

def prepare_job(path, *, argv, normalizer):
    assignment = b'{"job_id":"synthetic","subject":{"commit":"synthetic"}}\n'
    storage.write_bytes(path / 'assignment.json', assignment)
    storage.write(path / 'intent.json', {'assignment_sha256': storage.digest(assignment),
                                       'subject': {'commit': 'synthetic'}})
    storage.write(path / 'spec.json', {'argv': argv, 'normalizer': normalizer,
                                     'timeout_seconds': 1})
    result = subprocess.run([sys.executable, '-B', str(FIXTURE / 'worker_capture.py'), str(path)],
                            capture_output=True, timeout=5, check=False)
    if result.returncode:
        raise RuntimeError(result.stderr.decode())

missing = outdir / 'missing-launch'
prepare_job(missing, argv=[str(outdir / 'definitely-absent-worker')], normalizer='plain')
report['F1_missing_launch'] = {
    'native_process_started': False,
    'stdout_hex': (missing / 'stdout.bin').read_bytes().hex(),
    'stderr_text': (missing / 'stderr.bin').read_text(),
    'receipt': storage.read(missing / 'receipt.json'),
}

malformed = {}
for adapter in ['codex-jsonl', 'claude-jsonl']:
    workspace = outdir / adapter
    prepare_job(workspace / 'jobs/A', argv=[sys.executable, '-B', '-c', 'print("null")'],
                normalizer=adapter)
    prepare_job(workspace / 'jobs/B',
                argv=[sys.executable, '-B', '-c',
                      'print(\'{"recommendation":"ACCEPT","findings":[]}\')'],
                normalizer='plain')
    try:
        collected = exchange.collect(workspace)
        result = {'collected': collected, 'escaped': None}
    except Exception as exc:
        result = {'escaped': type(exc).__name__, 'detail': str(exc)}
    result.update({'A_native_retained': (workspace / 'jobs/A/stdout.bin').read_bytes() == b'null\n',
                   'A_normalization_error_recorded': (workspace / 'jobs/A/normalization-error.json').exists(),
                   'B_valid_review_collected': (workspace / 'jobs/B/review.json').exists()})
    malformed[adapter] = result
report['F2_nonobject_jsonl_event'] = malformed
target = Path('/tmp/gnostoa-review-exchange-prep/reviewer-probes.json')
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
