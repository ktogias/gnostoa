"""Benign timeout descendant probe; no model, network or provider effects."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time

fixture = Path('/tmp/gnostoa-review-exchange/tests/fixtures/review_exchange')
sys.path.insert(0, str(fixture))
import storage

root = Path(tempfile.mkdtemp(prefix='timeout-probe-', dir='/tmp/gnostoa-review-exchange-prep'))
capture = root / 'capture-source.py'
capture.write_bytes((fixture / 'worker_capture.py').read_bytes())
marker, pidfile = root / 'descendant-after-deadline.txt', root / 'descendant.pid'
child_code = 'import time; from pathlib import Path; time.sleep(1); Path(' + repr(str(marker)) + ').write_text("continued after timeout")'
worker_code = ('import subprocess,sys,time; from pathlib import Path; '
               'p=subprocess.Popen([sys.executable,"-B","-c",' + repr(child_code) + ']); '
               'Path(' + repr(str(pidfile)) + ').write_text(str(p.pid)); time.sleep(5)')
job = root / 'job'
assignment = b'{}\n'
storage.write_bytes(job / 'assignment.json', assignment)
storage.write(job / 'intent.json', {'assignment_sha256': storage.digest(assignment), 'subject': {'commit': 'synthetic'}})
storage.write(job / 'spec.json', {'argv': [sys.executable, '-B', '-c', worker_code],
                                 'normalizer': 'plain', 'timeout_seconds': 0.2})
started = time.monotonic()
try:
    result = subprocess.run([sys.executable, '-B', str(capture), str(job)],
                            env={**os.environ, 'PYTHONPATH': str(fixture)},
                            capture_output=True, timeout=4, check=False)
    elapsed = time.monotonic() - started
    time.sleep(1.3)
    report = {'source_sha256': hashlib.sha256(capture.read_bytes()).hexdigest(),
              'capture_exit': result.returncode, 'capture_seconds': elapsed,
              'selected_timeout_seconds': 0.2, 'receipt': storage.read(job / 'receipt.json'),
              'descendant_wrote_after_deadline': marker.exists(), 'evidence_root': str(root)}
    Path('/tmp/gnostoa-review-exchange-prep/timeout-probe-after.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
finally:
    if pidfile.exists():
        try:
            os.kill(int(pidfile.read_text()), signal.SIGKILL)
        except ProcessLookupError:
            pass
