# Evaluate portable review exchange and coordinator replacement

## Selected outcome and authority

Owner `human:ktogias` replied **«Συμφωνώ»** after the [concrete evaluation card](https://github.com/ktogias/gnostoa/issues/10#issuecomment-5626517082) and its plain-language scope/budget summary. This records selection and authorization to construct and evaluate that bounded experiment after satisfying its pre-implementation gates. It does not authorize merge, general orchestration deployment or paid API usage.

Determine whether one exact published candidate can be assigned for review, its individual responses retained and collected, and its coordinator replaced without owner copy/paste or task reconstruction. This is a separately deliverable self-only experiment under #10, using #3 handoff semantics, #11 review provenance and #201 executor research. Those broader Work Items remain open; no blanket dependency or Phase-D authority transfer follows.

## Current subject and prior art

Read-back on 2026-09-10 at approximately 23:05 UTC: main `a0c71f3018876b192b6a98741c837b7074d8892e`, zero open PRs and no `roadmap:now` issue. #3 owns the broader handoff capability; no current Work Item owns this exact limited trial. Reference source is historical PR #228 head `6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`, remotely acquired tree `c468e8d9bf8b9b47f87cc5b3c7a89d8dc1bae4ba`; its accepted result is not reopened.

Reuse the [core study](https://github.com/ktogias/gnostoa/issues/10#issuecomment-5626244123), [provider qualification research](https://github.com/ktogias/gnostoa/issues/201#issuecomment-5626222572) and [version/license-bound component assessment](https://github.com/ktogias/gnostoa/issues/201#issuecomment-5626236985). Standard Python process/file/JSON primitives and official executable interfaces are the intended initial composition; new code is limited to experimental assignment/result identity, capture and checkpoint binding. An existing general scheduler is not required for two jobs on one host. Reassess that residual choice if implementation exceeds the fixed setup budget.

## Proposed changed surface and classification

**Normal, Gnostoa-self-only experimental/test change.** Planned paths: `tests/fixtures/review_exchange/`, `tests/test_review_exchange_fixture.py`, `knowledge/decisions/0063-evaluate-portable-review-exchange-and-coordinator-replacement.md`, `knowledge/assessments/portable-review-exchange-evaluation.md` and its retained native evidence directory, plus the knowledge index. Reserve Decision **0063** for this subject; current main's highest Decision is 0062 and no open PR exists. These paths are prospective, not claims that unpublished source exists.

No supported CLI, public schema, dependency, policy/guardrail, CI behavior or production control changes. No browser automation, credential copying, provider gateway, generic scheduler, dashboard, merge credentials or source-modifying reviewer. Reclassify/re-admit a material scope expansion.

## Initial behavior map (before implementation)

All evidence below is **NOT RUN**, alignment **UNKNOWN**, executor/reviewer dispositions **PENDING**. Intended implementation: the test-only exchange command and separate durable result consumer; evidence: frozen independent controlled oracle plus qualified live trial where available.

| ID | Source / obligation | Expected observation |
|---|---|---|
| E01 | Card: valid exchange | Exact candidate/assignment and original response/recommendation survive transfer; our dispositions remain separate. |
| E02 | Card: single-agent fallback | One actor can use the route without a claim of independent review. |
| E03 | Card: coordinator replacement | A fresh coordinator process resumes durable state after dispatch; no owner reconstruction or automatic repeated dispatch. |
| E04 | Card: missing/ambiguous result | Missing and lost-ack work stays visible pending/unknown; a never-registered eligible job is not removed from the independently frozen roster. |
| E05 | Card: stale subject | Changed candidate/assignment invalidates current use, preserves historical review and cannot inherit acceptance. |
| E06 | Card: duplicate and dissent | Duplicate delivery creates no duplicate disposition; material unresolved findings remain visible after collection. |
| E07 | Card: effects/cost | Public inputs, read-only candidate/GitHub during trial, no paid API fallback; unsupported live routes stay unestablished. |

Controlled fixtures establish transport properties only. Live model replies are not expected to rediscover every historical finding. Native response acquisition precedes normalization; integrity digests are not provider-authenticity or semantic-completeness evidence. Local persistence is not protected-principal isolation or L10 closure.

## Admission, verification and effect boundary

The separate owner selection above supplies the bounded construction choice. Before the corrected transport implementation: retain draft Decision 0063, freeze independently derived cases/expectations, and execute a defective transfer counterexample that actually loses/misclassifies required information. Missing executables do not count as behavioral RED. Then implement, run the unchanged oracle and a discriminating mutant, review the exact candidate, and run applicable container policy/fast/regression/smoke/extended verification. Live calls are conditional on verified account entitlement, permitted input, official route and exclusion of unplanned paid usage.

Trial limits: one reference candidate; at most two reviewer assignments, one intentional coordinator handoff and one review round; no automatic reviewer retries. Zero additional paid API spend. Two hours adapter/setup effort and 45 minutes live execution maximum, with owner semantic review separate. Ordinary branch, draft PR and evidence publication are delivery effects, not permission for the trial to mutate GitHub. Merge requires later exact-candidate owner authorization.

## Acceptance / exit criteria

- [ ] Frozen eligible population and expected controls retained before corrected implementation.
- [ ] Genuine behavioral counterexample, corrected replay and discriminating mutation retained.
- [ ] Original/native responses, normalized findings and individual dispositions survive controlled exchange/replacement without owner relay.
- [ ] Qualified real routes attempted within the budget, or precise unmet prerequisites and narrower/inconclusive real-portability outcome retained.
- [ ] Costs, interruptions, missing observations and scope limits reported without a fabricated time-saving comparison.
- [ ] One evidence packet recommends use, narrow or abandon; human review/merge and close-last reconciliation remain separate.

A negative/incomplete experimental result is valid. Stop at the stated budget or capability/data/cost boundary, preserve evidence, and do not expand the mechanism to rescue the hypothesis.
