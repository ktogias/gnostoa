# Claude route qualification for the admitted live review attempt

Reviewer: `/root/review_guideline_route/native_content_hygiene`.
Date: 2026-09-11. Scope: installed help/version and official auth-status
whitelist, plus limited official documentation. No model invocation, login,
installation, token-file read or GitHub write occurred.

**Original recommendation: USE the installed official Claude Code route for
the bounded attempt with the explicit invocation below.** The owner-confirmed
disabled extra charges resolve the previously missing owner-setting fact.
This is qualification to attempt the admitted call, not evidence that a live
review has succeeded or that runtime isolation/portability is established.

## Fresh observations

- Installed Claude Code is **2.1.267**, at the resolved native binary
  `/home/ktogias/.local/share/claude/versions/2.1.267`, SHA-256
  `0399c793ff571d5946ef923d80b4f330d05ac4b6842a6b0775468f5d389403c0`.
- Version, main help, auth help and auth-status help returned exit 0.
- At `2026-09-11T04:41:48.625941+00:00`, the official auth-status command under
  safe/restricted flags and an environment allowlist returned exit 0 with
  `loggedIn=true`, `authMethod=claude.ai`, `apiProvider=firstParty`,
  `subscriptionType=pro`. Only those four fields were retained from its
  response; raw stdout/stderr, email, account IDs and credentials were not.
- The proposed global restrictions/settings/model were also supplied to the
  **auth-status subcommand**, which returned the same four observations at
  `2026-09-11T04:43:39.198595+00:00`, without stderr. This exercises argument
  acceptance for that subcommand only, not inference startup or enforcement.
- Observed API-key, OAuth-token override, provider/base-URL, alternate model,
  proxy and Node injection variables were absent. The proposed child still
  receives an explicit allowlist, so later ambient variables are not inherited
  merely because they were absent at qualification time.

Owner confirmation of disabled extra charges was supplied by the parent for
both tools. This report records that source explicitly; auth status does not
prove a spending limit, and the provider billing UI was not inspected here.
Remaining quota and actual model availability are still unobserved.

## Exact proposed subprocess arguments — two distinct evidence claims

The machine-readable templates are in
`live-provider/claude-proposed-invocation.json`. The parent selected job B as
Claude reviewer plus replacement coordinator after the one intentional
handoff; this does not add a third live job. **Prefer the acquisition form**
for that role. The tools-empty form below remains a narrower fallback. Replace its session placeholder
with a fresh UUID bound to the frozen assignment before dispatch; do not pass
the placeholder literally. Use the resolved executable and verify the recorded
binary hash again immediately before launch.

```python
settings = {
    "forceLoginMethod": "claudeai",
    "fallbackModel": [],
    "switchModelsOnFlag": False,
    "availableModels": ["claude-sonnet-5"],
    "enforceAvailableModels": True,
    "disableAllHooks": True,
}
argv = [
    resolved_claude,
    "--safe-mode", "--restricted",
    "--setting-sources", "",
    "--settings", json.dumps(settings, separators=(",", ":")),
    "--tools", "",
    "--strict-mcp-config", "--mcp-config", '{"mcpServers":{}}',
    "--disable-slash-commands", "--no-chrome",
    "--permission-mode", "dontAsk", "--permission-prompts", "none",
    "--model", "claude-sonnet-5",
    "--session-id", assignment_session_uuid,
    "--input-format", "text",
    "--output-format", "stream-json", "--verbose", "--print",
]
```

The code above is the **tools-empty packet-consumption form**: supply all
required public source, roster, exchange view and sanitized handoff bytes on
stdin. A successful result demonstrates consumption, not autonomous durable
state acquisition.

For the **preferred acquisition form**, replace `"--tools", ""` with:

```python
"--tools", "Read,Glob,Grep",
"--allowedTools", "Read,Glob,Grep",
```

Start it in a dedicated curated public packet directory containing only the
admitted source and sanitized durable roster/exchange-view/handoff records.
Pass the bounded assignment and relative packet locator on stdin so job B
actually acquires the retained state with those file tools. Supply no
`--add-dir`. The installed `--restricted` help documents confinement of file
tools to the working directories; the selected built-in tool set contains no
Bash, write, Agent/subagent or web tool. The `--allowedTools` names approve only
those tool classes. **They are not path selectors, and cwd alone is not a
filesystem isolation boundary.** This review did not qualify absolute-path
permission-pattern syntax or test symlink escape/hostile isolation; do not
invent a `Read(...)`/`Glob(...)`/`Grep(...)` path guarantee from these flags.
Native evidence must show the actual acquisition and tool boundary.

Both forms use the retained environment allowlist, `shell=False`,
`close_fds=True` and `start_new_session=True`. Safe mode
disables custom agents, skills, hooks, plugins and MCP; restricted mode ignores
user/project/local settings; strict MCP configuration supplies an empty server
set. Ordinary auth/session persistence remains available. Do not use `--bare`:
the installed help says it excludes OAuth/keychain authentication and uses
API/cloud authentication instead.

The explicit Sonnet 5 name avoids a moving family alias. Current official
documentation lists Sonnet 5 as the Pro default; the empty configured fallback
chain and disabled flag-based switching express the selected single-model
route. Do not add a fallback model or automatically retry on quota/auth/model
failure. Actual model/provider observations still need validation during the
run. [Model configuration](https://code.claude.com/docs/en/model-config).

## Runtime acceptance and remaining uncertainty

Use an outer **900-second maximum**, shortened to the remaining admitted live
trial budget. Retain native stdout/stderr before normalization. On deadline,
terminate the cooperative process group and drain available output; record
timeout/interruption and pending review. A successful process exit alone is
insufficient: require the expected terminal result, assignment binding and
well-formed reviewer output. SIGTERM leaves a Claude turn unfinished and exits
143; absence of a final result must not become a completed review.
[Programmatic execution](https://code.claude.com/docs/en/headless).

On the admitted run, verify that reported tools match the chosen form
(exactly Read/Glob/Grep for acquisition, empty for consumption), MCP servers
are empty,
the actual main model matches the selected ID, and output does not report a
fallback/authentication change or unexpected tool execution. Unexpected or
missing observations make the attempt unestablished; preserve the native
record and stop without automatic redispatch. Wrapper-level retry count and
observable provider-internal usage/retries must remain distinct.

Managed policy is a residual: safe/restricted mode preserves admin-managed
settings, and higher-precedence managed values can override ordinary settings.
No managed configuration or credential file was opened here. The installed
flags and offline auth-status success do not prove that all relevant managed
settings, future startup behavior or remote inference effects are absent.
Conflicting policy must not be bypassed; retain a failed/unestablished attempt
if it prevents the selected boundary. This is a trusted official-tool route,
not a hostile-process security sandbox.
[Settings precedence](https://code.claude.com/docs/en/settings).

## Retained evidence and disposition

`live-provider/claude-local-inventory.json` binds installed help/version output;
`claude-auth-status-whitelist.json` and
`claude-proposed-flags-auth-status.json` retain only the four allowed auth
fields plus safe execution metadata. `claude-environment-presence.json` records
names/presence only, `claude-proposed-invocation.json` the proposed argument
array and deadline, and `claude-doc-sources.json` sources/retrieval limits.
Full vendor help is local research evidence; publication can retain the small
inventory and relevant summaries rather than copying vendor documentation.

Original recommendation: **USE the acquisition form for the selected job B
reviewer/replacement attempt under these restrictions and owner-confirmed
disabled extra charges.** The tools-empty form is an explicit narrower
consumption alternative, not substitute evidence for autonomous acquisition.
Executor disposition: **PENDING parent integration and actual live readback**.
No live-review result, independent human approval, merge authority or general
provider/agent dependency is created by this qualification.
