# Live-addendum publication hygiene review

Date: 2026-09-11. Reviewer: `/root/review_guideline_route`.
Scope: the frozen public inputs/specifications, actual A and B evidence,
sanitized qualification summaries, and the explicitly identified final metric
and disposition updates. No model invocation, provider write, source mutation
or change to frozen public inputs occurred in this review.

**Original recommendation: ACCEPT the exact 84-file final union for bounded
publication hygiene, with the metadata and opaque-provider-field limitations
below.** No actual credential or newly introduced private-content blocker was
identified. This is not a claim that encrypted interiors were inspected, nor
acceptance of the live experiment's behavioral outcome.

## Exact population and execution

The final population is **84 regular files, 660,211 bytes**, relative to
`/tmp/gnostoa-review-exchange-prep`. The canonical path/size/SHA-256 manifest is
`live-publication-final-union-manifest.json`, SHA-256
`61021c080b50abbb10e60f658a78f5e35a350197415b24b9d3e39a65f9846edc`.
Every final file was rehashed after the stated delta; no symlinks are included.
The raw A/B files and frozen public inputs remained unchanged.

Three actual, separately bound scans were performed using installed
detect-secrets 1.5.0 with default detectors and filters, with network
verification disabled:

| Scan | Input | Candidate occurrences | Binding |
|---|---|---:|---|
| Pre-B | 65 files / 427,119 bytes | 172 | `live-publication-preB-manifest.json`: `a4020eea9b707e7ec9f37b1503787d45b9120f1487dae100ca6503ab6a3a87dc` |
| B addition | 18 files / 230,108 bytes | 19 | `live-publication-B-addition-manifest.json`: `088952b0d29c2f8fc9f941075127767eba217d770719a9fb36666cb27cd1103f` |
| Final delta | 4 files / 5,277 bytes | 0 | `live-publication-final-delta-manifest.json`: `9221834db2a98bb00734405a21319e6646c0ceac55ac6681a1a5e97813cffc3f` |

The final delta **replaces** two earlier versions (`live-budget-end.json` and
`measurements.json`), adds `executor-review-dispositions.json`, and rechecks the
unchanged `final-view.json`. Those replacements had no candidates in the earlier
scan either. The final union is 84 files, not the sum of all three scan inputs.
`live-publication-final-delta-review.json` retains the before/after hashes.

The initial CLI scanner attempt failed while starting its multiprocessing pool;
its zero-byte stdout is not scan evidence. A serial invocation of the same
installed scanner API completed the scans without network verification. Actual
scan outputs and execution summaries are retained separately. No old campaign
was rerun or represented as a new result.

All **191 candidate occurrences** were matched back to exact candidate values
using the detector's own hashed identifier and then classified in context:

| Classification | Count |
|---|---:|
| Independently rehashed live file digests | 132 |
| Previously reviewed public Git object references | 42 |
| Declared source/execution/help fingerprints | 9 |
| Official executable digests | 3 |
| Previously reviewed file digests | 3 |
| Explicit local controlled-candidate Git identity | 1 |
| Literal native `apiKeySource: none` | 1 |

**Unresolved scanner candidates: 0.** Per-occurrence findings and rationales are
in `live-publication-triage.json`. A supplemental all-byte screen over the
initial 83 files found no common private-key header, GitHub/provider/AWS token,
JWT, long bearer token or credential-bearing URL. The four final delta files
were separately read in full and scanned; no credential/private-content concern
was identified. These finite checks are not an exhaustive secret-absence proof.

## Independent content review and disclosures

**LP1 — Public source and handoff binding.** Independent reviewer
`/root/review_guideline_route/native_content_hygiene` inspected all 25 frozen
public files (197,453 bytes). All 11 source files match both the embedded packet
and local Git blobs at historical public subject
`6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`. A's handoff contains empty stdout,
the short startup configuration error, matching receipt hashes and an explicitly
unavailable prior review. The reviewer’s original recommendation was **ACCEPT
these scoped public inputs**; my disposition is **ADOPTED**. Its immutable
report is `live-public-input-hygiene.md`, SHA-256
`e6131c7f7ef47dbb95712325ce458fa8db0154542892b4fd1dc70a843e73f8e5`.

**LP2 — Actual B native output.** The same independent reviewer separately
inspected B stdout (204,813 bytes, SHA-256
`17e93ae481be1d5cfc2a95364dd907689513e0f849a8e445cbbcdecf6f0e023c`),
empty stderr, the manual extraction and native observations. Its 101 JSONL
events contain eight Read and two Glob calls with supplied paths inside the
frozen public directory. The extraction preserves the complete native terminal
text and its hash; it does not repair the strict normalizer's failed result.
Original recommendation: **ACCEPT this exact B evidence with trace/opaque-field
disclosures**. My disposition: **ADOPTED with the clarification in LP3**.
Report: `live-B-raw-hygiene.md`, SHA-256
`f93351222358f43311797835e4d2aca9c2cea77b813e523381bd00bf0670dee8`.

**LP3 — Opaque fields are retained, not decoded or claimed empty.** Six native
thinking blocks have empty textual thinking and opaque `signature` values,
including one of 30,552 characters. The scanner did not flag those fields; its
zero-unresolved count is not a statement about their plaintext. Official
documentation describes this field as carrying encrypted full reasoning for
multi-turn continuity. Accordingly, the field is more than a simple content
digest: its encrypted interior and cryptographic validity were not independently
examined. It is retained as observed native provider output, without reproducing
its values in this report. No claim is made that arbitrary opaque strings are
safe merely because a field is called `signature`. The exact field's origin,
documented role and bounded public-input context support retaining this record;
they do not establish decoded-content completeness.
[Claude thinking documentation](https://platform.claude.com/docs/en/build-with-claude/thinking)
(accessed 2026-09-11).

**LP4 — Metadata is not anonymous.** The union includes the existing public
repository/account name, local executable/home paths and environment-location
strings in command specifications, session/message/tool identifiers, and a
local runtime socket path. These are disclosed operational/trace metadata, not
identified authentication values. Auth summaries preserve only their stated
whitelist. Do not describe the entire archive as containing no identifiers or
no account-related metadata. Vendor full help was excluded from this selected
population.

**LP5 — Runtime and billing claims remain separate.** Native B usage lists both
Sonnet 5 and Haiku 4.5. The auxiliary model's purpose is **UNKNOWN**; this record
does not establish an all-single-model guarantee, a main-model fallback, or an
additional charge. Its `costBasis=list` amounts are native accounting estimates,
not an invoice. The owner-confirmed disabled extra charges remain separately
attributed. The metric correction accurately says one successful CLI terminal
result, not one model turn. Both fixture normalizations remain failed/pending;
manual extraction and a hygiene ACCEPT cannot promote them into success.

## Publication boundary

Package these exact reviewed bytes and verify them against the final union
manifest. Additional generated closure/review/scan reports may be appended as
such, with a final archive index; this review does not claim recursively scanning
its own output. The changed repository assessment and later generated result
audit are outside this 84-file union and must not be silently described as part
of its scan population. Original qualification, native evidence and earlier
reviews were preserved. This recommendation does not authorize a new model
attempt, push, draft PR or other provider write.
