from pathlib import Path
import collections
import hashlib
import json
import re
from detect_secrets.plugins.high_entropy_strings import HexHighEntropyString
from detect_secrets.plugins.keyword import KeywordDetector

ROOT = Path('/tmp/gnostoa-review-exchange-prep')
manifests = {}
all_rows = []
for role, name in [('preB', 'live-publication-preB-manifest.json'),
                   ('B-addition', 'live-publication-B-addition-manifest.json')]:
    data = (ROOT / name).read_bytes()
    rows = json.loads(data)
    for row in rows:
        p = ROOT / row['path']
        assert p.is_file() and not p.is_symlink()
        current = p.read_bytes()
        assert len(current) == row['bytes']
        assert hashlib.sha256(current).hexdigest() == row['sha256']
    manifests[role] = {'path':name,'sha256':hashlib.sha256(data).hexdigest(),
                       'files':len(rows),'bytes':sum(x['bytes'] for x in rows)}
    all_rows.extend(rows)
assert len({x['path'] for x in all_rows}) == len(all_rows)
all_rows.sort(key=lambda x:x['path'])
union = (json.dumps(all_rows, sort_keys=True, separators=(',', ':')) + '\n').encode()
(ROOT/'live-publication-reviewed-union-manifest.json').write_bytes(union)
current_digests = {x['sha256'] for x in all_rows}
prior = json.loads((ROOT/'hygiene-triage.json').read_text())
prior_records = {x['scanner_hash']:x for x in prior['records']}
prior_member_digests = {x['sha256'] for x in json.loads((ROOT/'hygiene-input-manifest.json').read_text())}
binary_digests = {'3188814c35471432d4123203e0eb38e5bddc60226e3d7ddf0e59e649ea140022',
                  '0399c793ff571d5946ef923d80b4f330d05ac4b6842a6b0775468f5d389403c0'}
plugins = {'Hex High Entropy String':HexHighEntropyString(), 'Secret Keyword':KeywordDetector()}
records = []
for role, name in [('preB','live-publication-preB-secret-scan.json'),
                   ('B-addition','live-publication-B-addition-secret-scan.json')]:
    scan = json.loads((ROOT/name).read_text())
    for filename, findings in scan['results'].items():
        lines = (ROOT/filename).read_text(errors='replace').splitlines()
        cache = {}
        for finding in findings:
            number = finding['line_number']; detector = finding['type']; key = finding['hashed_secret']
            line = lines[number-1]
            if (number,detector) not in cache:
                cache[number,detector] = {x.secret_hash:x.secret_value for x in plugins[detector].analyze_line(filename,line,number,enable_eager_search=True)}
            value = cache[number,detector].get(key)
            category = 'UNRESOLVED'; reason = 'Needs exact token/context review.'
            if value is not None:
                if value in current_digests:
                    category,reason='recomputed-live-file-digest','Exact SHA-256 equals an independently rehashed member of this reviewed union.'
                elif value in binary_digests:
                    category,reason='qualified-official-binary-digest','Exact executable SHA-256 from fresh local binary qualification, matching prior version.'
                elif key in prior_records:
                    category,reason='reused-prior-'+prior_records[key]['category'],'Same candidate fingerprint/context type as earlier retained public-source hygiene classification.'
                elif value in prior_member_digests:
                    category,reason='prior-reviewed-file-digest','Exact earlier retained source/evidence member digest, already reviewed.'
                elif re.fullmatch(r'[a-fA-F0-9]{64}',value) and ('sha256' in line.lower() or 'digest' in line.lower()):
                    category,reason='declared-content-or-execution-fingerprint','Explicit sha256/digest field in frozen packet, assignment, receipt, help comparison or published-source record; no credential syntax. Not a new authenticity claim.'
                elif re.fullmatch(r'[a-fA-F0-9]{40}',value) and any(x in line.lower() for x in ['commit','tree','revision']):
                    category,reason='public-historical-git-object-reference','Git commit/tree identity of public reference candidate or its retained history; no credential syntax.'
                elif filename == 'live-run/live-budget-start.json' and '"controlled_head"' in line and re.fullmatch(r'[a-fA-F0-9]{40}',value):
                    category,reason='local-controlled-candidate-git-object','Explicit controlled_head Git commit identity in trial budget record; not a credential and not a claim of remote availability.'
                elif filename == 'live-run/native-observations-B.json' and '"apiKeySource"' in line and value == 'none':
                    category,reason='explicit-no-api-key-source-label','Native apiKeySource metadata is the literal none, not a credential.'
            records.append({'scan':role,'path':filename,'line':number,'detector':detector,'scanner_hash':key,
                            'exact_value_reidentified':value is not None,'category':category,'rationale':reason})

patterns = {
    'private-key-header':rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
    'github-token':rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})\b',
    'provider-token':rb'\bsk-(?:ant-[A-Za-z0-9_-]{20,}|proj-[A-Za-z0-9_-]{20,}|[A-Za-z0-9]{40,})\b',
    'aws-access-key':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'jwt':rb'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b',
    'long-bearer':rb'(?i)\bBearer\s+[A-Za-z0-9._~-]{24,}',
    'credentials-in-url':rb'https?://[^\s/@:]+:[^\s/@]+@',
}
pattern_matches=[]
for row in all_rows:
    data=(ROOT/row['path']).read_bytes()
    for name,pattern in patterns.items():
        for match in re.finditer(pattern,data):
            pattern_matches.append({'path':row['path'],'pattern':name,'offset':match.start(),
                                    'candidate_sha256':hashlib.sha256(match.group()).hexdigest()})

report={'input_manifests':manifests,'union':{'files':len(all_rows),'bytes':sum(x['bytes'] for x in all_rows),
       'manifest_sha256':hashlib.sha256(union).hexdigest()},'scanner_occurrences':len(records),
       'classification_counts':dict(collections.Counter(x['category'] for x in records)),
       'unresolved_count':sum(x['category']=='UNRESOLVED' for x in records),
       'records':records,'supplemental_all_bytes_pattern_matches':pattern_matches}
(ROOT/'live-publication-triage.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['records']},indent=2))
for x in records:
    if x['category']=='UNRESOLVED':print(json.dumps(x))
