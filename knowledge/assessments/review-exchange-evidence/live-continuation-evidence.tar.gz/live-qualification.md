# Narrow live route qualification: Codex and Claude

Date: 2026-09-11. Reviewer: `/root/review_guideline_route`.
Subject: the owner-selected first review-exchange card, with at most two live
reviewer assignments and one intentional coordinator handoff in one round.
Previous `provider/qualification.md` remains unchanged.

**Original recommendation: USE the two official subscription-authenticated
routes for the bounded live attempt.** The owner has now explicitly confirmed
that additional charges are not enabled for both Codex and Claude. This resolves
the specific missing owner-setting fact from the earlier qualification. It is
owner evidence, not a provider billing-control readback or a promise about
remaining quota. No LLM, review or completion inference was invoked here.

## Fresh observations

| Tool | Fresh binary/auth observations | Selected model | Remaining limits |
|---|---|---|---|
| Codex | `codex-cli 0.154.0`; binary SHA-256 `3188814c35471432d4123203e0eb38e5bddc60226e3d7ddf0e59e649ea140022`; official login status says ChatGPT. Official app-server `account/read` returned `type=chatgpt`, `planType=prolite`. | `gpt-6-astra`, `medium`; advertised by the native model catalog, without requesting Fast/priority. | Remaining quota/credits not queried. Catalog advertisement is not proof that the next inference will succeed. |
| Claude Code | `2.1.267`; binary SHA-256 `0399c793ff571d5946ef923d80b4f330d05ac4b6842a6b0775468f5d389403c0`; safe official status returns `loggedIn=true`, `authMethod=claude.ai`, `apiProvider=firstParty`, `subscriptionType=pro`. | Explicit `claude-sonnet-5`; current official documentation identifies Sonnet 5 as the Pro default. | Quota and actual next-call model availability remain unobserved; no fallback is authorized. |

Both executable hashes equal the earlier qualification. Claude help/version
files are byte-identical. Fresh Codex captures contain stdout only; the old
captures also included its harmless PATH-alias warning, so the files have
different hashes although their help/version content matches. Exact comparisons
are retained in `live-provider/version-help-comparison.json`.

The first Codex app-server metadata attempt exited before `initialize` because
its SQLite initialization encountered a read-only filesystem. The same
metadata-only script succeeded with the permitted execution escalation needed
by the official tool's runtime state. It sent only `initialize`, `initialized`,
`account/read` with `refreshToken=false`, and `model/list`; no thread, turn,
login or consumption endpoint was called. The model catalog had no next page.
The protocol was terminated after its read-only replies. Authentication and
model metadata were whitelisted in memory; no email, account IDs, credential
contents or raw auth response were retained. This did not directly inspect
token files; the official tool used its ordinary authentication mechanism.
[Official app-server reference](https://learn.chatgpt.com/docs/app-server).

## Exact launch specifications

**Codex job A:** use the subprocess argument array and complete environment
recipe in `live-provider/codex-live-command.json`, replacing only the dedicated
public packet directory. It binds the resolved executable, explicit model,
ChatGPT-only login, official OpenAI provider, read-only sandbox and no approval
escalation. It ignores ambient user configuration, disables hooks, plugins,
apps, browser/computer, subagent, shell/code-mode, image and skill-dependency
execution surfaces, disables web search, and explicitly disables both MCP names
observed by the official configuration-list command (`node_repl`,
`openaiDeveloperDocs`). No MCP server connection or tool was invoked by that
list command. The curated working directory must not contain executable hooks
or project configuration.

Keep existing deny rules: the initial command recommendation included
`--ignore-rules`; the parent correctly requested its removal before execution.
The current command has no such flag. This is a recorded correction to the
recommendation, not evidence of a live bypass.

The child environment is constructed from an allowlist, not by subtracting
known secrets from the parent environment: retain the existing `HOME`, `LANG`,
`LC_ALL` and `TERM` values only; set `PATH=/usr/bin:/bin` and `NO_COLOR=1`.
Omit all other parent variables, including API keys, provider/base-URL
overrides, cloud routes, injected runtime settings and alternate credential
variables. Preserve the official auth location through unchanged `HOME`; do
not copy credentials. `shell_environment_policy.inherit="none"` is an additional
restriction for child tool processes. Observed key/provider overrides were
absent, but the explicit allowlist also handles later ambient additions.

These are version-supported configuration controls, not an already-executed
inference combination or a complete hostile-process isolation proof. Managed
configuration can constrain them. Unsupported overrides, conflicting policy,
unexpected tools/MCP/hooks, authentication changes or model rejection make the
attempt failed/unestablished; do not bypass that condition or select a paid
fallback. `--ignore-user-config` preserves authentication and does not itself
prove the absence of every managed configuration layer.
[Official configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference).

**Claude job B, reviewer and replacement coordinator:** use the preferred
acquisition array in `live-provider/claude-proposed-invocation.json`. The separate
review in `live-claude-qualification.md` gives its exact flags: safe/restricted
mode, no ordinary settings sources, explicit first-party subscription login,
disabled hooks and fallback chain, strict empty MCP, no Chrome or slash-command
customization, explicit Sonnet 5, and only `Read,Glob,Grep`. Start it in the
curated public directory containing the frozen source plus sanitized durable
roster, exchange view and handoff. Bind a fresh session UUID to the assignment.
Do not grant Bash, writes, Agent/subagent tools or additional directories.

The installed restricted mode documents file-tool confinement; a working
directory or tool-name allowlist alone is not a filesystem isolation boundary.
Neither path-pattern permissions nor symlink/hostile escape behavior was tested
here. The run must retain actual source/handoff acquisition and native tool
observations. The alternative tools-empty array accepts the complete frozen
packet through stdin and tests packet consumption only; it cannot establish
autonomous acquisition. Choose the intended claim before dispatch. It is not
an automatic second attempt after a failed acquisition job.
[Claude model settings](https://code.claude.com/docs/en/model-config),
[programmatic execution](https://code.claude.com/docs/en/headless).

## Execution and acceptance boundary

Use `shell=False`, closed inherited descriptors, and a new cooperative process
group. Open durable native stdout/stderr before launch and retain them before
normalization; inspect publication hygiene separately. Preserve native session
persistence where available. The external durable assignment/exchange record
remains authoritative for this same-host coordinator replacement exercise.

Per job, use at most **900 seconds**, shortened to the remaining shared
45-minute live budget. On deadline send SIGTERM to the process group; after
10 seconds, SIGKILL if still running. Drain partial output and mark the
assignment interrupted/incomplete. Deadline, exit 0, prose claiming completion,
or absence of a successor do not supply a successful review. Require a bound
terminal response and preserve available actual model, tool, usage and error
metadata. Record unobservable provider-internal request/token accounting as
UNKNOWN. Do not automatically redispatch or infer one assignment means one
provider request. This local deadline constrains the launched process; it is
not a newly proven provider-side cancellation guarantee.

The owner-setting confirmation permits the already-selected bounded attempt;
it creates no additional API-spend authorization, PR-creation authority,
GitHub-write authority or human semantic acceptance. The two providers are
reference adapters, not required domain dependencies.

## Findings, original recommendations and dispositions

| Reviewer/finding | Original recommendation | Disposition |
|---|---|---|
| This reviewer, LQ1: earlier extra-charge prerequisite lacked evidence. Owner now states additional charges are disabled for both tools. | USE the bounded subscription routes with no paid fallback. | Adopted as owner evidence; not relabeled as a billing API observation. |
| This reviewer, LQ2: Codex plan was previously unknown. Native metadata now reports ChatGPT `prolite` and a complete visible model page. | Use explicit advertised `gpt-6-astra`/medium; do not probe entitlement with inference. | Adopted. Actual next-call quota/model success remains to be observed. |
| Parent review, LQ3: initial Codex suggestion unnecessarily ignored deny rules. | Remove `--ignore-rules`. | Adopted before live execution; final argument array preserves rules. |
| Independent `/root/review_guideline_route/native_content_hygiene`, LQ4: Claude first-party Pro route and restricted acquisition form are available; tools-empty has a narrower evidence claim. | USE `Read,Glob,Grep` for selected job B acquisition; retain the tools-empty alternative only as consumption. | Adopted. Original review and argument arrays retained separately; actual inference/tool evidence remains pending. |

Evidence lives under `live-provider/`: fresh inventory and help comparisons,
sanitized account/model and auth-status responses, initial Codex infrastructure
failure, metadata-only preflight source/arguments, MCP names/enabled flags, and
the two nonexecuted command specifications. Full vendor help is local research
material; this memo does not recommend republishing that documentation. No
model calls, provider writes, installation or credential-file inspection were
performed by this qualification.
