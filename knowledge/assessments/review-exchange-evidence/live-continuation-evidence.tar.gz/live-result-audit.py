"""Read-only audit of retained #233 live data; no fixture/model execution."""

import hashlib
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path


ROOT = Path('/tmp/gnostoa-review-exchange-prep/live-run')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_bytes())


out = {'kind': 'read-only retained-data audit, not tests or live execution'}
out['files'] = {}
names = [
    'A.json', 'B.json', 'roster.json', 'handoff-dispatch-binding.json',
    'manual-review-B-extraction.json', 'native-observations-B.json',
    'live-budget-start.json', 'live-budget-end.json',
]
for job in ['A', 'B']:
    names.extend(f'exchange/jobs/{job}/{name}' for name in [
        'assignment.json', 'intent.json', 'receipt.json', 'stdout.bin',
        'stderr.bin', 'normalization-error.json', 'spec.json',
    ])
for name in names:
    data = (ROOT / name).read_bytes()
    out['files'][name] = {'bytes': len(data), 'sha256': digest(data)}

roster = read('roster.json')
out['eligible_ids'] = roster['eligible_job_ids']
out['binding_checks'] = {}
for job in ['A', 'B']:
    prefix = f'exchange/jobs/{job}'
    receipt, intent = read(prefix + '/receipt.json'), read(prefix + '/intent.json')
    assignment = (ROOT / prefix / 'assignment.json').read_bytes()
    out['binding_checks'][job] = {
        'assignment_matches_frozen': assignment == (ROOT / (job + '.json')).read_bytes(),
        'assignment_hash_matches_receipt_and_intent': digest(assignment) == receipt['assignment_sha256'] == intent['assignment_sha256'],
        'subject_matches_roster': receipt['subject'] == intent['subject'] == roster['subject'],
        'stdout_hash_matches': digest((ROOT / prefix / 'stdout.bin').read_bytes()) == receipt['stdout_sha256'],
        'stderr_hash_matches': digest((ROOT / prefix / 'stderr.bin').read_bytes()) == receipt['stderr_sha256'],
        'returncode': receipt['returncode'],
        'review_json_exists': (ROOT / prefix / 'review.json').exists(),
        'normalization_error': read(prefix + '/normalization-error.json'),
    }
binding = read('handoff-dispatch-binding.json')
out['public_binding_checks'] = {
    name: digest((ROOT / 'public' / name).read_bytes()) == expected
    for name, expected in binding['public_members'].items()
}

events = [json.loads(line) for line in (ROOT / 'exchange/jobs/B/stdout.bin').read_bytes().splitlines() if line.strip()]
out['native_event_counts'] = dict(Counter(event.get('type') for event in events))
init = next(event for event in events if event.get('type') == 'system' and event.get('subtype') == 'init')
out['native_init'] = {key: init.get(key) for key in ['tools', 'mcp_servers', 'model', 'permissionMode', 'apiKeySource', 'skills', 'plugins', 'agents']}
tool_uses, file_reads = [], []
for event in events:
    if event.get('type') == 'assistant':
        for block in event.get('message', {}).get('content', []):
            if block.get('type') == 'tool_use':
                tool_uses.append({'name': block['name'], 'input': block['input']})
    if event.get('type') == 'user':
        result = event.get('tool_use_result', {})
        file = result.get('file') if isinstance(result, dict) else None
        if isinstance(file, dict):
            path = Path(file['filePath'])
            content = file.get('content')
            file_reads.append({
                'path': str(path.relative_to(ROOT)),
                'num_lines': file.get('numLines'),
                'total_lines': file.get('totalLines'),
                'start_line': file.get('startLine'),
                'content_chars': len(content) if isinstance(content, str) else None,
                'native_file_content_matches_current': content == path.read_text() if isinstance(content, str) else False,
                'native_file_content_sha256': digest(content.encode()) if isinstance(content, str) else None,
            })
out['actual_tool_counts'] = dict(Counter(tool['name'] for tool in tool_uses))
out['tool_uses'] = tool_uses
out['file_reads'] = file_reads
results = [event for event in events if event.get('type') == 'result']
out['terminal_result_count'] = len(results)
result = results[0]
out['terminal'] = {key: result.get(key) for key in ['subtype', 'is_error', 'duration_ms', 'duration_api_ms', 'num_turns', 'total_cost_usd', 'modelUsage', 'permission_denials']}
text = result['result']
manual = read('manual-review-B-extraction.json')
blocks = re.findall(r'```json\s*\n(.*?)\n```', text, flags=re.DOTALL)
out['manual_capture_checks'] = {
    'exact_original_result_text': text == manual['original_result_text'],
    'raw_stdout_digest_matches': digest((ROOT / 'exchange/jobs/B/stdout.bin').read_bytes()) == manual['source_stdout_sha256'],
    'result_digest_matches': digest(text.encode()) == manual['source_result_sha256'],
    'json_fence_count': len(blocks),
    'parsed_block_matches_extracted_review': len(blocks) == 1 and json.loads(blocks[0]) == manual['extracted_review'],
}
try:
    json.loads(text)
except ValueError as exc:
    out['whole_result_json_parse'] = {'status': 'FAILED', 'error': str(exc)}
else:
    out['whole_result_json_parse'] = {'status': 'PASSED'}
review = manual['extracted_review']
handoff = review['handoff']
before = read('public/handoff/view-before-B.json')
out['handoff_checks'] = {
    'subject_matches': handoff['recovered_subject'] == roster['subject'],
    'eligible_matches': handoff['eligible_job_ids'] == roster['eligible_job_ids'],
    'prior_current_matches': handoff['prior_current_ids'] == before['current_ids'],
    'prior_pending_matches': handoff['prior_pending_ids'] == before['pending_ids'],
    'prior_A_absence_marker': read('public/handoff/prior-A-review.json'),
}
out['original_findings'] = review['findings']
out['original_recommendation'] = review['recommendation']
start = datetime.fromisoformat(read('live-budget-start.json')['at'])
end = datetime.fromisoformat(read('live-budget-end.json')['at'])
out['recorded_live_window_seconds'] = (end - start).total_seconds()
out['final_file_state'] = {
    'current_review_ids': [job for job in roster['eligible_job_ids'] if (ROOT / f'exchange/jobs/{job}/review.json').exists()],
    'normalization_error_ids': [job for job in roster['eligible_job_ids'] if (ROOT / f'exchange/jobs/{job}/normalization-error.json').exists()],
    'executor_dispositions': read('exchange/dispositions.json'),
}
print(json.dumps(out, indent=2))
