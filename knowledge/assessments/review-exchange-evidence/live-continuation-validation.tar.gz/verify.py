import subprocess,sys,json,time,hashlib
from pathlib import Path
out=Path('/evidence')
commands=[
 ('policy',['./ci/verify','policy']),
 ('knowledge',['python','-m','tools.validate_bundle','--profile','knowledge/profile.yaml','--bundle','knowledge']),
 ('docs',['python','-m','tools.build_docs','--repository-root','/workspace','--site-dir','/tmp/live-docs']),
 ('changed-source-scan',['python','-m','detect_secrets','--cores','1','scan','--no-verify','knowledge/assessments/portable-review-exchange-evaluation.md','knowledge/assessments/review-exchange-evidence/index.json'])]
results=[]
for name,args in commands:
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  r=subprocess.run(args,cwd='/workspace',stdout=stdout,stderr=stderr)
 results.append({'name':name,'argv':args,'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3)})
 print(name+': '+str(r.returncode),flush=True)
scan=json.loads((out/'changed-source-scan.stdout').read_text())
count=sum(len(rows) for rows in scan['results'].values())
summary={'commands':results,'changed_source_scan_candidates':count,'scope':'New documentary addendum/index only; executable fixture/test unchanged. Native outputs scanned separately before compression.','source_sha256':{n:hashlib.sha256((Path('/workspace')/n).read_bytes()).hexdigest() for n in ['knowledge/assessments/portable-review-exchange-evaluation.md','knowledge/assessments/review-exchange-evidence/index.json']}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('scan candidates: '+str(count))
sys.exit(int(any(r['exit_code'] for r in results) or bool(count)))
