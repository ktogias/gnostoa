Later validation supplement for #233. The first controlled archive is unchanged.
Original hygiene/code/packaging recommendations and executor dispositions are separate.
Initial fast failure is retained separately from corrected fast-final execution.
Ordinary scanner scanning a compressed archive does not cover its members; actual
extracted-member scans and contextual triage are retained. Public metadata/paths exist.
Measurement null means unobserved, never zero. No live model call occurred.
Source snapshots bind packaged checks; final changes after them are documentary only.
