# Validation supplement: separate pre-publication hygiene extension

Reviewer: `/root/review_guideline_route`; date 2026-09-11 Europe/Athens.

**Original recommendation: ACCEPT the frozen 1,570-file validation supplement for publication hygiene within this bounded scope.** All 4,997 scanner candidates were reidentified and context-classified; none remains unresolved. This is a separate extension. The original 4,097-member archive and its review are unchanged.

## Input and scanner binding

Two actual scans were supplied and inspected; no single unified 1,570-file scanner run is claimed:

| Scan input | Files / bytes | Input manifest SHA-256 | Complete detector report SHA-256 | Findings |
|---|---:|---|---|---:|
| Original validation stage, excluding later report-check addition | 1,569 / 9,169,523 | `594d8b46f47049ef93862e2cb7d2b13bf47525818b16c79cef5edc3fb838f914` | `6202a8268d111b901519074df7374a9f60641f9193f28a59c58b3517b5a5936d` | 4,997 |
| Final `review/report-check.md` addition | 1 / 9,004 | `6c32517bd526b751f8db4eff42bfdd4a78595f0d2540fddff3a7e18245b00df9` | `79b68f3774506308fb3251e624abd37cbbac2e8391963733bbb0611cb30fced4` | 0 |

The union is **1,570 regular files / 9,178,527 bytes**, canonical path/size/SHA-256 manifest `078135653eeaa2f61d3f661d0366fb4a66ba6e89177c40c548576feca10b62b5`. The added report's exact file SHA-256 is `b5b8272b7ab286abd67d25decf3d72775229b66fa85d832384cdcc34531eb715`. The earlier report-only scan is historical and was not used to bind this final version.

Both complete reports identify detect-secrets 1.5.0. The primary report contains 4,591 hex-entropy, 20 base64-entropy and 386 Secret Keyword occurrences. Every reported value was independently relocated by matching the retained detector SHA-1, including keywords triggered by the scanner's own `hashed_secret` metadata. Raw candidate values are not copied into the triage output.

## Findings and dispositions

1. **VH1 — Every reported candidate is explained. Disposition: cleared as noncredentials in context.** Reuse was restricted to exact prior detector-value hashes or the bound prior input manifest; new package/report fields were examined separately.

| Context | Occurrences |
|---|---:|
| Recomputed SHA-256 of current validation member bytes | 1,045 |
| Previously reviewed retained-member content digests | 1,592 |
| Public reference Git identities | 704 |
| Scanner-generated hash metadata | 1,157 |
| Package artifact, lock and selection digests | 468 |
| Paths, mounts, revision/output-directory arguments | 20 |
| Previously reviewed original archive digest | 2 |
| Named historical test-source digests | 4 |
| Prior hygiene observation fingerprints | 5 |
| **Total / unresolved** | **4,997 / 0** |

Package hashes occur in named artifact-selection fields, license inventories and CycloneDX component hashes. This hygiene classification does not assert that package integrity or licenses have been independently re-audited. Historical source/freeze fingerprints remain identity metadata rather than proof their original preimages are available.

2. **VH2 — Compressed input was opened. Disposition: reuse prior content review.** All 14 members of `source/inputs.zip` were read and compared byte-for-byte with the previously reviewed oracle members; every comparison matched. The outer ZIP was not treated as if scanning it alone covered its contents. A supplemental fixed-pattern screen also read the 1,570 staged files and these 14 inner members, with zero private-key/common-token/Bearer/JWT/credential-URL indicators.

3. **VH3 — New package and coverage metadata has no identified private-content blocker. Disposition: adopt the independent narrow review.** `/root/review_guideline_route/native_content_hygiene` inspected 30 metadata/report files. Package URLs, artifact hashes and SBOM UUIDs were metadata; `.coverage` contained source paths, empty context, branch numbers and coverage version data, not recorded account or command context. Its original recommendation was **ACCEPT** for those files; my disposition is **adopted**. Report SHA-256: `8473b5601779a95a26c0e95fa09655766973391d7191a0d0c012f27353daf5e5` (`validation-metadata-hygiene.md`). Public metadata and local execution paths remain disclosed; no global no-personal-identifiers claim is made.

4. **VH4 — Partial acquisition is not scanner evidence. Disposition: retain as an explicitly unusable historical capture.** `verification/extended-quality/capture-status.json` labels the first zero-byte tracked-tree scanner copy as incomplete. It was not parsed as a clean result or used to justify this review. The completed retry's tracked-tree report is separate; neither tracked-tree report alone establishes contents of compressed archives. This extension relies on the actual staged-member scans and inner-ZIP comparison above.

## Limits and retained records

This is hygiene clearance for the frozen stage, not a guarantee of exhaustive secret detection, provider-origin fidelity, semantic acceptance, package/license clearance or future archive membership. Root must package these exact bytes; the union manifest permits the resulting archive to be compared without rerunning the old campaign. No model/provider call, token-file inspection or source/bundle mutation was made by this review.

The detector's recorded filters remain relevant limitations. The fixed-pattern check is supporting evidence, not a substitute for context. An initial triage implementation redundantly analyzed repeated long manifest lines; the completed run cached identical line analyses without changing inputs or classification criteria. No unresolved result was waived for elapsed time.

Machine records: `validation-hygiene-review.json`, `validation-hygiene-triage.json`, three `validation-hygiene-*-manifest.json` files, `validation-zip-reuse.json`, `validation-hygiene-supplemental-screen.json`, and independent `validation-metadata-hygiene.md`. The original hygiene reports remain intact. Root's executor/publication disposition is separate from this original recommendation.
