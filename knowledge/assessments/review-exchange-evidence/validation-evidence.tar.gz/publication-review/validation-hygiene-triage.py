from pathlib import Path
import collections
import hashlib
import json
import re
from detect_secrets.plugins.high_entropy_strings import HexHighEntropyString, Base64HighEntropyString
from detect_secrets.plugins.keyword import KeywordDetector

ROOT = Path('/tmp/gnostoa-review-exchange-prep')
BASE = ROOT / 'validation-stage'
ADDITION = 'review/report-check.md'
manifest = []
digests = collections.defaultdict(list)
for path in sorted(BASE.rglob('*')):
    if path.is_dir():
        continue
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    name = str(path.relative_to(BASE))
    sha = hashlib.sha256(data).hexdigest()
    manifest.append({'path': name, 'bytes': len(data), 'sha256': sha})
    digests[sha].append(name)
bindings = {}
for name, rows in [('primary', [x for x in manifest if x['path'] != ADDITION]), ('addition', [x for x in manifest if x['path'] == ADDITION]), ('union', manifest)]:
    data = (json.dumps(rows, sort_keys=True, separators=(',', ':')) + '\n').encode()
    output = ROOT / f'validation-hygiene-{name}-manifest.json'
    output.write_bytes(data)
    bindings[name] = {'files': len(rows), 'bytes': sum(x['bytes'] for x in rows), 'manifest_sha256': hashlib.sha256(data).hexdigest()}

prior_path = ROOT / 'hygiene-triage.json'
prior = json.loads(prior_path.read_text())
prior_findings = {x['scanner_hash']: x for x in prior['records']}
prior_detector_values = set(prior_findings)
plugins = {'Hex High Entropy String': HexHighEntropyString(), 'Base64 High Entropy String': Base64HighEntropyString(), 'Secret Keyword': KeywordDetector()}
old_manifest_path = ROOT / 'hygiene-input-manifest.json'
assert hashlib.sha256(old_manifest_path.read_bytes()).hexdigest() == prior['input_manifest_sha256']
prior_member_digests = {x['sha256'] for x in json.loads(old_manifest_path.read_text())}
original_archive_digest = json.loads((ROOT / 'hygiene-archive-binding.json').read_text())['archive_sha256']
package_digests = set()
for path in (BASE / 'verification').glob('*quality/*artifact-selection.json'):
    obj = json.loads(path.read_text())
    package_digests.add(obj['lock']['sha256'])
    package_digests.add(obj['selection_sha256'])
    package_digests.update(x['sha256'] for x in obj['packages'])
detector_metadata = set(prior_detector_values)
for name in ('verification/extracted-members-secret-scan.json', 'verification/packaged-source-secret-scan.json'):
    obj = json.loads((BASE / name).read_text())
    detector_metadata.update(x['hashed_secret'] for xs in obj['results'].values() for x in xs)
records = []
scans = []
for role, path in [('primary', ROOT / 'validation-secret-scan.json'), ('addition', ROOT / 'validation-report-check-final-scan.json')]:
    data = path.read_bytes()
    scan = json.loads(data)
    scans.append({'role': role, 'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'version': scan['version'],
                  'generated_at': scan.get('generated_at'), 'finding_count': sum(map(len, scan['results'].values()))})
    for name, findings in scan['results'].items():
        file = BASE / name
        if not file.is_file() and role == 'addition':
            assert name.endswith(ADDITION)
            file = BASE / ADDITION
        assert file.is_file() and not file.is_symlink()
        relative = str(file.relative_to(BASE))
        assert (relative == ADDITION) == (role == 'addition'), (role, relative)
        lines = file.read_text(errors='replace').splitlines()
        candidate_cache = {}
        for finding in findings:
            line = lines[finding['line_number'] - 1]
            key = finding['hashed_secret']
            if finding['type'] not in plugins:
                values = []
            else:
                cache_key = (finding['line_number'], finding['type'])
                if cache_key not in candidate_cache:
                    candidate_cache[cache_key] = {x.secret_hash: x.secret_value for x in plugins[finding['type']].analyze_line(relative, line, finding['line_number'], enable_eager_search=True)}
                matched = candidate_cache[cache_key].get(key)
                values = [matched] if matched is not None else []
            value = values[0] if len(values) == 1 else None
            category = 'UNRESOLVED'
            reason = 'Exact value or semantic context needs review.'
            if value is not None:
                if value in digests:
                    category, reason = 'validation-member-digest', 'SHA-256 recomputed from actual staged member bytes.'
                elif key in prior_findings:
                    category, reason = 'reused-prior-' + prior_findings[key]['category'], 'Exact scanner hash matches previously context-reviewed token; original triage retained and bound.'
                elif value in prior_detector_values:
                    category, reason = 'prior-detector-hash-metadata', 'Value is the prior detector SHA-1 identifier, rather than the credential candidate itself.'
                elif value in prior_member_digests:
                    category, reason = 'prior-reviewed-member-digest', 'Value belongs to the exact prior input manifest whose member preimages were previously recomputed; old campaign not rerun.'
                elif value == original_archive_digest:
                    category, reason = 'original-archive-digest', 'Exact digest of the unchanged previously reviewed4097-member archive.'
                elif value in package_digests:
                    category, reason = 'package-artifact-lock-selection-digest', 'Exact value in package artifact-selection sha256 fields, cross-referenced by license inventory and CycloneDX component hashes; not a credential.'
                elif value in detector_metadata:
                    category, reason = 'scanner-hash-metadata', 'Exact hashed_secret metadata from retained detector report; not the underlying detected value.'
                elif relative == 'review/hygiene-native-pattern-observations.json' and '"value_sha256"' in line:
                    category, reason = 'prior-hygiene-value-fingerprint', 'One-way fingerprint in prior identity/path observation report; underlying content was reviewed separately and is not disclosed here.'
                elif relative in ('review/packaging-probe.json', 'verification/fast-final-run.json', 'verification/packaged-controlled-run.json', 'verification/packaged-mutant-run.json') and re.fullmatch(r'[a-f0-9]{64}', value):
                    category, reason = 'named-historical-test-source-digest', 'Explicit test_sha256/source_sha256 field for the packaged test source; hygiene classification does not assert current-source equality.'
                elif relative == 'verification/extended-retry-run.json' and value.startswith('XDG_CACHE_HOME=/tmp/'):
                    category, reason = 'temporary-cache-environment-argument', 'Declared disposable dependency-audit cache location, not a secret.'
                elif relative == 'verification/extended-retry-run.json' and re.fullmatch(r'GNOSTOA_QUALITY_OUTPUT=/[A-Za-z0-9_/-]+', value):
                    category, reason = 'quality-report-directory-argument', 'Exact declared absolute output directory in retry argv; not a credential.'
                elif finding['type'] == 'Base64 High Entropy String' and re.fullmatch(r'(?:/[^\s]+|type=bind,source=[^\s]+|GNOSTOA_EXCHANGE_EVIDENCE=[^\s]+)', value):
                    category, reason = 'execution-path-or-mount-argument', 'Exact path/mount argument; no credential syntax.'
            records.append({'scan': role, 'path': relative, 'line': finding['line_number'], 'detector': finding['type'], 'scanner_hash': key,
                            'exact_value_reidentified': value is not None, 'category': category, 'rationale': reason})
summary = {}
for x in records:
    if x['category'] != 'UNRESOLVED':
        continue
    entry = summary.setdefault(x['scanner_hash'], {'scanner_hash': x['scanner_hash'], 'count': 0, 'representatives': []})
    entry['count'] += 1
    if len(entry['representatives']) < 3:
        line = (BASE / x['path']).read_text(errors='replace').splitlines()[x['line'] - 1]
        entry['representatives'].append({'path': x['path'], 'line': x['line'], 'keys': sorted(set(re.findall(r'"([A-Za-z_][A-Za-z0-9_]*)"\s*:', line)))})
result = {'bindings': bindings, 'scans': scans, 'prior_triage_sha256': hashlib.sha256(prior_path.read_bytes()).hexdigest(),
          'prior_input_manifest_sha256': prior['input_manifest_sha256'], 'finding_count': len(records),
          'category_counts': dict(collections.Counter(x['category'] for x in records)), 'unresolved': list(summary.values()), 'records': records}
(ROOT / 'validation-hygiene-triage.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:result[k] for k in ('bindings','scans','finding_count','category_counts','unresolved')},indent=2))
