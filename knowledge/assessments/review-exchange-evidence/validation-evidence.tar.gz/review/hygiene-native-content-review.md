# Independent retained-content hygiene review

Reviewer: `/root/review_guideline_route/native_content_hygiene`.
Date: 2026-09-11. Read-only review; no model/provider calls, credential-file
reads, installations, source edits or bundle changes.

**Original recommendation: ACCEPT this bounded content slice for the existing
public-source experiment evidence, with the identity disclosures below recorded
explicitly. No credential or private-content blocker was identified. Do not
describe the slice as containing no personal identifiers, and do not turn this
review into a proof that the whole archive is secret-free.**

## Subject and method

Root: `/tmp/gnostoa-review-exchange-prep/retained-experiment`.

| Inspected group | Files |
| --- | ---: |
| `README.txt` | 1 |
| `qualification/` | 5 |
| `review-and-admission/` | 15 |
| `review-native/` | 858 |
| Total | 879 |

The complete path/size/SHA-256 inventory is
`/tmp/gnostoa-review-exchange-prep/hygiene-native-file-inventory.json`.
These files total 383,629 bytes and contain 389 distinct byte contents. No
symlinks or non-UTF-8 files occurred in this slice.

All retained bytes were inspected by targeted pattern classification for email,
private-key headers, common provider-token formats, JWTs, authorization headers,
sensitive key/value assignments, home paths, IP addresses and UUIDs. This is
additional narrow analysis, not the parent's separate detect-secrets review.
I examined the qualification documents/JSON, README, review/admission narrative,
probe programs/results and public-provider record structures. For native
fixtures, I inspected the distinct JSON field/value vocabulary and distinct
non-JSON contents after omitting repetitive hashes, timestamps and temporary
paths from the displayed vocabulary. Source/probe commands were read, not run.

Pattern locations and value hashes, without email or possible secret values,
are retained in
`/tmp/gnostoa-review-exchange-prep/hygiene-native-pattern-observations.json`.

## Findings and original dispositions

**H1 — Personal attribution is present outside the sanitized auth record
(informational; RETAIN AS PUBLIC SOURCE PROVENANCE, accurately described).**
`review-and-admission/reference.json` contains the same personal name and
non-noreply email in `commit.author` and `commit.committer`; the email occurs
on lines 7 and 12. Values are intentionally not reproduced here. The retained
record identifies the official GitHub API resource for reference commit
`6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`. I compared those author/committer
values against the local Git commit object and verified its Git object ID:
both metadata pairs match that exact source commit. This is retained commit
attribution, not a credential obtained from an auth response. This review did
not make a fresh network request to re-establish the repository's visibility.

`review-and-admission/work-item-readback.json` also retains ordinary GitHub
user login, numeric ID, node ID and avatar/profile references. Their presence
means a global “no account identifiers retained” statement would be false.
The existing narrower statement about the **sanitized auth-status file** is
consistent with its contents.

**H2 — Local installation paths are linkable to the public owner
(informational; RETAIN WITH EXISTING HISTORICAL-PATH DESCRIPTION).**
`qualification/local-route-inventory.json` contains four `/home/<owner>/...`
paths identifying the local installation account. Other retained command
paths are temporary experiment locations. Paths, process IDs, timestamps,
tool versions and executable hashes reveal execution context; they are not
authentication material. The README already explains historical paths.

**H3 — Auth material is reduced to the declared status whitelist
(NO FINDING within this file).**
`qualification/auth-status-sanitized.json` contains tool/command, exit/status
metadata, timestamps, authentication method, provider and subscription type.
It contains no raw response, email, account ID or credential value. The eight
sensitive-assignment pattern matches are all false-valued environment-presence
entries in `qualification/local-route-inventory.json`, not environment values.

**H4 — Native review content is synthetic and contains no newly identified
private subject matter (NO FINDING within inspected content).**
Native identities are `fixture-reviewer-A`/`fixture-reviewer-B`; responses,
findings and diagnostics concern the controlled transport examples. The
content includes deliberate malformed JSON, lost-receipt cases, process
records and public reference hashes. No actual provider conversation,
non-public document, password, private-key header, common provider credential,
JWT or authorization-header value was identified in this slice. No IP-address
or UUID pattern occurred. Public documentation and GitHub URLs were the only
observed web-host families.

## Limits and executor disposition

This is a narrow hygiene opinion for the inventoried bytes. Pattern matching
cannot establish absence of arbitrary encoded/unknown secrets or confidential
meaning, and public-source attribution remains personal information. The
parent owns the remaining archive members, all detect-secrets classifications,
final archive/index binding, publication scope and executor disposition.

No finding requires altering original native evidence on the observed facts.
If a narrower publication policy requires removing public attribution or local
paths, preserve original provenance separately and label the published
derivative; do not silently relabel altered content as original bytes.

Executor disposition: **PENDING parent assessment**. The original reviewer
recommendation above is retained independently from that later disposition.
