# Pre-publication hygiene review: retained review-exchange evidence

Reviewer: `/root/review_guideline_route`.
Date: 2026-09-11 Europe/Athens.
Scope: the staged 4,097 regular files in `retained-experiment`, the corresponding archive, and the supplied detector report. No model calls, credential/token-file inspection, provider writes or bundle changes.

## Input binding and actual checks

- Archive: `knowledge/assessments/review-exchange-evidence/controlled-evidence.tar.gz`; 372,087 bytes; SHA-256 `36e2db1c7c1d68e93c1792defd4f9ceed60e88fadcc1b84184c9b746c48f8b0c`.
- Independent archive traversal found exactly **4,097 regular members with distinct safe relative names**. No symlinks, special entries, duplicate names, missing/unexpected members or byte differences against the staged manifest.
- All staged member sizes and SHA-256s were recomputed. Canonical JSON manifest SHA-256: `1133bee2c046ca54733f15dcd3d46e00a030ee4d339975fc783e74bbd871e9f3`.
- Supplied detect-secrets 1.5.0 report SHA-256: `62bda56bf47762fe6944ff844e673abb1438f83de7f9fa525a7daf63dad7175d`; **3,925 findings in 1,251 files**: 3,892 hex-entropy and 33 base64-entropy findings.
- Every reported token was independently reidentified on its recorded line by matching the detector's retained SHA-1. No finding was waived merely because it had an entropy label. The classification output retains detector hashes and contexts/reasons, not raw candidate values.

## Numbered findings and dispositions

1. **H1 — Scanner findings are explained; no unresolved candidate remains.** The exact categories below account for all 3,925 occurrences. **Disposition: cleared as noncredential findings within this evidence bundle.** Matching a digest to retained bytes does not establish provider authenticity, semantic correctness or authorship.

| Exact context classification | Occurrences | Basis |
|---|---:|---|
| SHA-256 of retained member bytes | 2,008 | Independently recomputed matching preimage in the bundle. |
| Public reference Git object identities | 1,876 | Candidate/tree/base/parent/blob fields; the drift fixture names the published parent commit. |
| Execution paths, mount and evidence-directory arguments | 31 | Exact path/argv context, including generated temporary-directory suffixes. |
| Literal nonsecret revision environment argument | 2 | `KNOWLEDGE_KIT_REVISION=working-tree`. |
| Historical intermediate source digest | 3 | Named test-source binding in earlier corrected-stage records; no assertion that the bytes equal final source. |
| Historical evaluation-card digest | 1 | Named `card_sha256` provenance field. |
| Historical freeze-revision digest | 1 | Named `previous_freeze_sha256`; its original preimage is not claimed retained by this classification. |
| Software executable digests | 3 | Recorded hashes of inspected Codex/Claude/third-party Grok executable files; no credentials. |
| **Total** | **3,925** | 382 distinct detector hashes; zero unmatched or unresolved findings. |

2. **H2 — Public identity/provenance data exists outside sanitized auth.** `review-and-admission/reference.json` includes the reference commit's author/committer name and email, matching the local Git object for published commit `6ee2deb9584ebb9a8f4fa4076fef10f9500903b9`. Other retained records contain public GitHub account metadata and owner-username home paths. **Disposition: retain as public-reference/local execution provenance; no credential/private-content blocker identified.** Do not describe the whole bundle as containing no personal or account identifiers. The sanitized-auth whitelist claim applies to that auth file only. Values are not repeated in this report.

3. **H3 — Supplemental indicator check was negative, with explicit limits.** An offline byte scan read all 4,097 staged files for private-key headers, common GitHub/OpenAI/Anthropic/AWS token shapes, long Bearer tokens, JWT-shaped values and credentials embedded in URLs. It found zero such indicators. **Disposition: supporting negative evidence, not proof that every possible secret or private datum is absent.** No new scanner ignore rule or suppression was added.

4. **H4 — Native/publication-facing slice separately reviewed.** A delegated independent narrow review inspected 879 files (383,629 bytes; 389 unique contents) under `review-native`, `qualification`, `review-and-admission` and README. It found the public identity provenance above, verified the sanitized auth whitelist, and identified no credential/private-content blocker. Its original recommendation was **ACCEPT with explicit identity disclosure**. **My disposition: adopted**, preserving the distinction between public metadata and a global no-identifiers assertion. Its report is `hygiene-native-content-review.md`, SHA-256 `d9644dddc76e591d371c2e501a29fcb4e368457d16eca5846a9854c42f6cc9ff`.

## Original recommendation

**ACCEPT the exact archive for publication hygiene within this bounded review scope**, with H2's accurate disclosure of public identity and local execution metadata. No identified credential or unresolved scanner finding blocks this archive. This does not authorize unrelated publication and does not certify provider-origin authenticity, every possible secret class, comprehensive privacy compliance, copyright clearance or the experiment's semantic result.

The detector report uses its recorded standard filters, including line allowlists and heuristics; those can omit material before results are emitted. The exhaustive result triage and supplemental pattern scan mitigate a different question from proving every byte nonprivate. Most controlled artifacts are repeated generated fixture records; this review does not claim line-by-line semantic inspection of all 4,097 files. Full vendor CLI help/web documents are not bundled, consistent with the archive README.

Machine evidence: `hygiene-triage.json` (per-finding dispositions), `hygiene-input-manifest.json`, `hygiene-archive-binding.json`, `hygiene-supplemental-screen.json`, and `hygiene-review.json`. The triage implementation is retained as `hygiene-triage.py`. Root's final publication disposition remains separate from this reviewer's original recommendation.
