from pathlib import Path
import collections
import hashlib
import json
import re
from detect_secrets.plugins.high_entropy_strings import HexHighEntropyString, Base64HighEntropyString

BASE = Path('/tmp/gnostoa-review-exchange-prep/retained-experiment')
REPORT = Path('/tmp/gnostoa-review-exchange-prep/evidence/extracted-members-secret-scan.json')
OUT = Path('/tmp/gnostoa-review-exchange-prep/hygiene-triage.json')
report = json.loads(REPORT.read_text())
files = sorted(p for p in BASE.rglob('*') if p.is_file())
nonregular = [str(p.relative_to(BASE)) for p in BASE.rglob('*') if p.is_symlink() or (not p.is_file() and not p.is_dir())]
manifest = []
digests = collections.defaultdict(list)
for p in files:
    data = p.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    name = str(p.relative_to(BASE))
    manifest.append({'path': name, 'bytes': len(data), 'sha256': sha})
    digests[sha].append(name)

records = []
summaries = {}
plugins = {'Hex High Entropy String': HexHighEntropyString(), 'Base64 High Entropy String': Base64HighEntropyString()}
reference = json.loads((BASE / 'review-and-admission/reference.json').read_text())
freeze = json.loads((BASE / 'oracle/freeze.json').read_text())
public_git_ids = {reference['sha'], reference['commit']['tree']['sha'], freeze['base_main']}
public_git_ids.update(x['sha'] for x in reference['parents'])
public_git_ids.update(x['sha'] for x in reference['files'])
known_software_hashes = {x['sha256'] for x in json.loads((BASE / 'qualification/local-route-inventory.json').read_text())['executables'].values() if 'sha256' in x}
historical_digest_hashes = {
    '6044024cf4e66015d5636386199685146d9b977a': ('historical-source-digest', 'Named tests/test_review_exchange_fixture.py binding in corrected-run source_sha256 and corrected-source-bindings; earlier stage, not asserted equal to final source.'),
    '30f0e8578cf92cbb301fecb270a631a0bcb68849': ('historical-card-digest', 'oracle/freeze.json card_sha256 links the proposed public evaluation card; not an API credential.'),
    '6ca1e4184ee8e6f19ce0f47887647512ad3ba8b5': ('historical-freeze-digest', 'oracle/freeze.json metadata_correction.previous_freeze_sha256 explicitly identifies the earlier metadata representation; not proof its preimage is retained.'),
}
for name, findings in report['results'].items():
    p = BASE / name
    assert p.is_file() and not p.is_symlink()
    lines = p.read_text(errors='replace').splitlines()
    for finding in findings:
        line = lines[finding['line_number'] - 1]
        candidates = plugins[finding['type']].analyze_line(name, line, finding['line_number'], enable_eager_search=True)
        matches = [s.secret_value for s in candidates if s.secret_hash == finding['hashed_secret']]
        # Plugin-specific extraction has not identified a string merely because
        # it happens to be hex-like: require the retained scanner's exact hash.
        value = matches[0] if len(matches) == 1 else None
        category = 'UNRESOLVED'
        rationale = 'Scanner value not yet independently located.'
        related = []
        if value is not None:
            if value in digests:
                category = 'retained-member-sha256'
                rationale = 'Matched detector SHA-1, then independently recomputed SHA-256 of retained member bytes.'
                related = digests[value]
            elif finding['type'] == 'Base64 High Entropy String' and re.fullmatch(r'(?:/[^\s]+|type=bind,source=[^\s]+|GNOSTOA_EXCHANGE_EVIDENCE=[^\s]+)', value):
                category = 'execution-path-or-mount-argument'
                rationale = 'Exact detected value is a path/mount/evidence-directory argument; no embedded credential syntax.'
            elif value == 'KNOWLEDGE_KIT_REVISION=working-tree':
                category = 'public-nonsecret-environment-argument'
                rationale = 'Literal revision selector from retained docker argv, not an environment secret.'
            elif value in public_git_ids:
                category = 'public-reference-git-object'
                rationale = 'Exact value matches candidate/tree/base/parent/blob metadata in retained public reference records; drift test explicitly selects the public parent commit.'
            elif value in known_software_hashes:
                category = 'software-executable-digest'
                rationale = 'Exact digest in sanitized local-route-inventory for the three inspected executables; binaries were hashed during route qualification, not credentials.'
            elif finding['hashed_secret'] in historical_digest_hashes:
                category, rationale = historical_digest_hashes[finding['hashed_secret']]
            elif re.fullmatch(r'[0-9a-fA-F]{40}', value):
                category = 'git-identity-needs-context'
                rationale = '40 hex characters only; pending context confirmation, not automatically cleared.'
            elif re.fullmatch(r'[0-9a-fA-F]{64}', value):
                category = 'unmatched-digest-needs-context'
                rationale = '64 hex characters only; pending context confirmation, not automatically cleared.'
            else:
                rationale = 'Exact scanner token found; contextual review still required.'
        key = finding['hashed_secret']
        record = {'path': name, 'line': finding['line_number'], 'detector': finding['type'], 'scanner_hash': key,
                  'exact_value_reidentified': value is not None, 'category': category, 'rationale': rationale,
                  'related_member_count': len(related), 'representative_related_members': related[:3]}
        records.append(record)
        if key not in summaries:
            summaries[key] = {'scanner_hash': key, 'category': category, 'count': 0, 'token_length': len(value) if value is not None else None,
                              'representatives': [], 'keys_on_line': sorted(set(re.findall(r'"([A-Za-z_][A-Za-z0-9_]*)"\s*:', line)))}
        summaries[key]['count'] += 1
        if len(summaries[key]['representatives']) < 3:
            summaries[key]['representatives'].append({'path': name, 'line': finding['line_number']})

manifest_bytes = (json.dumps(manifest, sort_keys=True, separators=(',', ':')) + '\n').encode()
manifest_path = OUT.with_name('hygiene-input-manifest.json')
manifest_path.write_bytes(manifest_bytes)
result = {'report_sha256': hashlib.sha256(REPORT.read_bytes()).hexdigest(), 'input_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
          'file_count': len(files), 'nonregular': nonregular, 'finding_count': len(records), 'category_counts': dict(collections.Counter(x['category'] for x in records)),
          'unique_scanner_hashes': len(summaries), 'summaries': list(summaries.values()), 'records': records,
          'method': 'Offline exact detector-hash reidentification; no scanner values retained in output. Context-only candidates remain unresolved.'}
OUT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:result[k] for k in ('report_sha256','input_manifest_sha256','file_count','nonregular','finding_count','category_counts','unique_scanner_hashes')},indent=2))
print(json.dumps([x for x in summaries.values() if x['category'] in ('UNRESOLVED','git-identity-needs-context','unmatched-digest-needs-context')],indent=2))
