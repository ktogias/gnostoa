"""Inspect only the pinned oracle package and loader; no controller execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import tarfile
import zipfile

root = Path('/tmp/gnostoa-review-exchange')
prep = Path('/tmp/gnostoa-review-exchange-prep')
archive = root / 'tests/fixtures/review_exchange/oracle/inputs.zip'
with zipfile.ZipFile(archive) as zipped:
    members = zipped.infolist()
    raw = {member.filename: zipped.read(member) for member in members}
    observed = [{
        'name': member.filename,
        'regular': stat.S_ISREG(member.external_attr >> 16),
        'bytes': len(raw[member.filename]),
        'sha256': hashlib.sha256(raw[member.filename]).hexdigest(),
        'matches_prep_original': raw[member.filename] == (prep / 'oracle' / member.filename).read_bytes(),
    } for member in members]

freeze_matches_retained = []
if not next(item for item in observed if item['name'] == 'freeze.json')['matches_prep_original']:
    retained = root / 'knowledge/assessments/review-exchange-evidence/controlled-evidence.tar.gz'
    with tarfile.open(retained, 'r:gz') as packed:
        for member in packed.getmembers():
            if member.isfile() and member.name.endswith('/freeze.json'):
                stream = packed.extractfile(member)
                if stream is not None and stream.read() == raw['freeze.json']:
                    freeze_matches_retained.append(member.name)

test = root / 'tests/test_review_exchange_fixture.py'
spec = importlib.util.spec_from_file_location('packaging_review_tests', test)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cls = module.ReviewExchangeFixtureTests
try:
    cls.setUpClass()
    extracted = {path.name: path.read_bytes() for path in cls.oracle.iterdir()}
    loader_matches = extracted == raw
    extracted_path = str(cls.oracle)
finally:
    cls.doClassCleanups()

report = {
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'test_sha256': hashlib.sha256(test.read_bytes()).hexdigest(),
    'member_count': len(members),
    'unique_member_count': len(raw),
    'members': observed,
    'freeze_matches_retained_members': freeze_matches_retained,
    'actual_loader_extracted_exact_zip_bytes': loader_matches,
    'actual_loader_freeze_checks_passed': True,
    'temporary_directory_cleaned': not Path(extracted_path).exists(),
    'controller_or_test_methods_executed': False,
}
(prep / 'packaging-probe.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
