# #233 frozen-oracle packaging review

Reviewer: `/root/code_review`, independent of loader implementation. Recorded **2026-09-10T23:40:55Z**, corresponding to 2026-09-11 Europe/Athens. Scope: the oracle ZIP, test loader, byte equivalence and unchanged transport source only. No new full-suite, model, provider or scanner execution is claimed.

**Recommendation: CODE REVIEW PASS for this byte-preserving packaging change.** No material defect was found in the inspected loader. The separate code review and its original findings/dispositions remain unchanged at `/tmp/gnostoa-review-exchange-prep/code-review.md`, SHA-256 `26b797f00bc21238f24dcc15a5995ea1a35ce12e3dde27ae0a70d96d56766379`.

## Observed source and extraction behavior

`tests/test_review_exchange_fixture.py:42–76` first verifies the pinned archive digest, then requires exactly fourteen unique fixed root-level filenames. Matching both count and exact name set rejects duplicates, extra entries, nested paths and traversal names. Every member must have a regular-file mode. The loader writes each member's raw bytes manually into its newly allocated temporary directory rather than applying archive paths/permissions through generic extraction. Class cleanup owns that directory.

The existing `freeze.json` length/SHA-256 comparisons at lines 85–92 still run after extraction. The archive pin also binds `freeze.json` itself. The digest's same-line allowlist annotation identifies a public archive identity; it does not add a general scanner exemption or change CI/policy.

The reviewer executed the actual `setUpClass` loader only. It extracted bytes exactly equal to the ZIP entries, completed all existing freeze checks, and its class cleanup removed the temporary directory. No controller operation or test method ran during this narrow packaging probe.

## Independent byte comparison

All **14 ZIP members are regular files, unique, and byte-for-byte identical to their counterparts in `/tmp/gnostoa-review-exchange-prep/oracle`**. This includes `freeze.json`, which matches the previously reviewed corrected freeze SHA-256 `6fb54866e129710c9025fa2809f6631664d7e9fd805b89b59c568e9eac656b43`; no fallback historical archive was needed. Exact native CRLF/spacing, zero-byte stderr, assignments, rosters, scenarios and expected results are preserved. This is actual byte comparison, not an inference from two controller-reported digests.

| Member | Bytes | SHA-256 |
| --- | ---: | --- |
| assignment-A-revised.json | 349 | `42742627ed419de43c9757675421db011622a0f4b5b03f25170f7a52e605912e` |
| assignment-A.json | 391 | `b578ffd50176352056238469f2d0f44682f4c5681a14997f2abe7d890e1d9c63` |
| assignment-B.json | 391 | `efc9214df953864eca8745500f93c1b0180d98d23b5c48fec7f668a0a6c3c031` |
| cases.json | 8003 | `15bc2531d890efd6f160ae7f5243f79d64c1dbf901ed161e71d44497bf019a02` |
| expected.json | 7448 | `1d36c771b8e27afc226b304ff7c5a5ab4b8bbd3783a416f9982eff8d0fb82f39` |
| freeze.json | 2974 | `6fb54866e129710c9025fa2809f6631664d7e9fd805b89b59c568e9eac656b43` |
| native-A.stdout | 74 | `efa623003078a9bc94e0f9826af9f51ef34ff30ca074c02865492b1ed31e7615` |
| native-B.stdout | 92 | `833a784fc7f28bddaf2752cb2f7f18735db7234e86df1ce160891345bbc9b48c` |
| native-diagnostic.stderr | 61 | `66c9c648d46fd4e3b4f9b2d7bb89752211e56fc49b6ebc75d731614a9f2e52a8` |
| native-dissent.stdout | 174 | `0f718df0370917b6338541dd02551c3ee45b2b33ee2792b530af22f26077d333` |
| native-empty.stderr | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| native-malformed.stdout | 51 | `93e6a80b3f41d70a939d82bdb9accc6842610b8785e0ef8da417571523f61edc` |
| roster-single.json | 361 | `c52b2fa0e2cffa23be2e789f50b1e84cd80c7a3c35b56b93d87468a1b3031e28` |
| roster-two.json | 365 | `9a6774173ee5ff9082089af39ac5524499274f081213650ec7688d16301ced23` |

## Subject binding and retained evidence

- Oracle ZIP: `147239f44eccca59deb31cf8911eec302a076e4651f50272da1ea437a989e38d`.
- Test file containing reviewed loader: `554219a826bf2bc16dac0aa2090a45bc6202af248e2707dd35cd66dc80c9bb07`.
- `candidate.py`: `5f4d5918933578dbc7510ece1b2e904118728196234c8b405b31c35909ae4535`.
- `baseline.py`: `bc755268ed9b05f66180da0aeb6adaa50b2d9c03bf9137cf3672214cab84a50e`.
- `exchange.py`: `675bda45143160301a7294a88a842fa275cef3db5fff335e5d882ea864165d58`.
- `storage.py`: `98e996c8f2423277f619f61f76da163b844011e750c18b6eb9aa97af675e4fc9`.
- `worker_capture.py`: `0ff77846b4953fe302e14e0e1e32fb094024a89e99feab9b0f173852a9264013`.
- `scripted_worker.py`: `8c950827946b76887fad8ef4f193665e299fddc733b07d4cd8ddc2825ad48eec`.
- `replay_mutant.py`: `1d596542450184e647a04017747b4c6f9cea9426f7745610f0898d8b54e983fa`.

The seven transport/worker/mutant Python files match the prior reviewed identities. The test loader is newly bound above; prior test executions are not relabeled as fresh executions of this packaged test file. Root owns the final complete container gates.

Command, using the previously authorized narrow native review fallback:

```sh
cd /tmp/gnostoa-review-exchange
python3 -B /tmp/gnostoa-review-exchange-prep/packaging-probe.py
```

The probe reads the archive and originals, invokes only actual loader setup/cleanup, and retains `/tmp/gnostoa-review-exchange-prep/packaging-probe.json`. Its report-key wording was clarified after execution from `controller_or_tests_executed` to `controller_or_test_methods_executed` because loader setup did execute; observations were unchanged.

- Probe script SHA-256: `c912cc1afb414d817f3543bf22ee51ca8ec5e06281f3205f086f6ca939a011d7`.
- Probe JSON SHA-256: `6f86028c2ad51380bcc08dd51c3bec81d9e621db4e38d3c5a51efa08518bed15`.

## Interpretation and limits

This packaging avoids changing the already frozen JSON bytes and adds no production schema, transport behavior, dependency or CI-policy mutation. A normal tracked-tree secret scan of a ZIP is not an extracted-content scan. The coordinator's separate actual extracted-content scan and contextual triage must remain the disclosure evidence; this reviewer neither reran that scan nor substitutes an archive digest for it. No inference is made about generic archive scanning, general untrusted-archive safety or hidden content beyond this exact verified package.

The prior bounded code-review recommendation remains applicable to the unchanged transport source. Live-call entitlement, zero extra paid usage, permitted public input, read-only effects, actual tool replacement, final experiment disposition and human merge authority remain separate. No source/provider/model effects or broad reruns were performed in this packaging review.

## Final annotation and README read-back

After the loader probe, the coordinator moved a public historical-SHA annotation onto its literal line. The current test-file SHA-256 is `ff3f079c4b515815d1ae89ed270ebd27b4d1203a68826d54eee440eeebf4d616`. This is a final source read-back; the executed loader probe above remains bound to `554219a8...` and is not relabeled as a new execution. The inspected loader contract and all seven transport Python hashes remain unchanged.

The current fixture README correctly describes **eight original controlled cases plus four review regression methods**, and says baseline/M0 should fail X04 with one assertion failure. Source inspection confirms the baseline now exposes the same complete packet fields required by R04, so the added packet regression does not introduce another expected baseline failure. Its roster-enumeration defect remains the intended X04 discriminator. Root separately reports packaged 12-test PASS and M0 with exactly one X04 failure; those executions belong to root's gate evidence and were not rerun here.

Recommendation remains **PASS for the narrow packaging and annotation subject**, with previous review records preserved.
